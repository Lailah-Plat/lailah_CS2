# 📱 تطبيق ليلة للجوال — Lailah Customer App

تطبيق React Native (Expo) مخصص للعميل في منصة ليلة لحجز قاعات المناسبات.

## 🚀 تشغيل المشروع

### المتطلبات
- Node.js 18+
- Expo CLI: `npm install -g expo-cli eas-cli`
- iOS: Xcode 15+ (Mac فقط)
- Android: Android Studio

### خطوات التشغيل

```bash
# 1. تثبيت الحزم
npm install

# 2. تشغيل على المحاكي
npm run ios      # iOS Simulator
npm run android  # Android Emulator

# 3. تشغيل على الجهاز الحقيقي (عبر Expo Go)
npm start
```

### ضبط رابط الـ API
افتح `src/api/client.ts` وغيّر:
```ts
export const BASE_URL = 'http://YOUR_PC_IP:3000'; // للتطوير المحلي
// أو
export const BASE_URL = 'https://api.lailah.sa';  // للإنتاج
```

## 📦 بناء التطبيق للنشر

```bash
# تسجيل دخول EAS
eas login

# بناء Android APK/AAB
eas build --platform android

# بناء iOS IPA
eas build --platform ios

# رفع للمتاجر
eas submit --platform android
eas submit --platform ios
```

## 🗂 هيكل المشروع

```
LailahApp/
├── App.tsx                    ← نقطة الدخول
├── src/
│   ├── api/
│   │   ├── client.ts          ← API client مع JWT
│   │   └── index.ts           ← جميع الـ services
│   ├── store/
│   │   └── index.ts           ← Zustand stores
│   ├── navigation/
│   │   └── index.tsx          ← كل شاشات التنقل
│   ├── theme/
│   │   └── index.ts           ← ألوان وخطوط وثيم
│   ├── types/
│   │   └── index.ts           ← TypeScript types
│   ├── components/
│   │   └── common/index.tsx   ← مكوّنات مشتركة
│   └── screens/
│       ├── auth/              ← تسجيل الدخول والتسجيل
│       ├── home/              ← الرئيسية والإشعارات
│       ├── explore/           ← استعراض القاعات
│       ├── booking/           ← الحجز والدفع والفاتورة
│       ├── services/          ← الخدمات المساندة
│       ├── chat/              ← المحادثات والدعم
│       ├── wallet/            ← المحفظة
│       ├── calendar/          ← التقويم الذكي
│       ├── profile/           ← الملف الشخصي والإعدادات
│       └── legal/             ← الشروط وسياسة الخصوصية
```

## ✅ الميزات المُنجزة

| الميزة | الحالة |
|--------|--------|
| تسجيل الدخول (بريد/جوال) | ✅ |
| تسجيل الدخول بالبصمة | ✅ |
| تسجيل الدخول بـ Google/Apple | ✅ |
| التحقق بـ OTP | ✅ |
| استعراض القاعات مع فلتر | ✅ |
| تفاصيل القاعة والصور | ✅ |
| استعراض الخدمات المساندة | ✅ |
| إنشاء حجز | ✅ |
| الدفع (Moyasar, Tabby, Tamara, HyperPay) | ✅ |
| تأكيد الحجز والفاتورة | ✅ |
| طلب خدمة مساندة | ✅ |
| متابعة الحجوزات | ✅ |
| المحفظة الإلكترونية | ✅ |
| التقويم الذكي | ✅ |
| المساعد الذكي (AI) | ✅ |
| المحادثات المباشرة (Socket.IO) | ✅ |
| تذاكر الدعم الفني | ✅ |
| الإشعارات Push | ✅ |
| المفضلة | ✅ |
| الملف الشخصي | ✅ |
| طرق الدفع المتاحة | ✅ |
| الشروط والأحكام | ✅ |
| سياسة الخصوصية | ✅ |
| من نحن | ✅ |
| تواصل معنا | ✅ |
| الأسئلة الشائعة | ✅ |
| الإعدادات | ✅ |

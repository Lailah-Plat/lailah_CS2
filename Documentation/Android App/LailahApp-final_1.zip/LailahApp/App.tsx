import React from 'react';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import Toast from 'react-native-toast-message';
import { usePushNotifications, setBadgeCount } from './src/hooks/usePushNotifications';
import { useNotificationsStore } from './src/store';
import AppNavigator from './src/navigation';

function AppContent() {
  usePushNotifications();
  const { unreadCount } = useNotificationsStore();
  // Update badge when unread count changes
  import('expo-notifications').then(n => n.setBadgeCountAsync(unreadCount));
  return null;
}

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <AppContent />
        <AppNavigator />
        <Toast />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

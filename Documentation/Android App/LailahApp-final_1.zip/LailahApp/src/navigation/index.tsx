/**
 * Navigation — هيكل التنقل الكامل للتطبيق
 */
import React from 'react';
import { View, Text, Platform } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../theme';
import { useAuthStore } from '../store';

// Screens
import SplashScreen       from '../screens/SplashScreen';
import OnboardingScreen   from '../screens/OnboardingScreen';
import LoginScreen        from '../screens/auth/LoginScreen';
import RegisterScreen     from '../screens/auth/RegisterScreen';
import OtpVerifyScreen    from '../screens/auth/OtpVerifyScreen';
import ForgotPasswordScreen from '../screens/auth/ForgotPasswordScreen';
import ResetPasswordScreen  from '../screens/auth/ResetPasswordScreen';

import HomeScreen         from '../screens/home/HomeScreen';
import NotificationsScreen from '../screens/home/NotificationsScreen';

import ExploreScreen      from '../screens/explore/ExploreScreen';
import HallDetailsScreen  from '../screens/explore/HallDetailsScreen';
import HallGalleryScreen  from '../screens/explore/HallGalleryScreen';
import HallReviewsScreen  from '../screens/explore/HallReviewsScreen';
import ServicesExploreScreen from '../screens/services/ServicesExploreScreen';
import ServiceDetailsScreen  from '../screens/services/ServiceDetailsScreen';

import MyBookingsScreen       from '../screens/booking/MyBookingsScreen';
import BookingDetailsScreen   from '../screens/booking/BookingDetailsScreen';
import CreateBookingScreen    from '../screens/booking/CreateBookingScreen';
import BookingServicesScreen  from '../screens/booking/BookingServicesScreen';
import BookingPaymentScreen   from '../screens/booking/BookingPaymentScreen';
import BookingConfirmScreen   from '../screens/booking/BookingConfirmScreen';
import InvoiceViewScreen      from '../screens/booking/InvoiceViewScreen';
import ServiceRequestsScreen  from '../screens/services/ServiceRequestsScreen';
import CreateServiceRequestScreen from '../screens/services/CreateServiceRequestScreen';

import ChatListScreen    from '../screens/chat/ChatListScreen';
import ChatRoomScreen    from '../screens/chat/ChatRoomScreen';
import SupportScreen     from '../screens/support/SupportScreen';
import SupportTicketScreen from '../screens/support/SupportTicketScreen';
import NewTicketScreen   from '../screens/support/NewTicketScreen';

import ProfileScreen     from '../screens/profile/ProfileScreen';
import EditProfileScreen from '../screens/profile/EditProfileScreen';
import WalletScreen      from '../screens/wallet/WalletScreen';
import FavoritesScreen   from '../screens/profile/FavoritesScreen';
import CalendarScreen    from '../screens/calendar/CalendarScreen';
import SmartAssistantScreen from '../screens/profile/SmartAssistantScreen';
import PaymentMethodsScreen from '../screens/profile/PaymentMethodsScreen';
import SettingsScreen    from '../screens/profile/SettingsScreen';
import AboutScreen       from '../screens/legal/AboutScreen';
import TermsScreen       from '../screens/legal/TermsScreen';
import PrivacyScreen     from '../screens/legal/PrivacyScreen';
import ContactScreen     from '../screens/legal/ContactScreen';
import FAQScreen         from '../screens/legal/FAQScreen';

const Stack = createNativeStackNavigator();
const Tab   = createBottomTabNavigator();

// ===== Auth Stack =====
function AuthStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Login"         component={LoginScreen} />
      <Stack.Screen name="Register"      component={RegisterScreen} />
      <Stack.Screen name="OtpVerify"     component={OtpVerifyScreen} />
      <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
      <Stack.Screen name="ResetPassword" component={ResetPasswordScreen} />
    </Stack.Navigator>
  );
}

// ===== Home Stack =====
function HomeStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Home"          component={HomeScreen} />
      <Stack.Screen name="Notifications" component={NotificationsScreen} />
      <Stack.Screen name="HallDetails"   component={HallDetailsScreen} />
    </Stack.Navigator>
  );
}

// ===== Explore Stack =====
function ExploreStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Explore"         component={ExploreScreen} />
      <Stack.Screen name="HallDetails"     component={HallDetailsScreen} />
      <Stack.Screen name="HallGallery"     component={HallGalleryScreen} />
      <Stack.Screen name="HallReviews"     component={HallReviewsScreen} />
      <Stack.Screen name="ServicesExplore" component={ServicesExploreScreen} />
      <Stack.Screen name="ServiceDetails"  component={ServiceDetailsScreen} />
    </Stack.Navigator>
  );
}

// ===== Bookings Stack =====
function BookingsStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="MyBookings"           component={MyBookingsScreen} />
      <Stack.Screen name="BookingDetails"       component={BookingDetailsScreen} />
      <Stack.Screen name="CreateBooking"        component={CreateBookingScreen} />
      <Stack.Screen name="BookingServices"      component={BookingServicesScreen} />
      <Stack.Screen name="BookingPayment"       component={BookingPaymentScreen} />
      <Stack.Screen name="BookingConfirmation"  component={BookingConfirmScreen} />
      <Stack.Screen name="InvoiceView"          component={InvoiceViewScreen} />
      <Stack.Screen name="ServiceRequests"      component={ServiceRequestsScreen} />
      <Stack.Screen name="CreateServiceRequest" component={CreateServiceRequestScreen} />
    </Stack.Navigator>
  );
}

// ===== Chat Stack =====
function ChatStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ChatList"      component={ChatListScreen} />
      <Stack.Screen name="ChatRoom"      component={ChatRoomScreen} />
      <Stack.Screen name="Support"       component={SupportScreen} />
      <Stack.Screen name="SupportTicket" component={SupportTicketScreen} />
      <Stack.Screen name="NewTicket"     component={NewTicketScreen} />
    </Stack.Navigator>
  );
}

// ===== Profile Stack =====
function ProfileStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Profile"         component={ProfileScreen} />
      <Stack.Screen name="EditProfile"     component={EditProfileScreen} />
      <Stack.Screen name="Wallet"          component={WalletScreen} />
      <Stack.Screen name="Favorites"       component={FavoritesScreen} />
      <Stack.Screen name="Calendar"        component={CalendarScreen} />
      <Stack.Screen name="SmartAssistant"  component={SmartAssistantScreen} />
      <Stack.Screen name="PaymentMethods"  component={PaymentMethodsScreen} />
      <Stack.Screen name="Settings"        component={SettingsScreen} />
      <Stack.Screen name="About"           component={AboutScreen} />
      <Stack.Screen name="Terms"           component={TermsScreen} />
      <Stack.Screen name="Privacy"         component={PrivacyScreen} />
      <Stack.Screen name="ContactUs"       component={ContactScreen} />
      <Stack.Screen name="FAQ"             component={FAQScreen} />
    </Stack.Navigator>
  );
}

// ===== Tab Icon =====
function TabIcon({ name, focused, color }: { name: any; focused: boolean; color: string }) {
  return <Ionicons name={name} size={focused ? 26 : 22} color={color} />;
}

// ===== Bottom Tab Navigator =====
function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: Colors.white,
          borderTopWidth: 0.5,
          borderTopColor: Colors.border,
          height: Platform.OS === 'ios' ? 84 : 64,
          paddingBottom: Platform.OS === 'ios' ? 24 : 8,
          paddingTop: 8,
          elevation: 20,
          shadowColor: Colors.primary,
          shadowOpacity: 0.1,
          shadowRadius: 12,
        },
        tabBarActiveTintColor: Colors.primary,
        tabBarInactiveTintColor: Colors.gray400,
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '500',
          marginTop: -2,
        },
      }}
    >
      <Tab.Screen
        name="HomeTab"
        component={HomeStack}
        options={{
          title: 'الرئيسية',
          tabBarIcon: ({ focused, color }) => (
            <TabIcon name={focused ? 'home' : 'home-outline'} focused={focused} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="ExploreTab"
        component={ExploreStack}
        options={{
          title: 'استعرض',
          tabBarIcon: ({ focused, color }) => (
            <TabIcon name={focused ? 'search' : 'search-outline'} focused={focused} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="BookingsTab"
        component={BookingsStack}
        options={{
          title: 'حجوزاتي',
          tabBarIcon: ({ focused, color }) => (
            <TabIcon name={focused ? 'calendar' : 'calendar-outline'} focused={focused} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="ChatTab"
        component={ChatStack}
        options={{
          title: 'المحادثات',
          tabBarIcon: ({ focused, color }) => (
            <TabIcon name={focused ? 'chatbubbles' : 'chatbubbles-outline'} focused={focused} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="ProfileTab"
        component={ProfileStack}
        options={{
          title: 'حسابي',
          tabBarIcon: ({ focused, color }) => (
            <TabIcon name={focused ? 'person' : 'person-outline'} focused={focused} color={color} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

// ===== Root Navigator =====
export default function AppNavigator() {
  const { isAuthenticated } = useAuthStore();
  const [showSplash, setShowSplash] = React.useState(true);
  const [showOnboarding, setShowOnboarding] = React.useState(false);

  if (showSplash) {
    return <SplashScreen onDone={() => setShowSplash(false)} />;
  }

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {showOnboarding ? (
          <Stack.Screen name="Onboarding" component={OnboardingScreen} />
        ) : !isAuthenticated ? (
          <Stack.Screen name="Auth" component={AuthStack} />
        ) : (
          <Stack.Screen name="Main" component={MainTabs} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

/**
 * API Client — React Native
 * يستخدم AsyncStorage / SecureStore بدلاً من localStorage
 * يشارك نفس منطق الـ web client
 */
import * as SecureStore from 'expo-secure-store';

export const BASE_URL = 'https://api.lailah.sa'; // ← غيّر لـ IP محلي في التطوير

async function getToken(): Promise<string | null> {
  try {
    return await SecureStore.getItemAsync('authToken');
  } catch {
    return null;
  }
}

export class ApiError extends Error {
  status: number;
  data?: any;
  constructor(message: string, status: number, data?: any) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

async function request<T = any>(
  method: string,
  path: string,
  body?: any,
  extraHeaders?: Record<string, string>
): Promise<T> {
  const token = await getToken();

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'Accept-Language': 'ar',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...extraHeaders,
  };

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  });

  if (res.status === 401) {
    await SecureStore.deleteItemAsync('authToken');
    throw new ApiError('انتهت جلستك، يرجى تسجيل الدخول مرة أخرى', 401);
  }

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new ApiError(
      data?.error || data?.message || `خطأ في الخادم (${res.status})`,
      res.status,
      data
    );
  }

  return data as T;
}

export const api = {
  get:    <T = any>(path: string, headers?: Record<string, string>) =>
    request<T>('GET', path, undefined, headers),
  post:   <T = any>(path: string, body?: any, headers?: Record<string, string>) =>
    request<T>('POST', path, body, headers),
  put:    <T = any>(path: string, body?: any, headers?: Record<string, string>) =>
    request<T>('PUT', path, body, headers),
  patch:  <T = any>(path: string, body?: any, headers?: Record<string, string>) =>
    request<T>('PATCH', path, body, headers),
  delete: <T = any>(path: string, headers?: Record<string, string>) =>
    request<T>('DELETE', path, undefined, headers),
};

// ===================================================
// API Services — تطبيق ليلة للجوال
// ===================================================
import { api } from './client';
import type { User, Hall, Booking, Service, ServiceRequest, Wallet, Invoice } from '../types';

// ===== Auth =====
export const authApi = {
  login: (email: string, password: string) =>
    api.post<{ success: boolean; token: string; user: User }>('/api/auth/login', { email, password }),

  loginWithPhone: (phone: string, password: string) =>
    api.post<{ success: boolean; token: string; user: User }>('/api/auth/login', { email: phone, password }),

  register: (data: { name: string; email: string; phone: string; password: string }) =>
    api.post('/api/auth/register', data),

  verifyOtp: (email: string, otp: string) =>
    api.post('/api/auth/verify-otp', { email, otp }),

  forgotPassword: (email: string) =>
    api.post('/api/auth/forgot-password', { email }),

  resetPassword: (email: string, otp: string, newPassword: string) =>
    api.post('/api/auth/reset-password', { email, otp, newPassword }),

  socialLogin: (email: string, name: string, provider: 'google' | 'apple') =>
    api.post<{ success: boolean; token: string; user: User }>('/api/auth/social-login', { email, name, provider }),
};

// ===== Halls =====
export const hallsApi = {
  getAll: (params?: {
    city?: string; type?: string; minCapacity?: number;
    maxPrice?: number; search?: string; page?: number;
  }) => {
    const query = params
      ? '?' + new URLSearchParams(Object.entries(params).filter(([, v]) => v != null).map(([k, v]) => [k, String(v)])).toString()
      : '';
    return api.get<{ halls: Hall[]; total: number; page: number }>(`/api/halls${query}`);
  },

  getById: (id: number | string) =>
    api.get<Hall>(`/api/halls/${id}`),

  getAvailability: (id: number | string, startDate: string, endDate: string) =>
    api.get<{ available: boolean; blockedDates: string[] }>(
      `/api/halls/${id}/availability?start=${startDate}&end=${endDate}`
    ),

  getServices: (id: number | string) =>
    api.get<Service[]>(`/api/halls/${id}/services`),

  getReviews: (id: number | string) =>
    api.get(`/api/halls/${id}/reviews`),

  addReview: (id: number | string, rating: number, comment: string) =>
    api.post(`/api/halls/${id}/reviews`, { rating, comment }),
};

// ===== Independent Services =====
export const servicesApi = {
  getAll: (params?: { category?: string; city?: string; search?: string }) => {
    const query = params
      ? '?' + new URLSearchParams(Object.entries(params).filter(([, v]) => v != null) as [string,string][]).toString()
      : '';
    return api.get<{ services: Service[] }>(`/api/services${query}`);
  },

  getById: (id: number | string) =>
    api.get<Service>(`/api/services/${id}`),

  createRequest: (data: {
    serviceId: number | string;
    quantity: number;
    eventDate: string;
    address: string;
    notes?: string;
  }) => api.post<ServiceRequest>('/api/bookings/service-request', data),

  getMyRequests: () =>
    api.get<ServiceRequest[]>('/api/bookings/my-service-requests'),

  getRequestById: (id: number | string) =>
    api.get<ServiceRequest>(`/api/bookings/service-request/${id}`),
};

// ===== Bookings =====
export const bookingsApi = {
  getAll: (params?: { status?: string; page?: number }) => {
    const query = params
      ? '?' + new URLSearchParams(Object.entries(params).filter(([, v]) => v != null) as [string,string][]).toString()
      : '';
    return api.get<{ bookings: Booking[]; total: number }>(`/api/bookings${query}`);
  },

  getById: (id: number | string) =>
    api.get<Booking>(`/api/bookings/${id}`),

  create: (data: {
    hallId: number | string;
    startTime: string;
    endTime: string;
    guests: number;
    services?: Array<{ serviceId: number | string; quantity: number }>;
    notes?: string;
  }) => api.post<Booking>('/api/bookings/create', data),

  cancel: (id: number | string, reason: string) =>
    api.patch(`/api/bookings/${id}/cancel`, { reason }),

  getInvoice: (id: number | string) =>
    api.get<Invoice>(`/api/bookings/${id}/invoice`),
};

// ===== Payment =====
export const paymentApi = {
  getGateways: () =>
    api.get<{ gateways: string[]; activeDefault: string }>('/api/payment/gateways'),

  initPayment: (data: {
    bookingId: string | number;
    amount: number;
    gateway?: string;
    customerName?: string;
    customerEmail?: string;
    customerPhone?: string;
  }) => api.post<{ url?: string; sessionId?: string }>('/api/payment/init', data),

  verifyPayment: (paymentId: string, bookingId: string | number) =>
    api.get<{ success: boolean; status: string; booking?: Booking }>(
      `/api/payment/verify?paymentId=${paymentId}&bookingId=${bookingId}`
    ),
};

// ===== User Profile =====
export const userApi = {
  getProfile: () =>
    api.get<User>('/api/users/profile'),

  updateProfile: (data: Partial<User>) =>
    api.put<User>('/api/users/profile', data),

  uploadAvatar: async (imageUri: string) => {
    const formData = new FormData();
    formData.append('avatar', {
      uri: imageUri,
      name: 'avatar.jpg',
      type: 'image/jpeg',
    } as any);
    const token = await import('expo-secure-store').then(m => m.getItemAsync('authToken'));
    const res = await fetch('/api/upload?type=avatar', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: formData,
    });
    return res.json();
  },

  changePassword: (currentPassword: string, newPassword: string) =>
    api.post('/api/users/change-password', { currentPassword, newPassword }),

  deleteAccount: () =>
    api.delete('/api/users/account'),
};

// ===== Favorites =====
export const favoritesApi = {
  getAll: () => api.get<{ favorites: any[] }>('/api/favorites'),
  add: (hallId: number | string) => api.post('/api/favorites', { hallId }),
  remove: (hallId: number | string) => api.delete(`/api/favorites/${hallId}`),
};

// ===== Wallet =====
export const walletApi = {
  get: () => api.get<Wallet>('/api/finance/customer-wallet'),
  getTransactions: (page = 1) =>
    api.get(`/api/finance/customer-wallet/transactions?page=${page}`),
};

// ===== Notifications =====
export const notificationsApi = {
  getAll: () => api.get<{ notifications: any[]; unread: number }>('/api/notifications'),
  markRead: (ids?: string[]) => api.post('/api/notifications/mark-read', { ids }),
  delete: (id: string) => api.delete(`/api/notifications/${id}`),
  registerPushToken: (token: string, platform: 'ios' | 'android') =>
    api.post('/api/notifications/push-token', { token, platform }),
};

// ===== Chat / Support =====
export const chatApi = {
  getTickets: () => api.get('/api/support/tickets'),
  createTicket: (subject: string, message: string, priority?: string) =>
    api.post('/api/support/tickets', { subject, message, priority }),
  getTicketMessages: (ticketId: number | string) =>
    api.get(`/api/support/tickets/${ticketId}/messages`),
  sendMessage: (ticketId: number | string, message: string) =>
    api.post(`/api/support/tickets/${ticketId}/messages`, { message }),
  closeTicket: (ticketId: number | string) =>
    api.patch(`/api/support/tickets/${ticketId}/close`, {}),
};

// ===== Analytics =====
export const analyticsApi = {
  getOverview: () => api.get('/api/analytics/overview'),
};

// ===== Platform Info =====
export const platformApi = {
  getInfo: () => api.get('/api/security/platform-info'),
  getPaymentMethods: () => api.get('/api/payment/gateways'),
  getFAQ: () => api.get('/api/security/faq'),
  getTerms: () => api.get('/api/security/terms'),
  getPrivacy: () => api.get('/api/security/privacy'),
};

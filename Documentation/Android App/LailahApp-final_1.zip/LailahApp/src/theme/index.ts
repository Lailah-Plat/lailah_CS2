// ===================================================
// ثيم تطبيق ليلة — ألوان، خطوط، مسافات
// ===================================================

export const Colors = {
  primary:       '#6B21A8',   // بنفسجي ليلة
  primaryLight:  '#A855F7',
  primaryDark:   '#4C1D95',
  primaryBg:     '#F3E8FF',

  secondary:     '#EC4899',   // وردي
  secondaryLight:'#F9A8D4',

  accent:        '#8B5CF6',

  success:       '#10B981',
  successBg:     '#ECFDF5',
  warning:       '#F59E0B',
  warningBg:     '#FFFBEB',
  error:         '#EF4444',
  errorBg:       '#FEF2F2',
  info:          '#3B82F6',
  infoBg:        '#EFF6FF',

  // Neutrals
  white:         '#FFFFFF',
  black:         '#0F0F0F',
  gray50:        '#F9FAFB',
  gray100:       '#F3F4F6',
  gray200:       '#E5E7EB',
  gray300:       '#D1D5DB',
  gray400:       '#9CA3AF',
  gray500:       '#6B7280',
  gray600:       '#4B5563',
  gray700:       '#374151',
  gray800:       '#1F2937',
  gray900:       '#111827',

  // Background
  bg:            '#F8F7FC',
  bgCard:        '#FFFFFF',
  bgDark:        '#1A1033',

  // Text
  textPrimary:   '#1F1135',
  textSecondary: '#6B7280',
  textMuted:     '#9CA3AF',
  textLight:     '#FFFFFF',

  // Border
  border:        '#E5E7EB',
  borderFocus:   '#A855F7',

  // Status
  statusConfirmed:   '#10B981',
  statusPending:     '#F59E0B',
  statusCancelled:   '#EF4444',
  statusCompleted:   '#6B7280',
  statusPayment:     '#3B82F6',

  // Gradient (للاستخدام مع LinearGradient)
  gradientStart:  '#6B21A8',
  gradientEnd:    '#EC4899',
} as const;

export const Typography = {
  // Arabic font family
  fontArabic:    'Cairo',
  fontMono:      'monospace',

  // Sizes
  xs:    10,
  sm:    12,
  base:  14,
  md:    16,
  lg:    18,
  xl:    20,
  '2xl': 24,
  '3xl': 28,
  '4xl': 32,
  '5xl': 40,

  // Weights (as fontWeight strings)
  light:    '300' as const,
  regular:  '400' as const,
  medium:   '500' as const,
  semibold: '600' as const,
  bold:     '700' as const,
  extrabold:'800' as const,

  // Line heights
  tight:   1.25,
  normal:  1.5,
  relaxed: 1.75,
} as const;

export const Spacing = {
  0:   0,
  1:   4,
  2:   8,
  3:   12,
  4:   16,
  5:   20,
  6:   24,
  7:   28,
  8:   32,
  10:  40,
  12:  48,
  16:  64,
  20:  80,
  24:  96,
} as const;

export const Radius = {
  sm:   6,
  md:   10,
  lg:   14,
  xl:   18,
  '2xl':24,
  '3xl':32,
  full: 9999,
} as const;

export const Shadow = {
  sm: {
    shadowColor: '#6B21A8',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  md: {
    shadowColor: '#6B21A8',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 5,
  },
  lg: {
    shadowColor: '#6B21A8',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 20,
    elevation: 10,
  },
} as const;

export const Theme = { Colors, Typography, Spacing, Radius, Shadow };
export default Theme;

/**
 * App Store — Zustand
 * إدارة الحالة العامة للتطبيق
 */
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import type { User, AppNotification, Booking, Hall } from '../types';

// ===== Auth Store =====
interface AuthStore {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (user: User, token: string) => Promise<void>;
  logout: () => Promise<void>;
  updateUser: (partial: Partial<User>) => void;
  setLoading: (v: boolean) => void;
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false,

      login: async (user, token) => {
        await SecureStore.setItemAsync('authToken', token);
        set({ user, token, isAuthenticated: true });
      },

      logout: async () => {
        await SecureStore.deleteItemAsync('authToken');
        set({ user: null, token: null, isAuthenticated: false });
      },

      updateUser: (partial) =>
        set(state => ({ user: state.user ? { ...state.user, ...partial } : null })),

      setLoading: (v) => set({ isLoading: v }),
    }),
    {
      name: 'lailah-auth',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (s) => ({ user: s.user, isAuthenticated: s.isAuthenticated }),
    }
  )
);

// ===== Notifications Store =====
interface NotificationsStore {
  notifications: AppNotification[];
  unreadCount: number;
  setNotifications: (n: AppNotification[]) => void;
  addNotification: (n: AppNotification) => void;
  markRead: (ids?: string[]) => void;
  markAllRead: () => void;
  removeNotification: (id: string) => void;
}

export const useNotificationsStore = create<NotificationsStore>()((set) => ({
  notifications: [],
  unreadCount: 0,

  setNotifications: (notifications) =>
    set({ notifications, unreadCount: notifications.filter(n => !n.read).length }),

  addNotification: (n) =>
    set(state => ({
      notifications: [n, ...state.notifications],
      unreadCount: state.unreadCount + (n.read ? 0 : 1),
    })),

  markRead: (ids) =>
    set(state => {
      const updated = state.notifications.map(n =>
        !ids || ids.includes(n.id) ? { ...n, read: true } : n
      );
      return { notifications: updated, unreadCount: updated.filter(n => !n.read).length };
    }),

  markAllRead: () =>
    set(state => ({
      notifications: state.notifications.map(n => ({ ...n, read: true })),
      unreadCount: 0,
    })),

  removeNotification: (id) =>
    set(state => {
      const updated = state.notifications.filter(n => n.id !== id);
      return { notifications: updated, unreadCount: updated.filter(n => !n.read).length };
    }),
}));

// ===== Favorites Store =====
interface FavoritesStore {
  favorites: (number | string)[];
  toggleFavorite: (hallId: number | string) => void;
  setFavorites: (ids: (number | string)[]) => void;
  isFavorite: (hallId: number | string) => boolean;
}

export const useFavoritesStore = create<FavoritesStore>()(
  persist(
    (set, get) => ({
      favorites: [],
      setFavorites: (favorites) => set({ favorites }),
      toggleFavorite: (hallId) =>
        set(state => ({
          favorites: state.favorites.includes(hallId)
            ? state.favorites.filter(id => id !== hallId)
            : [...state.favorites, hallId],
        })),
      isFavorite: (hallId) => get().favorites.includes(hallId),
    }),
    {
      name: 'lailah-favorites',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);

// ===== Bookings Store =====
interface BookingsStore {
  bookings: Booking[];
  activeBooking: Booking | null;
  setBookings: (b: Booking[]) => void;
  setActiveBooking: (b: Booking | null) => void;
  updateBooking: (id: number | string, data: Partial<Booking>) => void;
}

export const useBookingsStore = create<BookingsStore>()((set) => ({
  bookings: [],
  activeBooking: null,
  setBookings: (bookings) => set({ bookings }),
  setActiveBooking: (activeBooking) => set({ activeBooking }),
  updateBooking: (id, data) =>
    set(state => ({
      bookings: state.bookings.map(b => b.id === id ? { ...b, ...data } : b),
    })),
}));

// ===== App Settings Store =====
interface AppSettingsStore {
  language: 'ar' | 'en';
  theme: 'light' | 'dark' | 'system';
  pushEnabled: boolean;
  biometricEnabled: boolean;
  setLanguage: (l: 'ar' | 'en') => void;
  setTheme: (t: 'light' | 'dark' | 'system') => void;
  setPushEnabled: (v: boolean) => void;
  setBiometricEnabled: (v: boolean) => void;
}

export const useAppSettingsStore = create<AppSettingsStore>()(
  persist(
    (set) => ({
      language: 'ar',
      theme: 'light',
      pushEnabled: true,
      biometricEnabled: false,
      setLanguage: (language) => set({ language }),
      setTheme: (theme) => set({ theme }),
      setPushEnabled: (pushEnabled) => set({ pushEnabled }),
      setBiometricEnabled: (biometricEnabled) => set({ biometricEnabled }),
    }),
    {
      name: 'lailah-settings',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);

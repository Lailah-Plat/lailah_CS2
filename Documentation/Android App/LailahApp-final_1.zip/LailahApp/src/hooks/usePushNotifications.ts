/**
 * Push Notifications Service — تطبيق ليلة
 * يتعامل مع Expo Push Notifications
 * يُسجّل token الجهاز عند تسجيل الدخول
 */
import { useEffect, useRef } from 'react';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { Platform } from 'react-native';
import { notificationsApi } from '../api';
import { useAuthStore, useNotificationsStore } from '../store';
import type { AppNotification } from '../types';

// ===== إعداد سلوك الإشعارات =====
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge:  true,
  }),
});

// ===== دالة تسجيل Push Token =====
export async function registerForPushNotifications(): Promise<string | null> {
  if (!Device.isDevice) {
    console.warn('Push notifications require a physical device');
    return null;
  }

  // طلب الإذن
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') {
    console.warn('Push notification permission denied');
    return null;
  }

  // Android channel
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('lailah-default', {
      name:        'ليلة',
      importance:   Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor:  '#6B21A8',
      sound:       'notification.wav',
    });
    await Notifications.setNotificationChannelAsync('lailah-bookings', {
      name:       'حجوزاتي',
      importance:  Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 250],
      lightColor: '#10B981',
    });
  }

  // الحصول على الـ token
  try {
    const projectId = Constants.expoConfig?.extra?.eas?.projectId;
    const tokenData = await Notifications.getExpoPushTokenAsync({ projectId });
    return tokenData.data;
  } catch (e) {
    console.error('Error getting push token:', e);
    return null;
  }
}

// ===== Hook استخدام الإشعارات =====
export function usePushNotifications() {
  const { user, isAuthenticated } = useAuthStore();
  const { addNotification }       = useNotificationsStore();
  const notifListener = useRef<any>();
  const responseListener = useRef<any>();

  useEffect(() => {
    if (!isAuthenticated || !user) return;

    // تسجيل token
    registerForPushNotifications().then(async token => {
      if (token) {
        try {
          await notificationsApi.registerPushToken(
            token,
            Platform.OS === 'ios' ? 'ios' : 'android'
          );
        } catch (e) {
          console.warn('Failed to register push token:', e);
        }
      }
    });

    // الاستماع للإشعارات الواردة (التطبيق مفتوح)
    notifListener.current = Notifications.addNotificationReceivedListener(notification => {
      const data = notification.request.content.data;
      const newNotif: AppNotification = {
        id:        notification.request.identifier,
        type:      data?.type || 'system',
        title:     notification.request.content.title || 'إشعار',
        body:      notification.request.content.body  || '',
        read:      false,
        data:      data as Record<string, any>,
        createdAt: new Date().toISOString(),
      };
      addNotification(newNotif);
    });

    // الاستماع لتفاعل المستخدم مع الإشعار (نقر)
    responseListener.current = Notifications.addNotificationResponseReceivedListener(response => {
      const data = response.notification.request.content.data;
      // يمكن التوجيه حسب نوع الإشعار هنا
      console.log('Notification tapped:', data);
    });

    return () => {
      if (notifListener.current)  Notifications.removeNotificationSubscription(notifListener.current);
      if (responseListener.current) Notifications.removeNotificationSubscription(responseListener.current);
    };
  }, [isAuthenticated, user?.id]);
}

// ===== إرسال إشعار محلي (للاختبار) =====
export async function sendLocalNotification(title: string, body: string, data?: Record<string, any>) {
  await Notifications.scheduleNotificationAsync({
    content: { title, body, data, sound: true },
    trigger: null, // فوري
  });
}

// ===== تحديث badge عدد الإشعارات =====
export async function setBadgeCount(count: number) {
  await Notifications.setBadgeCountAsync(count);
}

import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { Colors, Typography } from '../theme';

export default function SplashScreen({ onDone }: { onDone: () => void }) {
  const scale = new Animated.Value(0.7);
  const opacity = new Animated.Value(0);
  useEffect(() => {
    Animated.parallel([
      Animated.spring(scale, { toValue: 1, tension: 50, friction: 8, useNativeDriver: true }),
      Animated.timing(opacity, { toValue: 1, duration: 600, useNativeDriver: true }),
    ]).start();
    const t = setTimeout(onDone, 2200);
    return () => clearTimeout(t);
  }, []);
  return (
    <View style={styles.container}>
      <Animated.View style={{ transform: [{ scale }], opacity, alignItems: 'center' }}>
        <View style={styles.logo}><Text style={styles.logoText}>ليلة</Text></View>
        <Text style={styles.tagline}>احجز قاعتك بسهولة</Text>
      </Animated.View>
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center' },
  logo: { width: 100, height: 100, borderRadius: 50, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  logoText: { color: Colors.white, fontSize: 40, fontWeight: Typography.bold },
  tagline: { color: 'rgba(255,255,255,0.85)', fontSize: Typography.lg },
});

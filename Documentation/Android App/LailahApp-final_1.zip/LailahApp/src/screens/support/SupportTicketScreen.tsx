import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, StatusBadge, Card } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';
import { chatApi } from '../../api';
import { useAuthStore } from '../../store';

export default function SupportTicketScreen() {
  const nav   = useNavigation<any>();
  const route = useRoute<any>();
  const { ticketId } = route.params;
  const { user } = useAuthStore();
  const [ticket, setTicket]   = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [text, setText]         = useState('');
  const [sending, setSending]   = useState(false);

  useEffect(() => {
    chatApi.getTicketMessages(ticketId).then(res => {
      setMessages(res?.messages || []);
      if (res?.ticket) setTicket(res.ticket);
    }).catch(() => {});
  }, [ticketId]);

  async function send() {
    if (!text.trim()) return;
    setSending(true);
    try {
      await chatApi.sendMessage(ticketId, text.trim());
      setMessages(prev => [...prev, { id: Date.now(), message: text.trim(), sender: 'customer', createdAt: new Date().toISOString() }]);
      setText('');
    } catch {}
    finally { setSending(false); }
  }

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title={ticket?.subject || 'التذكرة'} onBack={() => nav.goBack()}
        rightAction={ticket && <StatusBadge status={ticket.status} />}
      />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={80}>
        <FlatList
          data={messages}
          keyExtractor={(m, i) => String(m.id || i)}
          contentContainerStyle={{ padding: 16, gap: 8 }}
          renderItem={({ item: m }) => {
            const isMe = m.sender === 'customer';
            return (
              <View style={{ alignItems: isMe ? 'flex-start' : 'flex-end' }}>
                <View style={[styles.bubble, isMe ? styles.myBubble : styles.themBubble]}>
                  <Text style={[styles.bubText, isMe && { color: Colors.white }]}>{m.message}</Text>
                  <Text style={[styles.bubTime, isMe && { color: 'rgba(255,255,255,0.7)' }]}>
                    {new Date(m.createdAt).toLocaleTimeString('ar-SA', { hour:'2-digit', minute:'2-digit' })}
                  </Text>
                </View>
              </View>
            );
          }}
        />
        <View style={styles.inputBar}>
          <TextInput style={styles.input} value={text} onChangeText={setText} placeholder="اكتب ردك..." placeholderTextColor={Colors.gray400} textAlign="right" multiline />
          <TouchableOpacity onPress={send} disabled={!text.trim() || sending} style={[styles.sendBtn, (!text.trim() || sending) && { opacity: 0.4 }]}>
            <Ionicons name="send" size={18} color={Colors.white} style={{ transform: [{ scaleX: -1 }] }} />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeScreen>
  );
}
const styles = StyleSheet.create({
  bubble: { maxWidth: '78%', padding: 10, borderRadius: 16 },
  myBubble: { backgroundColor: Colors.primary, borderBottomLeftRadius: 4 },
  themBubble: { backgroundColor: Colors.white, borderBottomRightRadius: 4 },
  bubText: { fontSize: Typography.base, color: Colors.textPrimary, lineHeight: 22 },
  bubTime: { fontSize: Typography.xs, color: Colors.textMuted, marginTop: 4 },
  inputBar: { flexDirection: 'row', gap: 10, padding: 12, backgroundColor: Colors.white, borderTopWidth: 0.5, borderTopColor: Colors.border },
  input: { flex: 1, backgroundColor: Colors.gray50, borderRadius: Radius.xl, paddingHorizontal: 14, paddingVertical: 10, fontSize: Typography.base, color: Colors.textPrimary, borderWidth: 1, borderColor: Colors.border },
  sendBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center' },
});

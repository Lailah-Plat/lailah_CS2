import React, { useState } from 'react';
import { View, Alert, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { SafeScreen, AppHeader, Input, Button, Card } from '../../components/common';
import { Colors } from '../../theme';
import { chatApi } from '../../api';

export default function NewTicketScreen() {
  const nav = useNavigation<any>();
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [loading, setLoading] = useState(false);

  async function submit() {
    if (!subject.trim() || !message.trim()) return Alert.alert('', 'أدخل الموضوع والرسالة');
    setLoading(true);
    try {
      await chatApi.createTicket(subject.trim(), message.trim(), priority);
      Alert.alert('✅ تم الإرسال', 'سنتواصل معك خلال 24 ساعة', [{ text: 'حسناً', onPress: () => nav.goBack() }]);
    } catch (err: any) {
      Alert.alert('خطأ', err.message || 'فشل إرسال التذكرة');
    } finally { setLoading(false); }
  }

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="تذكرة دعم جديدة" onBack={() => nav.goBack()} />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }} keyboardShouldPersistTaps="handled">
        <Input label="موضوع المشكلة" placeholder="وصف مختصر للمشكلة" value={subject} onChangeText={setSubject} icon="create-outline" />
        <Input label="تفاصيل المشكلة" placeholder="اشرح المشكلة بالتفصيل..." value={message} onChangeText={setMessage} multiline numberOfLines={5} />
        <Button label="إرسال التذكرة" onPress={submit} loading={loading} size="lg" icon="send-outline" />
      </ScrollView>
    </SafeScreen>
  );
}

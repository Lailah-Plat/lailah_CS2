import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card, StatusBadge, EmptyState, Button } from '../../components/common';
import { Colors, Typography } from '../../theme';
import { chatApi } from '../../api';
import type { SupportTicket } from '../../types';

export default function SupportScreen() {
  const nav = useNavigation<any>();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    chatApi.getTickets().then(res => setTickets(res?.tickets || res || [])).catch(() => {}).finally(() => setLoading(false));
  }, []);

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="تذاكر الدعم" onBack={() => nav.goBack()} />
      <FlatList
        data={tickets}
        keyExtractor={t => String(t.id)}
        contentContainerStyle={{ padding: 16, gap: 10, flexGrow: 1 }}
        ListHeaderComponent={
          <Button label="تذكرة جديدة" onPress={() => nav.navigate('NewTicket')} variant="primary" style={{ marginBottom: 12 }} icon="add-outline" />
        }
        ListEmptyComponent={!loading ? <EmptyState icon="headset-outline" title="لا توجد تذاكر" subtitle="أنشئ تذكرة دعم جديدة وسنتواصل معك قريباً" /> : null}
        renderItem={({ item: t }) => (
          <TouchableOpacity onPress={() => nav.navigate('SupportTicket', { ticketId: t.id })}>
            <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
              <View style={[styles.ticketIcon, { backgroundColor: t.status === 'open' ? Colors.infoBg : Colors.successBg }]}>
                <Ionicons name="ticket-outline" size={20} color={t.status === 'open' ? Colors.info : Colors.success} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.subject} numberOfLines={1}>{t.subject}</Text>
                <Text style={styles.date}>{new Date(t.createdAt).toLocaleDateString('ar-SA')}</Text>
              </View>
              <StatusBadge status={t.status} />
            </Card>
          </TouchableOpacity>
        )}
      />
    </SafeScreen>
  );
}
const styles = StyleSheet.create({
  ticketIcon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  subject: { fontSize: Typography.base, fontWeight: Typography.medium, color: Colors.textPrimary },
  date: { fontSize: Typography.xs, color: Colors.textSecondary, marginTop: 2 },
});

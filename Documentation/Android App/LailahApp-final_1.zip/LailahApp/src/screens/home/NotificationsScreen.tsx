import React, { useEffect } from 'react';
import { FlatList, TouchableOpacity, View, Text, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, EmptyState } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';
import { notificationsApi } from '../../api';
import { useNotificationsStore } from '../../store';

const TYPE_ICONS: Record<string, string> = {
  booking: 'calendar', payment: 'card', system: 'megaphone',
  review: 'star', support: 'headset', chat: 'chatbubble',
};

export default function NotificationsScreen() {
  const nav = useNavigation<any>();
  const { notifications, setNotifications, markAllRead, removeNotification } = useNotificationsStore();

  useEffect(() => {
    notificationsApi.getAll().then(res => setNotifications(res.notifications || [])).catch(() => {});
    notificationsApi.markRead();
  }, []);

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader
        title="الإشعارات"
        onBack={() => nav.goBack()}
        rightAction={
          <TouchableOpacity onPress={markAllRead}>
            <Text style={{ fontSize: Typography.xs, color: Colors.primary }}>قراءة الكل</Text>
          </TouchableOpacity>
        }
      />
      <FlatList
        data={notifications}
        keyExtractor={n => n.id}
        contentContainerStyle={{ padding: 16, gap: 8, flexGrow: 1 }}
        ListEmptyComponent={<EmptyState icon="notifications-outline" title="لا توجد إشعارات" subtitle="ستظهر هنا إشعاراتك" />}
        renderItem={({ item: n }) => (
          <TouchableOpacity
            onLongPress={() => removeNotification(n.id)}
            style={[styles.notifCard, !n.read && styles.notifUnread]}
            activeOpacity={0.85}
          >
            <View style={[styles.notifIcon, { backgroundColor: (!n.read ? Colors.primary : Colors.gray400) + '18' }]}>
              <Ionicons name={(TYPE_ICONS[n.type] || 'notifications') as any} size={20} color={!n.read ? Colors.primary : Colors.gray400} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.notifTitle, !n.read && { color: Colors.textPrimary }]}>{n.title}</Text>
              <Text style={styles.notifBody} numberOfLines={2}>{n.body}</Text>
              <Text style={styles.notifTime}>{new Date(n.createdAt).toLocaleDateString('ar-SA')}</Text>
            </View>
            {!n.read && <View style={styles.unreadDot} />}
          </TouchableOpacity>
        )}
      />
    </SafeScreen>
  );
}

const styles = StyleSheet.create({
  notifCard: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, backgroundColor: Colors.white, borderRadius: Radius.xl, padding: 14 },
  notifUnread: { backgroundColor: Colors.primaryBg },
  notifIcon: { width: 42, height: 42, borderRadius: 12, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  notifTitle: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary },
  notifBody: { fontSize: Typography.sm, color: Colors.textSecondary, marginTop: 3, lineHeight: 20 },
  notifTime: { fontSize: Typography.xs, color: Colors.textMuted, marginTop: 4 },
  unreadDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.primary, marginTop: 6 },
});

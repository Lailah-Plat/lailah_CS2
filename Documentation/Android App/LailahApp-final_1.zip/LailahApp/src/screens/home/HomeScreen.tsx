import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  FlatList, RefreshControl, Image, Dimensions,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeScreen, Card, Stars, Skeleton } from '../../components/common';
import { Colors, Typography, Spacing, Radius, Shadow } from '../../theme';
import { hallsApi, notificationsApi } from '../../api';
import { useAuthStore, useNotificationsStore, useFavoritesStore } from '../../store';
import type { Hall } from '../../types';

const { width } = Dimensions.get('window');

const HALL_TYPES = [
  { id: 'all', label: 'الكل', icon: 'grid-outline' },
  { id: 'wedding', label: 'أفراح', icon: 'heart-outline' },
  { id: 'conference', label: 'مؤتمرات', icon: 'business-outline' },
  { id: 'birthday', label: 'أعياد', icon: 'balloon-outline' },
  { id: 'graduation', label: 'تخرج', icon: 'school-outline' },
  { id: 'corporate', label: 'أعمال', icon: 'briefcase-outline' },
];

export default function HomeScreen() {
  const navigation = useNavigation<any>();
  const { user } = useAuthStore();
  const { unreadCount } = useNotificationsStore();
  const { isFavorite, toggleFavorite } = useFavoritesStore();

  const [halls, setHalls]           = useState<Hall[]>([]);
  const [featured, setFeatured]     = useState<Hall[]>([]);
  const [selectedType, setSelectedType] = useState('all');
  const [loading, setLoading]       = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { loadData(); }, []);

  async function loadData() {
    try {
      const res = await hallsApi.getAll({ page: 1 });
      const all = res.halls || [];
      setHalls(all);
      setFeatured(all.slice(0, 5));
    } catch { }
    finally { setLoading(false); setRefreshing(false); }
  }

  const filtered = selectedType === 'all'
    ? halls
    : halls.filter(h => h.type === selectedType);

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'صباح الخير';
    if (h < 17) return 'مساء الخير';
    return 'مساء النور';
  };

  return (
    <SafeScreen>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadData(); }} colors={[Colors.primary]} />}
      >
        {/* Header */}
        <LinearGradient colors={[Colors.gradientStart, Colors.gradientEnd]} style={styles.header}>
          <View style={styles.headerTop}>
            <View>
              <Text style={styles.greeting}>{greeting()}، {user?.name?.split(' ')[0]} 👋</Text>
              <Text style={styles.headerSub}>ابحث عن قاعتك المثالية</Text>
            </View>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <TouchableOpacity
                onPress={() => navigation.navigate('Notifications')}
                style={styles.headerIconBtn}
              >
                <Ionicons name="notifications-outline" size={22} color={Colors.white} />
                {unreadCount > 0 && (
                  <View style={styles.notifBadge}>
                    <Text style={styles.notifBadgeText}>{unreadCount > 9 ? '9+' : unreadCount}</Text>
                  </View>
                )}
              </TouchableOpacity>
            </View>
          </View>

          {/* Search Bar */}
          <TouchableOpacity
            style={styles.searchBar}
            onPress={() => navigation.navigate('ExploreTab', { screen: 'Explore', params: { focus: true } })}
          >
            <Ionicons name="search" size={18} color={Colors.gray400} />
            <Text style={styles.searchPlaceholder}>ابحث عن قاعة أو خدمة...</Text>
            <Ionicons name="options-outline" size={18} color={Colors.primary} />
          </TouchableOpacity>
        </LinearGradient>

        {/* Hall Type Filter */}
        <ScrollView
          horizontal showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 16, gap: 10 }}
        >
          {HALL_TYPES.map(t => (
            <TouchableOpacity
              key={t.id}
              onPress={() => setSelectedType(t.id)}
              style={[styles.typeChip, selectedType === t.id && styles.typeChipActive]}
            >
              <Ionicons
                name={t.icon as any} size={16}
                color={selectedType === t.id ? Colors.white : Colors.gray500}
              />
              <Text style={[styles.typeChipText, selectedType === t.id && { color: Colors.white }]}>
                {t.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Featured Halls */}
        {featured.length > 0 && (
          <View style={{ marginBottom: 24 }}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>قاعات مميزة ✨</Text>
              <TouchableOpacity onPress={() => navigation.navigate('ExploreTab')}>
                <Text style={styles.seeAll}>عرض الكل</Text>
              </TouchableOpacity>
            </View>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, gap: 14 }}>
              {featured.map(hall => (
                <FeaturedCard key={hall.id} hall={hall} onPress={() => navigation.navigate('ExploreTab', { screen: 'HallDetails', params: { hallId: hall.id } })} isFav={isFavorite(hall.id)} onFav={() => toggleFavorite(hall.id)} />
              ))}
            </ScrollView>
          </View>
        )}

        {/* All Halls */}
        <View style={{ marginBottom: 32 }}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>كل القاعات</Text>
            <Text style={styles.seeAll}>{filtered.length} قاعة</Text>
          </View>
          <View style={{ paddingHorizontal: 16, gap: 12 }}>
            {loading
              ? [1, 2, 3].map(i => <Skeleton key={i} width="100%" height={100} radius={14} />)
              : filtered.map(hall => (
                <HallListCard
                  key={hall.id} hall={hall}
                  onPress={() => navigation.navigate('ExploreTab', { screen: 'HallDetails', params: { hallId: hall.id } })}
                  isFav={isFavorite(hall.id)}
                  onFav={() => toggleFavorite(hall.id)}
                />
              ))
            }
            {!loading && filtered.length === 0 && (
              <View style={{ alignItems: 'center', padding: 32 }}>
                <Text style={{ color: Colors.textSecondary }}>لا توجد قاعات متاحة حالياً</Text>
              </View>
            )}
          </View>
        </View>
      </ScrollView>
    </SafeScreen>
  );
}

function FeaturedCard({ hall, onPress, isFav, onFav }: { hall: Hall; onPress: () => void; isFav: boolean; onFav: () => void }) {
  return (
    <TouchableOpacity onPress={onPress} style={styles.featuredCard} activeOpacity={0.95}>
      <Image source={{ uri: hall.images?.[0] || 'https://placehold.co/300x200' }} style={styles.featuredImage} />
      <LinearGradient colors={['transparent', 'rgba(0,0,0,0.75)']} style={styles.featuredOverlay}>
        <TouchableOpacity onPress={onFav} style={styles.favBtn}>
          <Ionicons name={isFav ? 'heart' : 'heart-outline'} size={20} color={isFav ? '#FF4B6E' : Colors.white} />
        </TouchableOpacity>
        <View style={{ padding: 12 }}>
          <Text style={styles.featuredName}>{hall.name}</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 }}>
            <Ionicons name="location-outline" size={12} color={Colors.white} />
            <Text style={styles.featuredCity}>{hall.city}</Text>
            {hall.rating && <Stars rating={hall.rating} size={11} />}
          </View>
          <Text style={styles.featuredPrice}>{hall.hourlyRate?.toLocaleString()} ر.س/ساعة</Text>
        </View>
      </LinearGradient>
    </TouchableOpacity>
  );
}

function HallListCard({ hall, onPress, isFav, onFav }: { hall: Hall; onPress: () => void; isFav: boolean; onFav: () => void }) {
  return (
    <TouchableOpacity onPress={onPress} style={styles.listCard} activeOpacity={0.9}>
      <Image source={{ uri: hall.images?.[0] || 'https://placehold.co/120x90' }} style={styles.listImage} />
      <View style={{ flex: 1, padding: 12 }}>
        <Text style={styles.listName} numberOfLines={1}>{hall.name}</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 3 }}>
          <Ionicons name="location-outline" size={12} color={Colors.gray400} />
          <Text style={styles.listCity}>{hall.city}</Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 3 }}>
          <Ionicons name="people-outline" size={12} color={Colors.gray400} />
          <Text style={styles.listCity}>حتى {hall.capacity} ضيف</Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 6 }}>
          <Text style={styles.listPrice}>{hall.hourlyRate?.toLocaleString()} <Text style={{ fontSize: Typography.xs, color: Colors.textSecondary }}>ر.س/ساعة</Text></Text>
          {hall.rating && <Stars rating={hall.rating} size={12} />}
        </View>
      </View>
      <TouchableOpacity onPress={onFav} style={{ padding: 10, alignSelf: 'flex-start' }}>
        <Ionicons name={isFav ? 'heart' : 'heart-outline'} size={20} color={isFav ? '#FF4B6E' : Colors.gray300} />
      </TouchableOpacity>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 24 },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 },
  greeting: { fontSize: Typography.xl, fontWeight: Typography.bold, color: Colors.white },
  headerSub: { fontSize: Typography.sm, color: 'rgba(255,255,255,0.8)', marginTop: 2 },
  headerIconBtn: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center', justifyContent: 'center',
  },
  notifBadge: {
    position: 'absolute', top: -2, right: -2,
    width: 16, height: 16, borderRadius: 8,
    backgroundColor: Colors.error, alignItems: 'center', justifyContent: 'center',
  },
  notifBadgeText: { color: Colors.white, fontSize: 9, fontWeight: Typography.bold },
  searchBar: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: Colors.white, borderRadius: Radius.xl,
    paddingHorizontal: 14, paddingVertical: 12,
  },
  searchPlaceholder: { flex: 1, color: Colors.gray400, fontSize: Typography.base },
  typeChip: {
    flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 8,
    borderRadius: Radius.full, backgroundColor: Colors.white, borderWidth: 1, borderColor: Colors.border,
  },
  typeChipActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  typeChipText: { fontSize: Typography.sm, color: Colors.gray600, fontWeight: Typography.medium },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, marginBottom: 12 },
  sectionTitle: { fontSize: Typography.lg, fontWeight: Typography.bold, color: Colors.textPrimary },
  seeAll: { fontSize: Typography.sm, color: Colors.primary, fontWeight: Typography.medium },
  featuredCard: { width: 240, height: 180, borderRadius: Radius.xl, overflow: 'hidden', ...Shadow.md },
  featuredImage: { width: '100%', height: '100%' },
  featuredOverlay: { position: 'absolute', inset: 0, justifyContent: 'space-between', paddingTop: 10 },
  favBtn: { alignSelf: 'flex-end', padding: 8, backgroundColor: 'rgba(0,0,0,0.3)', borderRadius: 20, marginRight: 8 },
  featuredName: { color: Colors.white, fontSize: Typography.md, fontWeight: Typography.bold },
  featuredCity: { color: 'rgba(255,255,255,0.85)', fontSize: Typography.xs },
  featuredPrice: { color: Colors.white, fontSize: Typography.sm, fontWeight: Typography.semibold, marginTop: 4 },
  listCard: { flexDirection: 'row', backgroundColor: Colors.white, borderRadius: Radius.xl, overflow: 'hidden', ...Shadow.sm },
  listImage: { width: 110, height: 100 },
  listName: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary },
  listCity: { fontSize: Typography.xs, color: Colors.textSecondary },
  listPrice: { fontSize: Typography.md, fontWeight: Typography.bold, color: Colors.primary },
});

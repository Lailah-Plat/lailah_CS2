import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, Share } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card, StatusBadge, Button } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';
import { bookingsApi } from '../../api';
import type { Booking } from '../../types';

export default function BookingDetailsScreen() {
  const nav   = useNavigation<any>();
  const route = useRoute<any>();
  const { bookingId } = route.params;
  const [booking, setBooking] = useState<Booking | null>(null);
  const [loading, setLoading] = useState(true);
  const [cancelling, setCancelling] = useState(false);

  useEffect(() => {
    bookingsApi.getById(bookingId)
      .then(b => setBooking(b))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [bookingId]);

  async function handleCancel() {
    Alert.alert('إلغاء الحجز', 'هل أنت متأكد من إلغاء هذا الحجز؟', [
      { text: 'تراجع', style: 'cancel' },
      {
        text: 'إلغاء الحجز', style: 'destructive',
        onPress: async () => {
          setCancelling(true);
          try {
            await bookingsApi.cancel(bookingId, 'طلب العميل');
            setBooking(prev => prev ? { ...prev, status: 'cancelled' } : prev);
            Alert.alert('✅ تم الإلغاء', 'تم إلغاء حجزك بنجاح');
          } catch (e: any) {
            Alert.alert('خطأ', e.message);
          } finally { setCancelling(false); }
        },
      },
    ]);
  }

  if (loading) return <SafeScreen><View style={{ flex:1, alignItems:'center', justifyContent:'center' }}><Text style={{ color: Colors.textSecondary }}>جارٍ التحميل...</Text></View></SafeScreen>;
  if (!booking) return <SafeScreen><AppHeader title="الحجز" onBack={() => nav.goBack()} /><View style={{ flex:1, alignItems:'center', justifyContent:'center' }}><Text style={{ color: Colors.textSecondary }}>لم يُعثر على الحجز</Text></View></SafeScreen>;

  const canCancel = ['pending','pending_payment','confirmed'].includes(booking.status);

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader
        title="تفاصيل الحجز"
        onBack={() => nav.goBack()}
        rightAction={
          <TouchableOpacity onPress={() => Share.share({ message: `حجزي في ${booking.hallName} — رقم: ${booking.bookingRef || booking.id}` })}>
            <Ionicons name="share-outline" size={22} color={Colors.textPrimary} />
          </TouchableOpacity>
        }
      />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }} showsVerticalScrollIndicator={false}>

        {/* Status Banner */}
        <Card style={{ alignItems: 'center', paddingVertical: 20, gap: 8 }}>
          <StatusBadge status={booking.status} />
          <Text style={{ fontSize: Typography['2xl'], fontWeight: Typography.bold, color: Colors.textPrimary }}>{booking.hallName}</Text>
          {booking.bookingRef && <Text style={{ fontSize: Typography.sm, color: Colors.textSecondary }}>#{booking.bookingRef}</Text>}
        </Card>

        {/* Booking Info */}
        <Card style={{ gap: 12 }}>
          <Text style={styles.cardTitle}>تفاصيل الحجز</Text>
          <InfoRow icon="calendar-outline" label="تاريخ البدء" value={new Date(booking.startTime).toLocaleString('ar-SA', { weekday:'long', day:'numeric', month:'long', hour:'2-digit', minute:'2-digit' })} />
          <InfoRow icon="time-outline" label="تاريخ الانتهاء" value={new Date(booking.endTime).toLocaleString('ar-SA', { weekday:'long', day:'numeric', month:'long', hour:'2-digit', minute:'2-digit' })} />
          <InfoRow icon="people-outline" label="عدد الضيوف" value={`${booking.guests} ضيف`} />
          {booking.notes && <InfoRow icon="document-text-outline" label="ملاحظات" value={booking.notes} />}
        </Card>

        {/* Price */}
        <Card style={{ gap: 10 }}>
          <Text style={styles.cardTitle}>ملخص المبالغ</Text>
          {booking.hallAmount != null && <PriceRow label="إيجار القاعة" value={booking.hallAmount} />}
          {booking.servicesAmount != null && <PriceRow label="الخدمات الإضافية" value={booking.servicesAmount} />}
          {booking.vatAmount != null && <PriceRow label="ضريبة القيمة المضافة" value={booking.vatAmount} />}
          <View style={[styles.totalRow]}>
            <Text style={styles.totalLabel}>الإجمالي</Text>
            <Text style={styles.totalValue}>{Number(booking.totalAmount).toLocaleString()} ر.س</Text>
          </View>
        </Card>

        {/* Services */}
        {booking.services && booking.services.length > 0 && (
          <Card style={{ gap: 10 }}>
            <Text style={styles.cardTitle}>الخدمات المضافة</Text>
            {booking.services.map((s, i) => (
              <View key={i} style={{ flexDirection:'row', justifyContent:'space-between' }}>
                <Text style={{ fontSize: Typography.sm, color: Colors.textSecondary }}>{s.serviceName} × {s.quantity}</Text>
                <Text style={{ fontSize: Typography.sm, color: Colors.textPrimary, fontWeight: Typography.medium }}>{s.total?.toLocaleString()} ر.س</Text>
              </View>
            ))}
          </Card>
        )}

        {/* Actions */}
        <View style={{ gap: 10 }}>
          <Button label="عرض الفاتورة" onPress={() => nav.navigate('InvoiceView', { invoice: booking })} variant="outline" icon="receipt-outline" />
          {canCancel && (
            <Button label="إلغاء الحجز" onPress={handleCancel} loading={cancelling} variant="danger" icon="close-circle-outline" />
          )}
        </View>
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeScreen>
  );
}

function InfoRow({ icon, label, value }: { icon: string; label: string; value: string }) {
  return (
    <View style={{ flexDirection:'row', alignItems:'flex-start', gap: 10 }}>
      <Ionicons name={icon as any} size={16} color={Colors.primary} style={{ marginTop: 2 }} />
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: Typography.xs, color: Colors.textSecondary }}>{label}</Text>
        <Text style={{ fontSize: Typography.base, color: Colors.textPrimary, marginTop: 2 }}>{value}</Text>
      </View>
    </View>
  );
}
function PriceRow({ label, value }: { label: string; value: number }) {
  return (
    <View style={{ flexDirection:'row', justifyContent:'space-between' }}>
      <Text style={{ fontSize: Typography.sm, color: Colors.textSecondary }}>{label}</Text>
      <Text style={{ fontSize: Typography.sm, color: Colors.textPrimary }}>{value.toLocaleString()} ر.س</Text>
    </View>
  );
}
const styles = StyleSheet.create({
  cardTitle: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary, paddingBottom: 4, borderBottomWidth: 0.5, borderBottomColor: Colors.border },
  totalRow: { flexDirection:'row', justifyContent:'space-between', paddingTop: 10, borderTopWidth: 0.5, borderTopColor: Colors.border, marginTop: 4 },
  totalLabel: { fontSize: Typography.base, fontWeight: Typography.bold, color: Colors.textPrimary },
  totalValue: { fontSize: Typography.lg, fontWeight: Typography.bold, color: Colors.primary },
});

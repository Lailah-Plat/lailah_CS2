import React, { useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Share } from 'react-native';
import { useNavigation, useRoute, CommonActions } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, Button, Card } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';

export default function BookingConfirmScreen() {
  const nav   = useNavigation<any>();
  const route = useRoute<any>();
  const { booking } = route.params;

  function goHome() {
    nav.dispatch(CommonActions.reset({ index: 0, routes: [{ name: 'Main' }] }));
  }

  return (
    <SafeScreen bg={Colors.bg}>
      <View style={{ flex: 1, padding: 24, alignItems: 'center', justifyContent: 'center' }}>
        {/* Success Icon */}
        <View style={styles.successCircle}>
          <Ionicons name="checkmark" size={52} color={Colors.white} />
        </View>

        <Text style={styles.title}>تم الحجز بنجاح! 🎉</Text>
        <Text style={styles.subtitle}>سيصلك تأكيد الحجز على بريدك الإلكتروني</Text>

        {/* Booking Summary */}
        <Card style={{ width: '100%', marginTop: 24, gap: 10 }}>
          <Row label="القاعة"   value={booking?.hallName || '—'} />
          <Row label="الموعد"   value={booking?.startTime ? new Date(booking.startTime).toLocaleDateString('ar-SA', { day: 'numeric', month: 'long', year: 'numeric' }) : '—'} />
          <Row label="الضيوف"  value={booking?.guests ? `${booking.guests} ضيف` : '—'} />
          <Row label="الحالة"  value="مؤكد ✅" color={Colors.success} />
          <View style={{ borderTopWidth: 0.5, borderTopColor: Colors.border, paddingTop: 10 }}>
            <Row label="الإجمالي" value={`${Number(booking?.totalAmount || 0).toLocaleString()} ر.س`} bold />
          </View>
        </Card>

        <View style={{ width: '100%', gap: 10, marginTop: 24 }}>
          <Button label="عرض الفاتورة" onPress={() => nav.navigate('InvoiceView', { invoice: { ...booking } })} variant="outline" size="lg" icon="receipt-outline" />
          <Button label="العودة للرئيسية" onPress={goHome} size="lg" />
        </View>
      </View>
    </SafeScreen>
  );
}

function Row({ label, value, color, bold }: { label: string; value: string; color?: string; bold?: boolean }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
      <Text style={{ fontSize: Typography.sm, color: Colors.textSecondary }}>{label}</Text>
      <Text style={{ fontSize: Typography.sm, color: color || Colors.textPrimary, fontWeight: bold ? Typography.bold : Typography.medium }}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  successCircle: {
    width: 100, height: 100, borderRadius: 50, backgroundColor: Colors.success,
    alignItems: 'center', justifyContent: 'center', marginBottom: 20,
    shadowColor: Colors.success, shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3, shadowRadius: 16, elevation: 12,
  },
  title: { fontSize: Typography['3xl'], fontWeight: Typography.bold, color: Colors.textPrimary, textAlign: 'center' },
  subtitle: { fontSize: Typography.base, color: Colors.textSecondary, textAlign: 'center', marginTop: 8 },
});

import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Share } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card, Button } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';

export default function InvoiceViewScreen() {
  const nav   = useNavigation<any>();
  const route = useRoute<any>();
  const { invoice } = route.params;

  const items = invoice.services?.map((s: any) => ({
    name: s.serviceName || s.name, qty: s.quantity || 1, unitPrice: s.price || 0, total: s.total || 0,
  })) || [{ name: `إيجار ${invoice.hallName || 'القاعة'}`, qty: 1, unitPrice: invoice.totalAmount, total: invoice.totalAmount }];

  const subtotal  = items.reduce((a: number, i: any) => a + i.total, 0);
  const vatAmount = invoice.vatAmount || 0;
  const total     = invoice.totalAmount || subtotal + vatAmount;

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader
        title="الفاتورة"
        onBack={() => nav.goBack()}
        rightAction={
          <TouchableOpacity onPress={() => Share.share({ message: `فاتورة ليلة — المبلغ: ${total.toLocaleString()} ر.س` })}>
            <Ionicons name="share-outline" size={22} color={Colors.textPrimary} />
          </TouchableOpacity>
        }
      />
      <ScrollView contentContainerStyle={{ padding: 16 }} showsVerticalScrollIndicator={false}>
        <Card style={{ gap: 16 }}>
          {/* Header */}
          <View style={{ alignItems: 'center', paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: Colors.border, borderStyle: 'dashed' }}>
            <View style={styles.logo}><Text style={{ color: Colors.white, fontSize: 22, fontWeight: Typography.bold }}>ليلة</Text></View>
            <Text style={styles.invoiceTitle}>فـاتـورة ضريبية</Text>
            <Text style={{ fontSize: Typography.xs, color: Colors.textSecondary, marginTop: 4 }}>
              رقم الفاتورة: {invoice.invoiceRef || invoice.bookingRef || invoice.id}
            </Text>
            <Text style={{ fontSize: Typography.xs, color: Colors.textSecondary }}>
              التاريخ: {new Date(invoice.createdAt || invoice.issuedAt || Date.now()).toLocaleDateString('ar-SA')}
            </Text>
          </View>

          {/* Customer Info */}
          <View style={{ gap: 4 }}>
            <Text style={styles.sectionLabel}>بيانات العميل</Text>
            <Text style={styles.infoText}>{invoice.customerName || 'العميل'}</Text>
          </View>

          {/* Items Table */}
          <View style={{ gap: 0 }}>
            <Text style={styles.sectionLabel}>تفاصيل الخدمات</Text>
            <View style={styles.tableHeader}>
              <Text style={[styles.tableHead, { flex: 2 }]}>البيان</Text>
              <Text style={[styles.tableHead, { width: 40 }]}>الكمية</Text>
              <Text style={[styles.tableHead, { width: 80, textAlign: 'left' }]}>المبلغ</Text>
            </View>
            {items.map((item: any, i: number) => (
              <View key={i} style={[styles.tableRow, i % 2 === 0 && { backgroundColor: Colors.gray50 }]}>
                <Text style={[styles.tableCell, { flex: 2 }]} numberOfLines={2}>{item.name}</Text>
                <Text style={[styles.tableCell, { width: 40, textAlign: 'center' }]}>{item.qty}</Text>
                <Text style={[styles.tableCell, { width: 80, textAlign: 'left', color: Colors.primary }]}>{item.total?.toLocaleString()}</Text>
              </View>
            ))}
          </View>

          {/* Totals */}
          <View style={{ gap: 8, paddingTop: 12, borderTopWidth: 1, borderTopColor: Colors.border, borderStyle: 'dashed' }}>
            <TotalRow label="المجموع قبل الضريبة" value={subtotal} />
            {vatAmount > 0 && <TotalRow label="ضريبة القيمة المضافة 15%" value={vatAmount} />}
            <View style={[styles.totalFinal]}>
              <Text style={styles.totalFinalLabel}>الإجمالي المستحق</Text>
              <Text style={styles.totalFinalValue}>{total.toLocaleString()} ر.س</Text>
            </View>
          </View>

          {/* Footer */}
          <View style={{ alignItems: 'center', paddingTop: 16, borderTopWidth: 0.5, borderTopColor: Colors.border, gap: 4 }}>
            <Text style={{ fontSize: Typography.xs, color: Colors.textMuted }}>شكراً لاختيارك منصة ليلة 🌙</Text>
            <Text style={{ fontSize: Typography.xs, color: Colors.textMuted }}>info@lailah.sa | 920000000</Text>
          </View>
        </Card>

        <Button
          label="مشاركة الفاتورة"
          onPress={() => Share.share({ message: `فاتورة ليلة #${invoice.invoiceRef || invoice.id} — الإجمالي: ${total.toLocaleString()} ر.س` })}
          variant="outline"
          icon="share-outline"
          style={{ marginTop: 16 }}
        />
        <View style={{ height: 32 }} />
      </ScrollView>
    </SafeScreen>
  );
}

function TotalRow({ label, value }: { label: string; value: number }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
      <Text style={{ fontSize: Typography.sm, color: Colors.textSecondary }}>{label}</Text>
      <Text style={{ fontSize: Typography.sm, color: Colors.textPrimary, fontWeight: Typography.medium }}>{value.toLocaleString()} ر.س</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  logo: { width: 60, height: 60, borderRadius: 30, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  invoiceTitle: { fontSize: Typography.xl, fontWeight: Typography.bold, color: Colors.textPrimary },
  sectionLabel: { fontSize: Typography.xs, fontWeight: Typography.semibold, color: Colors.textMuted, textTransform: 'uppercase', marginBottom: 6 },
  infoText: { fontSize: Typography.base, color: Colors.textPrimary },
  tableHeader: { flexDirection: 'row', backgroundColor: Colors.primary, paddingHorizontal: 10, paddingVertical: 8, borderRadius: Radius.sm },
  tableHead: { fontSize: Typography.xs, color: Colors.white, fontWeight: Typography.semibold },
  tableRow: { flexDirection: 'row', paddingHorizontal: 10, paddingVertical: 10, borderBottomWidth: 0.5, borderBottomColor: Colors.border },
  tableCell: { fontSize: Typography.sm, color: Colors.textPrimary },
  totalFinal: { flexDirection: 'row', justifyContent: 'space-between', paddingTop: 10, borderTopWidth: 1.5, borderTopColor: Colors.primary },
  totalFinalLabel: { fontSize: Typography.base, fontWeight: Typography.bold, color: Colors.textPrimary },
  totalFinalValue: { fontSize: Typography.xl, fontWeight: Typography.bold, color: Colors.primary },
});

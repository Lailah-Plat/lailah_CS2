import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, Image } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { WebView } from 'react-native-webview';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Button, Card } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';
import { paymentApi } from '../../api';

const GATEWAYS = [
  { id: 'moyasar',  nameAr: 'مدى / بطاقات بنكية', icon: 'card-outline',    color: '#1A56DB' },
  { id: 'tabby',   nameAr: 'تابي — قسّم على 4',   icon: 'layers-outline',  color: '#3BB273' },
  { id: 'tamara',  nameAr: 'تمارة — ادفع لاحقاً', icon: 'time-outline',    color: '#FF6B35' },
  { id: 'hyperpay',nameAr: 'Apple Pay / Google Pay', icon: 'phone-portrait-outline', color: '#000' },
];

export default function BookingPaymentScreen() {
  const nav   = useNavigation<any>();
  const route = useRoute<any>();
  const { booking, amount } = route.params;

  const [selectedGateway, setSelectedGateway] = useState('moyasar');
  const [loading, setLoading]                 = useState(false);
  const [paymentUrl, setPaymentUrl]           = useState<string | null>(null);
  const [availableGateways, setAvailableGateways] = useState(GATEWAYS);

  useEffect(() => {
    paymentApi.getGateways().then(res => {
      if (res.gateways?.length) {
        setAvailableGateways(GATEWAYS.filter(g => res.gateways.includes(g.id)));
        setSelectedGateway(res.activeDefault || 'moyasar');
      }
    }).catch(() => {});
  }, []);

  async function handlePay() {
    setLoading(true);
    try {
      const session = await paymentApi.initPayment({
        bookingId: booking.id,
        amount,
        gateway: selectedGateway,
      });
      if (session.url) {
        setPaymentUrl(session.url);
      } else {
        // Simulate success for dev
        nav.navigate('BookingConfirmation', { booking: { ...booking, status: 'confirmed', totalAmount: amount } });
      }
    } catch (err: any) {
      Alert.alert('خطأ في الدفع', err.message || 'فشل بدء عملية الدفع');
    } finally { setLoading(false); }
  }

  // WebView for payment gateway redirect
  if (paymentUrl) {
    return (
      <SafeScreen>
        <AppHeader title="إتمام الدفع" onBack={() => setPaymentUrl(null)} />
        <WebView
          source={{ uri: paymentUrl }}
          onNavigationStateChange={state => {
            if (state.url.includes('success') || state.url.includes('callback')) {
              setPaymentUrl(null);
              nav.navigate('BookingConfirmation', { booking: { ...booking, status: 'confirmed', totalAmount: amount } });
            }
            if (state.url.includes('cancel') || state.url.includes('failed')) {
              setPaymentUrl(null);
              Alert.alert('تم إلغاء الدفع', 'يمكنك المحاولة مرة أخرى');
            }
          }}
        />
      </SafeScreen>
    );
  }

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="اختر طريقة الدفع" onBack={() => nav.goBack()} />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }} showsVerticalScrollIndicator={false}>

        {/* Amount Summary */}
        <Card style={{ alignItems: 'center', paddingVertical: 24 }}>
          <Text style={{ fontSize: Typography.sm, color: Colors.textSecondary, marginBottom: 6 }}>المبلغ الإجمالي</Text>
          <Text style={{ fontSize: 40, fontWeight: Typography.bold, color: Colors.primary }}>{Number(amount).toLocaleString()}</Text>
          <Text style={{ fontSize: Typography.base, color: Colors.textSecondary, marginTop: 2 }}>ريال سعودي</Text>
        </Card>

        {/* Gateway Selection */}
        <Text style={styles.sectionTitle}>طريقة الدفع</Text>
        {availableGateways.map(gw => (
          <TouchableOpacity key={gw.id} onPress={() => setSelectedGateway(gw.id)} activeOpacity={0.8}>
            <Card style={[styles.gwCard, selectedGateway === gw.id && styles.gwCardActive]}>
              <View style={[styles.gwIcon, { backgroundColor: gw.color + '18' }]}>
                <Ionicons name={gw.icon as any} size={22} color={gw.color} />
              </View>
              <Text style={[styles.gwName, selectedGateway === gw.id && { color: Colors.primary }]}>{gw.nameAr}</Text>
              <View style={[styles.radioOuter, selectedGateway === gw.id && { borderColor: Colors.primary }]}>
                {selectedGateway === gw.id && <View style={styles.radioInner} />}
              </View>
            </Card>
          </TouchableOpacity>
        ))}

        <View style={styles.secureRow}>
          <Ionicons name="shield-checkmark-outline" size={16} color={Colors.success} />
          <Text style={styles.secureText}>جميع المدفوعات مشفرة وآمنة بالكامل</Text>
        </View>

        <Button label={`ادفع ${Number(amount).toLocaleString()} ر.س`} onPress={handlePay} loading={loading} size="lg" icon="card-outline" />
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeScreen>
  );
}

const styles = StyleSheet.create({
  sectionTitle: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary },
  gwCard: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  gwCardActive: { borderWidth: 1.5, borderColor: Colors.primary },
  gwIcon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  gwName: { flex: 1, fontSize: Typography.base, color: Colors.textPrimary, fontWeight: Typography.medium },
  radioOuter: { width: 22, height: 22, borderRadius: 11, borderWidth: 2, borderColor: Colors.gray300, alignItems: 'center', justifyContent: 'center' },
  radioInner: { width: 12, height: 12, borderRadius: 6, backgroundColor: Colors.primary },
  secureRow: { flexDirection: 'row', alignItems: 'center', gap: 6, justifyContent: 'center', paddingVertical: 4 },
  secureText: { fontSize: Typography.xs, color: Colors.textSecondary },
});

import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card, Button } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';
import { hallsApi } from '../../api';
import type { Service } from '../../types';

export default function BookingServicesScreen() {
  const nav   = useNavigation<any>();
  const route = useRoute<any>();
  const { hallId, bookingData } = route.params;
  const [services, setServices] = useState<Service[]>([]);
  const [selected, setSelected] = useState<Record<string, number>>({});

  useEffect(() => {
    hallsApi.getServices(hallId).then(s => setServices(Array.isArray(s) ? s : [])).catch(() => {});
  }, [hallId]);

  function toggle(svc: Service) {
    setSelected(prev => {
      const next = { ...prev };
      if (next[String(svc.id)]) delete next[String(svc.id)];
      else next[String(svc.id)] = 1;
      return next;
    });
  }

  function changeQty(id: string, delta: number) {
    setSelected(prev => {
      const next = { ...prev };
      const cur  = next[id] || 0;
      const nxt  = Math.max(0, cur + delta);
      if (nxt === 0) delete next[id];
      else next[id] = nxt;
      return next;
    });
  }

  const selectedServices = services
    .filter(s => selected[String(s.id)])
    .map(s => ({ serviceId: s.id, serviceName: s.name, quantity: selected[String(s.id)], price: s.price, total: s.price * selected[String(s.id)] }));

  const servicesTotal = selectedServices.reduce((a, s) => a + s.total, 0);
  const grandTotal    = (bookingData?.hallAmount || 0) + servicesTotal + (bookingData?.vatAmount || 0);

  function proceed() {
    const finalBooking = { ...bookingData, services: selectedServices, servicesAmount: servicesTotal, totalAmount: grandTotal };
    nav.navigate('BookingPayment', { booking: finalBooking, amount: grandTotal });
  }

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="إضافة خدمات (اختياري)" onBack={() => nav.goBack()} />
      <FlatList
        data={services}
        keyExtractor={s => String(s.id)}
        contentContainerStyle={{ padding: 16, gap: 10, flexGrow: 1 }}
        ListHeaderComponent={<Text style={{ fontSize: Typography.sm, color: Colors.textSecondary, marginBottom: 4 }}>اختر الخدمات التي تريد إضافتها لحجزك</Text>}
        ListEmptyComponent={<View style={{ alignItems: 'center', padding: 32 }}><Text style={{ color: Colors.textSecondary }}>لا توجد خدمات إضافية لهذه القاعة</Text></View>}
        renderItem={({ item: svc }) => {
          const qty = selected[String(svc.id)] || 0;
          const isSelected = qty > 0;
          return (
            <Card style={[styles.svcCard, isSelected && styles.svcCardActive]}>
              <View style={styles.svcInfo}>
                <View style={styles.svcIcon}><Ionicons name="construct-outline" size={20} color={isSelected ? Colors.primary : Colors.gray400} /></View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.svcName}>{svc.name}</Text>
                  {svc.description && <Text style={styles.svcDesc} numberOfLines={1}>{svc.description}</Text>}
                  <Text style={styles.svcPrice}>{svc.price?.toLocaleString()} ر.س/{svc.unit || 'وحدة'}</Text>
                </View>
              </View>
              {isSelected ? (
                <View style={styles.qtyRow}>
                  <TouchableOpacity onPress={() => changeQty(String(svc.id), -1)} style={styles.qtyBtn}>
                    <Ionicons name="remove" size={18} color={Colors.primary} />
                  </TouchableOpacity>
                  <Text style={styles.qtyText}>{qty}</Text>
                  <TouchableOpacity onPress={() => changeQty(String(svc.id), 1)} style={styles.qtyBtn}>
                    <Ionicons name="add" size={18} color={Colors.primary} />
                  </TouchableOpacity>
                </View>
              ) : (
                <TouchableOpacity onPress={() => toggle(svc)} style={styles.addBtn}>
                  <Ionicons name="add" size={18} color={Colors.primary} />
                  <Text style={styles.addText}>إضافة</Text>
                </TouchableOpacity>
              )}
            </Card>
          );
        }}
      />

      {/* Bottom bar */}
      <View style={styles.bottomBar}>
        {servicesTotal > 0 && (
          <Text style={{ fontSize: Typography.sm, color: Colors.textSecondary }}>
            الخدمات: <Text style={{ color: Colors.primary, fontWeight: Typography.semibold }}>{servicesTotal.toLocaleString()} ر.س</Text>
          </Text>
        )}
        <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
          <Button label="تخطي" onPress={() => nav.navigate('BookingPayment', { booking: bookingData, amount: bookingData?.totalAmount || 0 })} variant="outline" style={{ flex: 1 }} />
          <Button label="متابعة" onPress={proceed} style={{ flex: 2 }} icon="arrow-back" />
        </View>
      </View>
    </SafeScreen>
  );
}

const styles = StyleSheet.create({
  svcCard: { gap: 10 },
  svcCardActive: { borderWidth: 1.5, borderColor: Colors.primary },
  svcInfo: { flexDirection: 'row', gap: 10, alignItems: 'flex-start' },
  svcIcon: { width: 40, height: 40, borderRadius: 10, backgroundColor: Colors.gray50, alignItems: 'center', justifyContent: 'center' },
  svcName: { fontSize: Typography.base, fontWeight: Typography.medium, color: Colors.textPrimary },
  svcDesc: { fontSize: Typography.xs, color: Colors.textSecondary, marginTop: 2 },
  svcPrice: { fontSize: Typography.sm, color: Colors.primary, fontWeight: Typography.semibold, marginTop: 4 },
  qtyRow: { flexDirection: 'row', alignItems: 'center', gap: 16, justifyContent: 'center', marginTop: 4 },
  qtyBtn: { width: 32, height: 32, borderRadius: 16, borderWidth: 1.5, borderColor: Colors.primary, alignItems: 'center', justifyContent: 'center' },
  qtyText: { fontSize: Typography.lg, fontWeight: Typography.bold, color: Colors.textPrimary, minWidth: 24, textAlign: 'center' },
  addBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, borderWidth: 1.5, borderColor: Colors.primary, borderRadius: Radius.xl, paddingHorizontal: 12, paddingVertical: 6, alignSelf: 'flex-end' },
  addText: { fontSize: Typography.sm, color: Colors.primary, fontWeight: Typography.medium },
  bottomBar: { backgroundColor: Colors.white, padding: 16, borderTopWidth: 0.5, borderTopColor: Colors.border },
});

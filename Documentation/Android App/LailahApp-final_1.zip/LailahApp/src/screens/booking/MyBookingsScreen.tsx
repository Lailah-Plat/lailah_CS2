import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, RefreshControl } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card, StatusBadge, EmptyState } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';
import { bookingsApi } from '../../api';
import type { Booking } from '../../types';

const FILTERS = [
  { key: 'all', label: 'الكل' },
  { key: 'pending', label: 'قيد المراجعة' },
  { key: 'confirmed', label: 'مؤكدة' },
  { key: 'completed', label: 'مكتملة' },
  { key: 'cancelled', label: 'ملغاة' },
];

export default function MyBookingsScreen() {
  const nav = useNavigation<any>();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { load(); }, []);
  async function load() {
    try { const res = await bookingsApi.getAll(); setBookings(res.bookings || []); }
    catch {} finally { setLoading(false); setRefreshing(false); }
  }

  const filtered = filter === 'all' ? bookings : bookings.filter(b => b.status === filter);

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader
        title="حجوزاتي"
        rightAction={
          <TouchableOpacity onPress={() => nav.navigate('ServiceRequests')} style={{ paddingHorizontal: 8 }}>
            <Text style={{ color: Colors.primary, fontSize: Typography.xs, fontWeight: Typography.medium }}>طلبات الخدمات</Text>
          </TouchableOpacity>
        }
      />

      {/* Filter tabs */}
      <FlatList
        data={FILTERS}
        horizontal showsHorizontalScrollIndicator={false}
        keyExtractor={i => i.key}
        contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 12, gap: 8 }}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => setFilter(item.key)} style={[styles.filterChip, filter === item.key && styles.filterActive]}>
            <Text style={[styles.filterText, filter === item.key && { color: Colors.white }]}>{item.label}</Text>
          </TouchableOpacity>
        )}
      />

      <FlatList
        data={filtered}
        keyExtractor={b => String(b.id)}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} colors={[Colors.primary]} />}
        contentContainerStyle={{ padding: 16, gap: 12, flexGrow: 1 }}
        ListEmptyComponent={<EmptyState icon="calendar-outline" title="لا توجد حجوزات" subtitle="لم تقم بأي حجز بعد" action={{ label: 'استعرض القاعات', onPress: () => nav.navigate('ExploreTab') }} />}
        renderItem={({ item: b }) => (
          <TouchableOpacity onPress={() => nav.navigate('BookingDetails', { bookingId: b.id })} activeOpacity={0.85}>
            <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'flex-start' }}>
              <View style={styles.bookingIcon}>
                <Ionicons name="calendar" size={22} color={Colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.hallName} numberOfLines={1}>{b.hallName}</Text>
                <Text style={styles.bookingDate}>
                  {new Date(b.startTime).toLocaleDateString('ar-SA', { weekday: 'short', day: 'numeric', month: 'long' })}
                </Text>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 6 }}>
                  <StatusBadge status={b.status} />
                  <Text style={styles.amount}>{Number(b.totalAmount).toLocaleString()} ر.س</Text>
                </View>
              </View>
              <Ionicons name="chevron-back" size={16} color={Colors.gray300} style={{ marginTop: 4 }} />
            </Card>
          </TouchableOpacity>
        )}
      />
    </SafeScreen>
  );
}

const styles = StyleSheet.create({
  filterChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: Radius.full, backgroundColor: Colors.white, borderWidth: 1, borderColor: Colors.border },
  filterActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  filterText: { fontSize: Typography.sm, color: Colors.textSecondary, fontWeight: Typography.medium },
  bookingIcon: { width: 44, height: 44, borderRadius: 12, backgroundColor: Colors.primaryBg, alignItems: 'center', justifyContent: 'center' },
  hallName: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary },
  bookingDate: { fontSize: Typography.sm, color: Colors.textSecondary, marginTop: 3 },
  amount: { fontSize: Typography.sm, color: Colors.primary, fontWeight: Typography.semibold },
});

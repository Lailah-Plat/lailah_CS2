import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, Platform } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';
import { SafeScreen, AppHeader, Button, Input, Card } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';
import { bookingsApi } from '../../api';
import type { Hall } from '../../types';

export default function CreateBookingScreen() {
  const nav   = useNavigation<any>();
  const route = useRoute<any>();
  const hall: Hall = route.params?.hall;

  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate]     = useState(new Date(Date.now() + 3 * 3600000));
  const [guests, setGuests]       = useState('50');
  const [notes, setNotes]         = useState('');
  const [showStart, setShowStart] = useState(false);
  const [showEnd, setShowEnd]     = useState(false);
  const [loading, setLoading]     = useState(false);

  const hours     = Math.max(1, Math.ceil((endDate.getTime() - startDate.getTime()) / 3600000));
  const subtotal  = (hall?.hourlyRate || 0) * hours;
  const vatAmount = hall?.isVatEnabled ? subtotal * ((hall.vatRate || 15) / 100) : 0;
  const total     = subtotal + vatAmount;

  async function handleBook() {
    if (!hall) return;
    if (Number(guests) < 1) return Alert.alert('', 'أدخل عدد الضيوف');
    if (endDate <= startDate) return Alert.alert('', 'وقت الانتهاء يجب أن يكون بعد وقت البدء');

    setLoading(true);
    try {
      const booking = await bookingsApi.create({
        hallId: hall.id,
        startTime: startDate.toISOString(),
        endTime: endDate.toISOString(),
        guests: Number(guests),
        notes: notes || undefined,
      });
      nav.navigate('BookingPayment', { booking, amount: total });
    } catch (err: any) {
      Alert.alert('خطأ', err.message || 'فشل إنشاء الحجز');
    } finally { setLoading(false); }
  }

  const fmtDate = (d: Date) => d.toLocaleDateString('ar-SA', { weekday: 'short', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="تفاصيل الحجز" onBack={() => nav.goBack()} />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }} showsVerticalScrollIndicator={false}>

        {/* Hall Summary */}
        <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <View style={{ width: 52, height: 52, borderRadius: 14, backgroundColor: Colors.primaryBg, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="business" size={26} color={Colors.primary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary }}>{hall?.name}</Text>
            <Text style={{ fontSize: Typography.sm, color: Colors.textSecondary }}>{hall?.city} · حتى {hall?.capacity} ضيف</Text>
          </View>
        </Card>

        {/* Date & Time */}
        <Card style={{ gap: 14 }}>
          <Text style={styles.sectionTitle}>موعد الحجز</Text>

          <TouchableOpacity onPress={() => setShowStart(true)} style={styles.dateRow}>
            <Ionicons name="time-outline" size={18} color={Colors.primary} />
            <View style={{ flex: 1 }}>
              <Text style={styles.dateLabel}>وقت البدء</Text>
              <Text style={styles.dateValue}>{fmtDate(startDate)}</Text>
            </View>
            <Ionicons name="chevron-back" size={16} color={Colors.gray300} />
          </TouchableOpacity>

          <TouchableOpacity onPress={() => setShowEnd(true)} style={styles.dateRow}>
            <Ionicons name="time-outline" size={18} color={Colors.error} />
            <View style={{ flex: 1 }}>
              <Text style={styles.dateLabel}>وقت الانتهاء</Text>
              <Text style={styles.dateValue}>{fmtDate(endDate)}</Text>
            </View>
            <Ionicons name="chevron-back" size={16} color={Colors.gray300} />
          </TouchableOpacity>

          <View style={styles.durationBadge}>
            <Ionicons name="hourglass-outline" size={14} color={Colors.primary} />
            <Text style={{ fontSize: Typography.sm, color: Colors.primary, fontWeight: Typography.medium }}>المدة: {hours} ساعة</Text>
          </View>
        </Card>

        {showStart && (
          <DateTimePicker value={startDate} mode="datetime" display="default" minimumDate={new Date()}
            onChange={(_, d) => { setShowStart(false); if (d) setStartDate(d); }} />
        )}
        {showEnd && (
          <DateTimePicker value={endDate} mode="datetime" display="default" minimumDate={startDate}
            onChange={(_, d) => { setShowEnd(false); if (d) setEndDate(d); }} />
        )}

        {/* Guests */}
        <Input
          label="عدد الضيوف"
          placeholder={`1 - ${hall?.capacity}`}
          value={guests}
          onChangeText={setGuests}
          keyboardType="number-pad"
          icon="people-outline"
        />

        {/* Notes */}
        <Input
          label="ملاحظات (اختياري)"
          placeholder="أي متطلبات أو ملاحظات خاصة..."
          value={notes}
          onChangeText={setNotes}
          multiline numberOfLines={3}
          icon="document-text-outline"
        />

        {/* Price Summary */}
        <Card style={{ gap: 8 }}>
          <Text style={styles.sectionTitle}>ملخص الأسعار</Text>
          <PriceLine label={`${hall?.hourlyRate?.toLocaleString()} ر.س × ${hours} ساعة`} value={subtotal} />
          {vatAmount > 0 && <PriceLine label={`ضريبة القيمة المضافة (${hall?.vatRate || 15}%)`} value={vatAmount} />}
          <View style={[styles.priceLine, { marginTop: 8, paddingTop: 12, borderTopWidth: 0.5, borderTopColor: Colors.border }]}>
            <Text style={{ fontSize: Typography.lg, fontWeight: Typography.bold, color: Colors.textPrimary }}>الإجمالي</Text>
            <Text style={{ fontSize: Typography.xl, fontWeight: Typography.bold, color: Colors.primary }}>{total.toLocaleString()} ر.س</Text>
          </View>
        </Card>

        <Button label="المتابعة للدفع" onPress={handleBook} loading={loading} size="lg" icon="card-outline" />
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeScreen>
  );
}

function PriceLine({ label, value }: { label: string; value: number }) {
  return (
    <View style={styles.priceLine}>
      <Text style={{ fontSize: Typography.sm, color: Colors.textSecondary }}>{label}</Text>
      <Text style={{ fontSize: Typography.sm, fontWeight: Typography.medium, color: Colors.textPrimary }}>{value.toLocaleString()} ر.س</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  sectionTitle: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary, marginBottom: 4 },
  dateRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 6 },
  dateLabel: { fontSize: Typography.xs, color: Colors.textSecondary },
  dateValue: { fontSize: Typography.base, color: Colors.textPrimary, fontWeight: Typography.medium, marginTop: 2 },
  durationBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: Colors.primaryBg, paddingHorizontal: 12, paddingVertical: 7, borderRadius: Radius.full, alignSelf: 'flex-start' },
  priceLine: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
});

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  TextInput, RefreshControl, Modal, ScrollView,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, Card, Stars, StatusBadge, EmptyState, Skeleton } from '../../components/common';
import { Colors, Typography, Radius, Spacing } from '../../theme';
import { hallsApi, servicesApi } from '../../api';
import { useFavoritesStore } from '../../store';
import type { Hall, Service } from '../../types';

const CITIES = ['الكل','الرياض','جدة','مكة المكرمة','المدينة المنورة','الدمام','الخبر','أبها','تبوك'];
const TYPES  = ['الكل','أفراح','مؤتمرات','أعياد ميلاد','تخرج','أعمال'];
const TABS   = [{ id: 'halls', label: 'القاعات' }, { id: 'services', label: 'الخدمات المساندة' }];

export default function ExploreScreen() {
  const nav = useNavigation<any>();
  const { isFavorite, toggleFavorite } = useFavoritesStore();
  const [activeTab, setActiveTab]   = useState('halls');
  const [search, setSearch]         = useState('');
  const [halls, setHalls]           = useState<Hall[]>([]);
  const [services, setServices]     = useState<Service[]>([]);
  const [loading, setLoading]       = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filterVisible, setFilterVisible] = useState(false);
  const [selectedCity, setSelectedCity]   = useState('الكل');
  const [selectedType, setSelectedType]   = useState('الكل');

  useEffect(() => { load(); }, [activeTab]);

  async function load() {
    setLoading(true);
    try {
      if (activeTab === 'halls') {
        const res = await hallsApi.getAll({
          city: selectedCity !== 'الكل' ? selectedCity : undefined,
          search: search || undefined,
        });
        setHalls(res.halls || []);
      } else {
        const res = await servicesApi.getAll({ search: search || undefined });
        setServices(res.services || []);
      }
    } catch {}
    finally { setLoading(false); setRefreshing(false); }
  }

  const filteredHalls = halls.filter(h =>
    (!search || h.name.includes(search) || h.city.includes(search)) &&
    (selectedCity === 'الكل' || h.city === selectedCity) &&
    (selectedType === 'الكل' || h.type === selectedType)
  );

  const filteredServices = services.filter(s =>
    !search || s.name.includes(search) || s.category?.includes(search)
  );

  return (
    <SafeScreen bg={Colors.bg}>
      {/* Search Header */}
      <View style={styles.searchHeader}>
        <View style={styles.searchRow}>
          <View style={styles.searchBox}>
            <Ionicons name="search" size={18} color={Colors.gray400} />
            <TextInput
              style={styles.searchInput}
              placeholder={activeTab === 'halls' ? 'ابحث عن قاعة...' : 'ابحث عن خدمة...'}
              placeholderTextColor={Colors.gray400}
              value={search}
              onChangeText={setSearch}
              onSubmitEditing={load}
              textAlign="right"
            />
            {search.length > 0 && (
              <TouchableOpacity onPress={() => { setSearch(''); }}>
                <Ionicons name="close-circle" size={18} color={Colors.gray400} />
              </TouchableOpacity>
            )}
          </View>
          <TouchableOpacity onPress={() => setFilterVisible(true)} style={styles.filterBtn}>
            <Ionicons name="options-outline" size={20} color={Colors.primary} />
          </TouchableOpacity>
        </View>

        {/* Tabs */}
        <View style={styles.tabs}>
          {TABS.map(t => (
            <TouchableOpacity key={t.id} onPress={() => setActiveTab(t.id)} style={[styles.tab, activeTab === t.id && styles.tabActive]}>
              <Text style={[styles.tabText, activeTab === t.id && styles.tabTextActive]}>{t.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Results */}
      {activeTab === 'halls' ? (
        <FlatList
          data={loading ? [1,2,3,4] as any[] : filteredHalls}
          keyExtractor={(_, i) => String(i)}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} colors={[Colors.primary]} />}
          contentContainerStyle={{ padding: 16, gap: 12, flexGrow: 1 }}
          numColumns={1}
          ListHeaderComponent={
            <Text style={styles.resultCount}>
              {loading ? '' : `${filteredHalls.length} قاعة متاحة`}
            </Text>
          }
          ListEmptyComponent={!loading ? <EmptyState icon="business-outline" title="لا توجد قاعات" subtitle="جرّب تغيير معايير البحث" /> : null}
          renderItem={({ item: hall }) =>
            loading ? <Skeleton width="100%" height={100} radius={14} /> : (
              <HallCard hall={hall} onPress={() => nav.navigate('HallDetails', { hallId: hall.id })} isFav={isFavorite(hall.id)} onFav={() => toggleFavorite(hall.id)} />
            )
          }
        />
      ) : (
        <FlatList
          data={loading ? [1,2,3] as any[] : filteredServices}
          keyExtractor={(_, i) => String(i)}
          contentContainerStyle={{ padding: 16, gap: 12, flexGrow: 1 }}
          ListEmptyComponent={!loading ? <EmptyState icon="construct-outline" title="لا توجد خدمات" subtitle="جرّب تغيير معايير البحث" /> : null}
          renderItem={({ item: svc }) =>
            loading ? <Skeleton width="100%" height={90} radius={14} /> : (
              <ServiceCard service={svc} onPress={() => nav.navigate('ServiceDetails', { service: svc })} />
            )
          }
        />
      )}

      {/* Filter Modal */}
      <Modal visible={filterVisible} animationType="slide" transparent onRequestClose={() => setFilterVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalSheet}>
            <View style={styles.modalHandle} />
            <Text style={styles.modalTitle}>تصفية النتائج</Text>

            <Text style={styles.filterLabel}>المدينة</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingVertical: 4 }}>
              {CITIES.map(c => (
                <TouchableOpacity key={c} onPress={() => setSelectedCity(c)} style={[styles.chip, selectedCity === c && styles.chipActive]}>
                  <Text style={[styles.chipText, selectedCity === c && { color: Colors.white }]}>{c}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            <Text style={[styles.filterLabel, { marginTop: 16 }]}>نوع القاعة</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingVertical: 4 }}>
              {TYPES.map(t => (
                <TouchableOpacity key={t} onPress={() => setSelectedType(t)} style={[styles.chip, selectedType === t && styles.chipActive]}>
                  <Text style={[styles.chipText, selectedType === t && { color: Colors.white }]}>{t}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            <TouchableOpacity onPress={() => { setFilterVisible(false); load(); }} style={styles.applyBtn}>
              <Text style={styles.applyText}>تطبيق الفلتر</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => { setSelectedCity('الكل'); setSelectedType('الكل'); }} style={{ alignItems: 'center', paddingVertical: 12 }}>
              <Text style={{ color: Colors.textSecondary, fontSize: Typography.sm }}>مسح الفلتر</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeScreen>
  );
}

function HallCard({ hall, onPress, isFav, onFav }: { hall: Hall; onPress: () => void; isFav: boolean; onFav: () => void }) {
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.88}>
      <Card style={{ flexDirection: 'row', gap: 12, padding: 0, overflow: 'hidden' }}>
        <View style={{ width: 110, height: 100, backgroundColor: Colors.gray100 }}>
          {hall.images?.[0] && (
            <View style={{ flex: 1, backgroundColor: Colors.primaryBg, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="business" size={32} color={Colors.primaryLight} />
            </View>
          )}
        </View>
        <View style={{ flex: 1, padding: 12 }}>
          <Text style={{ fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary }} numberOfLines={1}>{hall.name}</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 3 }}>
            <Ionicons name="location-outline" size={12} color={Colors.gray400} />
            <Text style={{ fontSize: Typography.xs, color: Colors.textSecondary }}>{hall.city}</Text>
            <Text style={{ color: Colors.gray300 }}>·</Text>
            <Ionicons name="people-outline" size={12} color={Colors.gray400} />
            <Text style={{ fontSize: Typography.xs, color: Colors.textSecondary }}>{hall.capacity} ضيف</Text>
          </View>
          {hall.rating && <Stars rating={hall.rating} size={12} />}
          <Text style={{ fontSize: Typography.md, fontWeight: Typography.bold, color: Colors.primary, marginTop: 4 }}>
            {hall.hourlyRate?.toLocaleString()} <Text style={{ fontSize: Typography.xs, color: Colors.textSecondary }}>ر.س/ساعة</Text>
          </Text>
        </View>
        <TouchableOpacity onPress={onFav} style={{ padding: 10, alignSelf: 'flex-start' }}>
          <Ionicons name={isFav ? 'heart' : 'heart-outline'} size={20} color={isFav ? '#FF4B6E' : Colors.gray300} />
        </TouchableOpacity>
      </Card>
    </TouchableOpacity>
  );
}

function ServiceCard({ service, onPress }: { service: Service; onPress: () => void }) {
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.88}>
      <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
        <View style={{ width: 52, height: 52, borderRadius: 14, backgroundColor: Colors.primaryBg, alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name="construct-outline" size={24} color={Colors.primary} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary }}>{service.name}</Text>
          <Text style={{ fontSize: Typography.xs, color: Colors.textSecondary, marginTop: 2 }}>{service.category}</Text>
          <Text style={{ fontSize: Typography.base, fontWeight: Typography.bold, color: Colors.primary, marginTop: 4 }}>
            {service.price?.toLocaleString()} ر.س
          </Text>
        </View>
        <Ionicons name="chevron-back" size={16} color={Colors.gray300} />
      </Card>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  searchHeader: { backgroundColor: Colors.white, paddingHorizontal: 16, paddingTop: 12, paddingBottom: 0, borderBottomWidth: 0.5, borderBottomColor: Colors.border },
  searchRow: { flexDirection: 'row', gap: 10, marginBottom: 12 },
  searchBox: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: Colors.gray50, borderRadius: Radius.xl, paddingHorizontal: 12, height: 44, borderWidth: 1, borderColor: Colors.border },
  searchInput: { flex: 1, fontSize: Typography.base, color: Colors.textPrimary },
  filterBtn: { width: 44, height: 44, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.white },
  tabs: { flexDirection: 'row', gap: 0 },
  tab: { flex: 1, paddingVertical: 12, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabActive: { borderBottomColor: Colors.primary },
  tabText: { fontSize: Typography.base, color: Colors.gray400, fontWeight: Typography.medium },
  tabTextActive: { color: Colors.primary, fontWeight: Typography.semibold },
  resultCount: { fontSize: Typography.sm, color: Colors.textSecondary, marginBottom: 4 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  modalSheet: { backgroundColor: Colors.white, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 40 },
  modalHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: Colors.gray200, alignSelf: 'center', marginBottom: 16 },
  modalTitle: { fontSize: Typography.xl, fontWeight: Typography.bold, color: Colors.textPrimary, marginBottom: 20 },
  filterLabel: { fontSize: Typography.sm, fontWeight: Typography.semibold, color: Colors.textSecondary, marginBottom: 8 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: Radius.full, backgroundColor: Colors.gray50, borderWidth: 1, borderColor: Colors.border },
  chipActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  chipText: { fontSize: Typography.sm, color: Colors.textSecondary },
  applyBtn: { backgroundColor: Colors.primary, borderRadius: Radius.xl, padding: 14, alignItems: 'center', marginTop: 24 },
  applyText: { color: Colors.white, fontWeight: Typography.semibold, fontSize: Typography.base },
});

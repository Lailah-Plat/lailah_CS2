import React, { useEffect, useState } from 'react';
import { FlatList, View, Text, StyleSheet } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { SafeScreen, AppHeader, Card, Stars, Avatar, EmptyState } from '../../components/common';
import { Colors, Typography } from '../../theme';
import { hallsApi } from '../../api';

export default function HallReviewsScreen() {
  const nav   = useNavigation<any>();
  const route = useRoute<any>();
  const { hallId, hallName } = route.params;
  const [reviews, setReviews] = useState<any[]>([]);

  useEffect(() => {
    hallsApi.getReviews(hallId).then(r => setReviews(Array.isArray(r) ? r : r?.reviews || [])).catch(() => {});
  }, [hallId]);

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title={`تقييمات ${hallName}`} onBack={() => nav.goBack()} />
      <FlatList
        data={reviews}
        keyExtractor={(r, i) => String(r.id || i)}
        contentContainerStyle={{ padding: 16, gap: 10, flexGrow: 1 }}
        ListEmptyComponent={<EmptyState icon="star-outline" title="لا توجد تقييمات" subtitle="كن أول من يقيّم هذه القاعة" />}
        renderItem={({ item: r }) => (
          <Card style={{ gap: 8 }}>
            <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}>
              <Avatar name={r.customerName} size={38} />
              <View style={{ flex: 1 }}>
                <Text style={styles.reviewer}>{r.customerName || 'مستخدم'}</Text>
                <Text style={styles.date}>{new Date(r.createdAt).toLocaleDateString('ar-SA')}</Text>
              </View>
              <Stars rating={r.rating} size={14} />
            </View>
            {r.comment && <Text style={styles.comment}>{r.comment}</Text>}
          </Card>
        )}
      />
    </SafeScreen>
  );
}
const styles = StyleSheet.create({
  reviewer: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary },
  date: { fontSize: Typography.xs, color: Colors.textSecondary },
  comment: { fontSize: Typography.base, color: Colors.textSecondary, lineHeight: 24 },
});

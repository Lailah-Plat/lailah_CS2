import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Image, Dimensions, Alert, Share,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeScreen, Button, Stars, StatusBadge, Card } from '../../components/common';
import { Colors, Typography, Radius, Shadow } from '../../theme';
import { hallsApi } from '../../api';
import { useFavoritesStore } from '../../store';
import type { Hall, Service } from '../../types';

const { width } = Dimensions.get('window');

export default function HallDetailsScreen() {
  const nav    = useNavigation<any>();
  const route  = useRoute<any>();
  const { hallId } = route.params;
  const { isFavorite, toggleFavorite } = useFavoritesStore();

  const [hall, setHall]         = useState<Hall | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading]   = useState(true);
  const [imgIndex, setImgIndex] = useState(0);
  const [activeSection, setActiveSection] = useState<'info' | 'services' | 'reviews'>('info');

  useEffect(() => {
    hallsApi.getById(hallId).then(h => { setHall(h); setLoading(false); }).catch(() => setLoading(false));
    hallsApi.getServices(hallId).then(s => setServices(Array.isArray(s) ? s : [])).catch(() => {});
  }, [hallId]);

  if (loading || !hall) {
    return (
      <SafeScreen>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: Colors.textSecondary }}>جارٍ التحميل...</Text>
        </View>
      </SafeScreen>
    );
  }

  const images = hall.images?.length ? hall.images : ['https://placehold.co/400x250'];
  const isFav  = isFavorite(hall.id);

  return (
    <SafeScreen bg={Colors.white}>
      <ScrollView showsVerticalScrollIndicator={false}>

        {/* Image Gallery */}
        <View style={{ position: 'relative' }}>
          <ScrollView
            horizontal pagingEnabled showsHorizontalScrollIndicator={false}
            onMomentumScrollEnd={e => setImgIndex(Math.round(e.nativeEvent.contentOffset.x / width))}
          >
            {images.map((img, i) => (
              <View key={i} style={{ width, height: 280, backgroundColor: Colors.gray100 }}>
                <View style={{ flex: 1, backgroundColor: Colors.primaryBg, alignItems: 'center', justifyContent: 'center' }}>
                  <Ionicons name="business" size={64} color={Colors.primaryLight} />
                </View>
              </View>
            ))}
          </ScrollView>

          {/* Overlay controls */}
          <LinearGradient colors={['rgba(0,0,0,0.4)', 'transparent']} style={styles.imgTopOverlay}>
            <TouchableOpacity onPress={() => nav.goBack()} style={styles.imgBtn}>
              <Ionicons name="arrow-back" size={20} color={Colors.white} />
            </TouchableOpacity>
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <TouchableOpacity onPress={() => toggleFavorite(hall.id)} style={styles.imgBtn}>
                <Ionicons name={isFav ? 'heart' : 'heart-outline'} size={20} color={isFav ? '#FF4B6E' : Colors.white} />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => Share.share({ title: hall.name, message: `تفضل قاعة ${hall.name} في ${hall.city}` })} style={styles.imgBtn}>
                <Ionicons name="share-outline" size={20} color={Colors.white} />
              </TouchableOpacity>
            </View>
          </LinearGradient>

          {/* Image dots */}
          {images.length > 1 && (
            <View style={styles.imgDots}>
              {images.map((_, i) => (
                <View key={i} style={[styles.imgDot, i === imgIndex && styles.imgDotActive]} />
              ))}
            </View>
          )}
        </View>

        {/* Hall Info */}
        <View style={{ padding: 20 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <View style={{ flex: 1 }}>
              <Text style={styles.hallName}>{hall.name}</Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 }}>
                <Ionicons name="location-outline" size={14} color={Colors.gray400} />
                <Text style={styles.hallCity}>{hall.city}</Text>
                {hall.region && <Text style={{ color: Colors.gray300 }}>·</Text>}
                {hall.region && <Text style={styles.hallCity}>{hall.region}</Text>}
              </View>
              {hall.rating && (
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 6 }}>
                  <Stars rating={hall.rating} />
                  <Text style={{ fontSize: Typography.sm, color: Colors.textSecondary }}>
                    {hall.rating.toFixed(1)} ({hall.reviewCount || 0} تقييم)
                  </Text>
                </View>
              )}
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={styles.price}>{hall.hourlyRate?.toLocaleString()}</Text>
              <Text style={{ fontSize: Typography.xs, color: Colors.textSecondary }}>ر.س / ساعة</Text>
            </View>
          </View>

          {/* Quick Stats */}
          <View style={styles.statsRow}>
            <StatItem icon="people-outline" label="السعة" value={`${hall.capacity} ضيف`} />
            <StatItem icon="business-outline" label="النوع" value={hall.type} />
            {hall.isVatEnabled && <StatItem icon="receipt-outline" label="ضريبة القيمة" value={`${hall.vatRate || 15}%`} />}
          </View>

          {/* Sections */}
          <View style={styles.sectionTabs}>
            {(['info', 'services', 'reviews'] as const).map(s => (
              <TouchableOpacity key={s} onPress={() => setActiveSection(s)} style={[styles.sectionTab, activeSection === s && styles.sectionTabActive]}>
                <Text style={[styles.sectionTabText, activeSection === s && { color: Colors.primary }]}>
                  {s === 'info' ? 'المعلومات' : s === 'services' ? 'الخدمات' : 'التقييمات'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {activeSection === 'info' && (
            <View style={{ gap: 12 }}>
              {hall.description && (
                <Card>
                  <Text style={styles.sectionTitle}>وصف القاعة</Text>
                  <Text style={styles.description}>{hall.description}</Text>
                </Card>
              )}
              {hall.amenities && hall.amenities.length > 0 && (
                <Card>
                  <Text style={styles.sectionTitle}>المميزات والمرافق</Text>
                  <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
                    {hall.amenities.map((a, i) => (
                      <View key={i} style={styles.amenityChip}>
                        <Ionicons name="checkmark-circle" size={14} color={Colors.success} />
                        <Text style={styles.amenityText}>{a}</Text>
                      </View>
                    ))}
                  </View>
                </Card>
              )}
            </View>
          )}

          {activeSection === 'services' && (
            <View style={{ gap: 10 }}>
              {services.length === 0
                ? <Text style={{ color: Colors.textSecondary, textAlign: 'center', padding: 24 }}>لا توجد خدمات إضافية</Text>
                : services.map(s => (
                  <Card key={s.id} style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}>
                    <View style={styles.svcIcon}><Ionicons name="construct-outline" size={18} color={Colors.primary} /></View>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: Typography.base, fontWeight: Typography.medium, color: Colors.textPrimary }}>{s.name}</Text>
                      {s.description && <Text style={{ fontSize: Typography.xs, color: Colors.textSecondary }}>{s.description}</Text>}
                    </View>
                    <Text style={{ color: Colors.primary, fontWeight: Typography.bold }}>{s.price?.toLocaleString()} ر.س</Text>
                  </Card>
                ))
              }
            </View>
          )}

          {activeSection === 'reviews' && (
            <View>
              <TouchableOpacity onPress={() => nav.navigate('HallReviews', { hallId: hall.id, hallName: hall.name })} style={styles.seeReviewsBtn}>
                <Text style={{ color: Colors.primary, fontWeight: Typography.medium }}>عرض كل التقييمات</Text>
                <Ionicons name="arrow-back" size={16} color={Colors.primary} />
              </TouchableOpacity>
            </View>
          )}
        </View>
        <View style={{ height: 120 }} />
      </ScrollView>

      {/* Bottom CTA */}
      <View style={styles.bottomBar}>
        <View>
          <Text style={{ fontSize: Typography.xs, color: Colors.textSecondary }}>السعر من</Text>
          <Text style={{ fontSize: Typography.xl, fontWeight: Typography.bold, color: Colors.primary }}>
            {hall.hourlyRate?.toLocaleString()} ر.س
          </Text>
        </View>
        <Button
          label="احجز الآن"
          onPress={() => nav.navigate('BookingsTab', { screen: 'CreateBooking', params: { hall } })}
          style={{ flex: 1, marginRight: 12 }}
          size="lg"
        />
      </View>
    </SafeScreen>
  );
}

function StatItem({ icon, label, value }: { icon: string; label: string; value: string }) {
  return (
    <View style={styles.statItem}>
      <Ionicons name={icon as any} size={18} color={Colors.primary} />
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={styles.statValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  imgTopOverlay: { position: 'absolute', top: 0, left: 0, right: 0, height: 80, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', paddingHorizontal: 16, paddingBottom: 12 },
  imgBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(0,0,0,0.4)', alignItems: 'center', justifyContent: 'center' },
  imgDots: { position: 'absolute', bottom: 12, alignSelf: 'center', flexDirection: 'row', gap: 6 },
  imgDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.5)' },
  imgDotActive: { width: 18, backgroundColor: Colors.white },
  hallName: { fontSize: Typography['2xl'], fontWeight: Typography.bold, color: Colors.textPrimary },
  hallCity: { fontSize: Typography.sm, color: Colors.textSecondary },
  price: { fontSize: Typography['2xl'], fontWeight: Typography.bold, color: Colors.primary },
  statsRow: { flexDirection: 'row', gap: 10, marginTop: 16, marginBottom: 20 },
  statItem: { flex: 1, backgroundColor: Colors.gray50, borderRadius: Radius.lg, padding: 10, alignItems: 'center', gap: 4 },
  statLabel: { fontSize: Typography.xs, color: Colors.textSecondary },
  statValue: { fontSize: Typography.sm, fontWeight: Typography.semibold, color: Colors.textPrimary },
  sectionTabs: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: Colors.border, marginBottom: 16 },
  sectionTab: { flex: 1, paddingVertical: 10, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  sectionTabActive: { borderBottomColor: Colors.primary },
  sectionTabText: { fontSize: Typography.sm, color: Colors.gray400, fontWeight: Typography.medium },
  sectionTitle: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary, marginBottom: 6 },
  description: { fontSize: Typography.base, color: Colors.textSecondary, lineHeight: 26 },
  amenityChip: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: Colors.successBg, paddingHorizontal: 10, paddingVertical: 5, borderRadius: Radius.full },
  amenityText: { fontSize: Typography.xs, color: Colors.success, fontWeight: Typography.medium },
  svcIcon: { width: 38, height: 38, borderRadius: 10, backgroundColor: Colors.primaryBg, alignItems: 'center', justifyContent: 'center' },
  seeReviewsBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, justifyContent: 'center', padding: 14, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border },
  bottomBar: { position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: Colors.white, paddingHorizontal: 20, paddingVertical: 16, borderTopWidth: 0.5, borderTopColor: Colors.border, ...Shadow.md },
});

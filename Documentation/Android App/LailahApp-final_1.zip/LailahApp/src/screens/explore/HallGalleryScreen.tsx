import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, Dimensions, StyleSheet } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen } from '../../components/common';
import { Colors, Typography } from '../../theme';

const { width, height } = Dimensions.get('window');

export default function HallGalleryScreen() {
  const nav   = useNavigation<any>();
  const route = useRoute<any>();
  const { images = [], index: initIndex = 0 } = route.params;
  const [current, setCurrent] = useState(initIndex);

  return (
    <SafeScreen bg="#000">
      <TouchableOpacity onPress={() => nav.goBack()} style={{ position: 'absolute', top: 50, right: 16, zIndex: 10, backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 20, padding: 8 }}>
        <Ionicons name="close" size={24} color={Colors.white} />
      </TouchableOpacity>
      <FlatList
        data={images}
        horizontal pagingEnabled
        initialScrollIndex={initIndex}
        getItemLayout={(_, i) => ({ length: width, offset: width * i, index: i })}
        onMomentumScrollEnd={e => setCurrent(Math.round(e.nativeEvent.contentOffset.x / width))}
        renderItem={({ item }) => (
          <View style={{ width, height, backgroundColor: '#111', alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="business" size={80} color="rgba(255,255,255,0.2)" />
          </View>
        )}
        keyExtractor={(_, i) => String(i)}
        showsHorizontalScrollIndicator={false}
      />
      <View style={styles.counter}>
        <Text style={{ color: Colors.white, fontSize: Typography.base }}>{current + 1} / {images.length}</Text>
      </View>
    </SafeScreen>
  );
}
const styles = StyleSheet.create({
  counter: { position: 'absolute', bottom: 40, alignSelf: 'center', backgroundColor: 'rgba(0,0,0,0.6)', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20 },
});

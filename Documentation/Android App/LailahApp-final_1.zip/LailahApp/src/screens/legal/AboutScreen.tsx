import React from 'react';
import { View, Text, ScrollView, StyleSheet, Linking, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card } from '../../components/common';
import { Colors, Typography } from '../../theme';

export default function AboutScreen() {
  const nav = useNavigation<any>();
  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="من نحن" onBack={() => nav.goBack()} />
      <ScrollView contentContainerStyle={{ padding: 20, gap: 16 }} showsVerticalScrollIndicator={false}>
        <View style={{ alignItems: 'center', paddingVertical: 24 }}>
          <View style={{ width: 80, height: 80, borderRadius: 40, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center', marginBottom: 12 }}>
            <Text style={{ color: Colors.white, fontSize: 30, fontWeight: Typography.bold }}>ل</Text>
          </View>
          <Text style={{ fontSize: Typography['2xl'], fontWeight: Typography.bold, color: Colors.textPrimary }}>منصة ليلة</Text>
          <Text style={{ color: Colors.textSecondary, fontSize: Typography.sm, marginTop: 4 }}>الإصدار 1.0.0</Text>
        </View>

        <Card>
          <Text style={styles.cardTitle}>رسالتنا</Text>
          <Text style={styles.cardBody}>ليلة هي منصة سعودية متخصصة في حجز قاعات الأفراح والمناسبات والخدمات المساندة، نسعى لتسهيل رحلة العميل من البحث حتى الحجز والدفع في مكان واحد.</Text>
        </Card>

        <Card>
          <Text style={styles.cardTitle}>تواصل معنا</Text>
          {[
            { icon: 'mail-outline', label: 'info@lailah.sa', action: () => Linking.openURL('mailto:info@lailah.sa') },
            { icon: 'call-outline', label: '920000000', action: () => Linking.openURL('tel:920000000') },
            { icon: 'logo-twitter', label: '@lailah_sa', action: () => Linking.openURL('https://twitter.com/lailah_sa') },
          ].map((item, i) => (
            <TouchableOpacity key={i} onPress={item.action} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8 }}>
              <Ionicons name={item.icon as any} size={18} color={Colors.primary} />
              <Text style={{ color: Colors.primary, fontSize: Typography.base }}>{item.label}</Text>
            </TouchableOpacity>
          ))}
        </Card>
      </ScrollView>
    </SafeScreen>
  );
}
const styles = StyleSheet.create({
  cardTitle: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary, marginBottom: 8 },
  cardBody: { fontSize: Typography.base, color: Colors.textSecondary, lineHeight: 26 },
});

import React from 'react';
import { ScrollView, Text, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { SafeScreen, AppHeader, Card } from '../../components/common';
import { Colors, Typography } from '../../theme';

export default function TermsScreen() {
  const nav = useNavigation<any>();
  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="سياسة الخصوصية" onBack={() => nav.goBack()} />
      <ScrollView contentContainerStyle={{ padding: 16 }} showsVerticalScrollIndicator={false}>
        <Card>
          <Text style={{ fontSize: Typography.base, color: Colors.textSecondary, lineHeight: 28, textAlign: 'right' }}>
            سياسة الخصوصية لمنصة ليلة — يُرجى قراءتها بعناية قبل استخدام التطبيق.{'\n\n'}
            تستخدم منصة ليلة بياناتك لتحسين تجربتك وتقديم خدمات الحجز والدفع.{'\n\n'}
            للاستفسار: info@lailah.sa
          </Text>
        </Card>
      </ScrollView>
    </SafeScreen>
  );
}

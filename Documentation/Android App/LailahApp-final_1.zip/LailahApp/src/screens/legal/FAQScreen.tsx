import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card } from '../../components/common';
import { Colors, Typography } from '../../theme';

const FAQS = [
  { q: 'كيف أحجز قاعة؟', a: 'اختر القاعة المناسبة من الاستعراض، حدد الموعد والضيوف، ثم أكمل عملية الدفع.' },
  { q: 'كيف يمكنني إلغاء الحجز؟', a: 'يمكنك إلغاء الحجز من قسم "حجوزاتي" قبل 48 ساعة من الموعد لاسترداد المبلغ.' },
  { q: 'ما طرق الدفع المتاحة؟', a: 'ندعم مدى، فيزا، ماستركارد، Apple Pay، وخدمات التقسيط مثل تمارة وتابي.' },
  { q: 'كيف أطلب خدمة مساندة مستقلة؟', a: 'من تبويب "استعرض" اختر "الخدمات المساندة"، حدد الخدمة واملأ تفاصيل الطلب.' },
  { q: 'هل يمكنني الدفع لاحقاً؟', a: 'نعم، نتيح خيار "ادفع لاحقاً" عبر خدمة تمارة أو تابي.' },
];

export default function FAQScreen() {
  const nav = useNavigation<any>();
  const [open, setOpen] = useState<number | null>(null);
  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="الأسئلة الشائعة" onBack={() => nav.goBack()} />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 8 }} showsVerticalScrollIndicator={false}>
        {FAQS.map((faq, i) => (
          <Card key={i} style={{ padding: 0, overflow: 'hidden' }}>
            <TouchableOpacity onPress={() => setOpen(open === i ? null : i)} style={styles.faqQ}>
              <Text style={styles.faqQText}>{faq.q}</Text>
              <Ionicons name={open === i ? 'chevron-up' : 'chevron-down'} size={18} color={Colors.gray400} />
            </TouchableOpacity>
            {open === i && (
              <View style={styles.faqA}>
                <Text style={styles.faqAText}>{faq.a}</Text>
              </View>
            )}
          </Card>
        ))}
      </ScrollView>
    </SafeScreen>
  );
}
const styles = StyleSheet.create({
  faqQ: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 10 },
  faqQText: { flex: 1, fontSize: Typography.base, fontWeight: Typography.medium, color: Colors.textPrimary },
  faqA: { paddingHorizontal: 16, paddingBottom: 14, borderTopWidth: 0.5, borderTopColor: Colors.border },
  faqAText: { fontSize: Typography.sm, color: Colors.textSecondary, lineHeight: 24, marginTop: 10 },
});

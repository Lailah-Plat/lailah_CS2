import React, { useState } from 'react';
import { View, Alert, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { SafeScreen, AppHeader, Input, Button, Card } from '../../components/common';
import { Colors } from '../../theme';

export default function ContactScreen() {
  const nav = useNavigation<any>();
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  async function send() {
    if (!subject || !message) return Alert.alert('', 'أدخل الموضوع والرسالة');
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    setLoading(false);
    Alert.alert('✅ تم الإرسال', 'سنتواصل معك خلال 24 ساعة');
    nav.goBack();
  }

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="تواصل معنا" onBack={() => nav.goBack()} />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }} keyboardShouldPersistTaps="handled">
        <Input label="الموضوع" placeholder="ما موضوع رسالتك؟" value={subject} onChangeText={setSubject} icon="create-outline" />
        <Input label="الرسالة" placeholder="اكتب رسالتك هنا..." value={message} onChangeText={setMessage} multiline numberOfLines={5} />
        <Button label="إرسال الرسالة" onPress={send} loading={loading} size="lg" />
      </ScrollView>
    </SafeScreen>
  );
}

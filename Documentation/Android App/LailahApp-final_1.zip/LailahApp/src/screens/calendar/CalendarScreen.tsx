import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Calendar, LocaleConfig } from 'react-native-calendars';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card, StatusBadge, EmptyState } from '../../components/common';
import { Colors, Typography } from '../../theme';
import { bookingsApi } from '../../api';
import type { Booking } from '../../types';

LocaleConfig.locales['ar'] = {
  monthNames: ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'],
  monthNamesShort: ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'],
  dayNames: ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'],
  dayNamesShort: ['أح','إث','ثل','أر','خم','جم','سب'],
};
LocaleConfig.defaultLocale = 'ar';

export default function CalendarScreen() {
  const nav = useNavigation<any>();
  const [bookings, setBookings]       = useState<Booking[]>([]);
  const [selectedDate, setSelectedDate] = useState('');
  const [markedDates, setMarkedDates]   = useState<Record<string, any>>({});

  useEffect(() => {
    bookingsApi.getAll().then(res => {
      const all = res.bookings || [];
      setBookings(all);
      const marks: Record<string, any> = {};
      all.forEach(b => {
        const dateKey = b.startTime.slice(0, 10);
        const color = b.status === 'confirmed' ? Colors.success : b.status === 'pending' ? Colors.warning : Colors.error;
        marks[dateKey] = { marked: true, dotColor: color, selectedColor: Colors.primary };
      });
      setMarkedDates(marks);
    }).catch(() => {});
  }, []);

  const dayBookings = selectedDate
    ? bookings.filter(b => b.startTime.startsWith(selectedDate))
    : [];

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="التقويم الذكي" onBack={() => nav.goBack()} />
      <Calendar
        onDayPress={day => setSelectedDate(day.dateString)}
        markedDates={{
          ...markedDates,
          ...(selectedDate ? { [selectedDate]: { ...markedDates[selectedDate], selected: true, selectedColor: Colors.primary } } : {}),
        }}
        theme={{
          backgroundColor: Colors.white,
          calendarBackground: Colors.white,
          selectedDayBackgroundColor: Colors.primary,
          selectedDayTextColor: Colors.white,
          todayTextColor: Colors.primary,
          dayTextColor: Colors.textPrimary,
          textDisabledColor: Colors.gray300,
          dotColor: Colors.primary,
          monthTextColor: Colors.textPrimary,
          arrowColor: Colors.primary,
          textDayFontWeight: Typography.medium,
          textMonthFontWeight: Typography.bold,
        }}
      />
      {selectedDate && (
        <View style={{ flex: 1, padding: 16 }}>
          <Text style={styles.dateHeader}>
            حجوزات {new Date(selectedDate).toLocaleDateString('ar-SA', { weekday: 'long', day: 'numeric', month: 'long' })}
          </Text>
          {dayBookings.length === 0 ? (
            <EmptyState icon="calendar-outline" title="لا توجد حجوزات" subtitle="لا يوجد حجوزات في هذا اليوم" />
          ) : (
            <FlatList
              data={dayBookings}
              keyExtractor={b => String(b.id)}
              contentContainerStyle={{ gap: 8 }}
              renderItem={({ item: b }) => (
                <TouchableOpacity onPress={() => nav.navigate('BookingsTab', { screen: 'BookingDetails', params: { bookingId: b.id } })}>
                  <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                    <View style={styles.timeBox}>
                      <Text style={styles.timeText}>{new Date(b.startTime).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: Typography.base, fontWeight: Typography.medium, color: Colors.textPrimary }}>{b.hallName}</Text>
                      <Text style={{ fontSize: Typography.xs, color: Colors.textSecondary }}>{b.guests} ضيف · {Number(b.totalAmount).toLocaleString()} ر.س</Text>
                    </View>
                    <StatusBadge status={b.status} />
                  </Card>
                </TouchableOpacity>
              )}
            />
          )}
        </View>
      )}
    </SafeScreen>
  );
}

const styles = StyleSheet.create({
  dateHeader: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary, marginBottom: 12 },
  timeBox: { backgroundColor: Colors.primaryBg, borderRadius: 8, padding: 8, alignItems: 'center' },
  timeText: { fontSize: Typography.xs, fontWeight: Typography.semibold, color: Colors.primary },
});

import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, TextInput, StyleSheet, RefreshControl } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card, EmptyState, Skeleton, Stars } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';
import { servicesApi } from '../../api';
import type { Service } from '../../types';

const CATEGORIES = ['الكل','تصوير','ضيافة','ديكور','موسيقى','كيك','طباعة','أمن','نقليات'];

export default function ServicesExploreScreen() {
  const nav = useNavigation<any>();
  const [services, setServices]   = useState<Service[]>([]);
  const [search, setSearch]       = useState('');
  const [category, setCategory]   = useState('الكل');
  const [loading, setLoading]     = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      const res = await servicesApi.getAll({ category: category !== 'الكل' ? category : undefined, search: search || undefined });
      setServices(res.services || []);
    } catch {}
    finally { setLoading(false); setRefreshing(false); }
  }

  const filtered = services.filter(s =>
    (category === 'الكل' || s.category === category) &&
    (!search || s.name.includes(search) || s.category?.includes(search))
  );

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="الخدمات المساندة" onBack={() => nav.goBack()} />

      {/* Search */}
      <View style={{ paddingHorizontal: 16, paddingVertical: 10, backgroundColor: Colors.white }}>
        <View style={styles.searchBox}>
          <Ionicons name="search" size={16} color={Colors.gray400} />
          <TextInput style={styles.searchInput} placeholder="ابحث عن خدمة..." placeholderTextColor={Colors.gray400} value={search} onChangeText={setSearch} onSubmitEditing={load} textAlign="right" />
        </View>
      </View>

      {/* Category chips */}
      <FlatList
        data={CATEGORIES} horizontal showsHorizontalScrollIndicator={false}
        keyExtractor={c => c}
        contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 10, gap: 8 }}
        renderItem={({ item: c }) => (
          <TouchableOpacity onPress={() => setCategory(c)} style={[styles.chip, category === c && styles.chipActive]}>
            <Text style={[styles.chipText, category === c && { color: Colors.white }]}>{c}</Text>
          </TouchableOpacity>
        )}
      />

      <FlatList
        data={loading ? [1,2,3] as any[] : filtered}
        keyExtractor={(_, i) => String(i)}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} colors={[Colors.primary]} />}
        contentContainerStyle={{ padding: 16, gap: 10, flexGrow: 1 }}
        ListHeaderComponent={!loading ? <Text style={{ fontSize: Typography.sm, color: Colors.textSecondary, marginBottom: 4 }}>{filtered.length} خدمة متاحة</Text> : null}
        ListEmptyComponent={!loading ? <EmptyState icon="construct-outline" title="لا توجد خدمات" subtitle="جرب تغيير الفئة أو بحث مختلف" /> : null}
        renderItem={({ item: svc }) =>
          loading ? <Skeleton width="100%" height={90} radius={14} /> : (
            <TouchableOpacity onPress={() => nav.navigate('ServiceDetails', { service: svc })} activeOpacity={0.85}>
              <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
                <View style={styles.svcIcon}><Ionicons name="construct-outline" size={24} color={Colors.primary} /></View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.svcName}>{svc.name}</Text>
                  <Text style={styles.svcCat}>{svc.category}</Text>
                  {svc.rating && <Stars rating={svc.rating} size={12} />}
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={styles.svcPrice}>{svc.price?.toLocaleString()}</Text>
                  <Text style={styles.svcUnit}>ر.س/{svc.unit || 'وحدة'}</Text>
                </View>
              </Card>
            </TouchableOpacity>
          )
        }
      />
    </SafeScreen>
  );
}

const styles = StyleSheet.create({
  searchBox: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: Colors.gray50, borderRadius: Radius.xl, paddingHorizontal: 12, height: 42, borderWidth: 1, borderColor: Colors.border },
  searchInput: { flex: 1, fontSize: Typography.base, color: Colors.textPrimary },
  chip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: Radius.full, backgroundColor: Colors.white, borderWidth: 1, borderColor: Colors.border },
  chipActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  chipText: { fontSize: Typography.sm, color: Colors.textSecondary, fontWeight: Typography.medium },
  svcIcon: { width: 48, height: 48, borderRadius: 12, backgroundColor: Colors.primaryBg, alignItems: 'center', justifyContent: 'center' },
  svcName: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary },
  svcCat: { fontSize: Typography.xs, color: Colors.textSecondary, marginTop: 2 },
  svcPrice: { fontSize: Typography.lg, fontWeight: Typography.bold, color: Colors.primary },
  svcUnit: { fontSize: Typography.xs, color: Colors.textSecondary },
});

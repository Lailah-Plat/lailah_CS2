import React, { useEffect, useState } from 'react';
import { FlatList, TouchableOpacity, View, Text, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card, StatusBadge, EmptyState } from '../../components/common';
import { Colors, Typography } from '../../theme';
import { servicesApi } from '../../api';
import type { ServiceRequest } from '../../types';

export default function ServiceRequestsScreen() {
  const nav = useNavigation<any>();
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    servicesApi.getMyRequests().then(r => setRequests(Array.isArray(r) ? r : [])).catch(() => {}).finally(() => setLoading(false));
  }, []);

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="طلبات الخدمات" onBack={() => nav.goBack()} />
      <FlatList
        data={requests}
        keyExtractor={r => String(r.id)}
        contentContainerStyle={{ padding: 16, gap: 10, flexGrow: 1 }}
        ListEmptyComponent={!loading ? <EmptyState icon="construct-outline" title="لا توجد طلبات" subtitle="اطلب خدمة مساندة من قسم الاستعراض" action={{ label: 'استعرض الخدمات', onPress: () => nav.navigate('ExploreTab', { screen: 'ServicesExplore' }) }} /> : null}
        renderItem={({ item: r }) => (
          <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
            <View style={styles.icon}><Ionicons name="construct-outline" size={20} color={Colors.primary} /></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.name}>{r.serviceName}</Text>
              <Text style={styles.date}>{r.eventDate ? new Date(r.eventDate).toLocaleDateString('ar-SA') : '—'} · {r.quantity} وحدة</Text>
              <Text style={styles.amount}>{Number(r.totalAmount).toLocaleString()} ر.س</Text>
            </View>
            <StatusBadge status={r.status} />
          </Card>
        )}
      />
    </SafeScreen>
  );
}
const styles = StyleSheet.create({
  icon: { width: 44, height: 44, borderRadius: 12, backgroundColor: Colors.primaryBg, alignItems: 'center', justifyContent: 'center' },
  name: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary },
  date: { fontSize: Typography.xs, color: Colors.textSecondary, marginTop: 2 },
  amount: { fontSize: Typography.sm, color: Colors.primary, fontWeight: Typography.semibold, marginTop: 2 },
});

import React, { useState } from 'react';
import { View, Text, ScrollView, Alert, StyleSheet } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { SafeScreen, AppHeader, Input, Button, Card } from '../../components/common';
import { Colors, Typography } from '../../theme';
import { servicesApi } from '../../api';
import type { Service } from '../../types';

export default function CreateServiceRequestScreen() {
  const nav   = useNavigation<any>();
  const route = useRoute<any>();
  const service: Service = route.params?.service;
  const initQty: number  = route.params?.quantity || 1;

  const [eventDate, setEventDate] = useState('');
  const [address, setAddress]     = useState('');
  const [notes, setNotes]         = useState('');
  const [qty, setQty]             = useState(String(initQty));
  const [loading, setLoading]     = useState(false);

  async function submit() {
    if (!eventDate || !address) return Alert.alert('', 'أدخل تاريخ الفعالية والعنوان');
    setLoading(true);
    try {
      await servicesApi.createRequest({
        serviceId: service.id, quantity: Number(qty),
        eventDate, address, notes: notes || undefined,
      });
      Alert.alert('✅ تم الطلب', 'سيتواصل معك مقدم الخدمة قريباً', [
        { text: 'حسناً', onPress: () => nav.navigate('ServiceRequests') },
      ]);
    } catch (e: any) {
      Alert.alert('خطأ', e.message || 'فشل إرسال الطلب');
    } finally { setLoading(false); }
  }

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="طلب خدمة" onBack={() => nav.goBack()} />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <Card>
          <Text style={styles.svcName}>{service?.name}</Text>
          <Text style={styles.svcPrice}>{((service?.price || 0) * Number(qty)).toLocaleString()} ر.س</Text>
        </Card>
        <Input label="الكمية" placeholder="1" value={qty} onChangeText={setQty} keyboardType="number-pad" icon="layers-outline" />
        <Input label="تاريخ الفعالية" placeholder="2026-08-15" value={eventDate} onChangeText={setEventDate} icon="calendar-outline" />
        <Input label="العنوان" placeholder="مدينة / حي / شارع" value={address} onChangeText={setAddress} icon="location-outline" />
        <Input label="ملاحظات (اختياري)" placeholder="أي متطلبات إضافية..." value={notes} onChangeText={setNotes} multiline numberOfLines={3} icon="document-text-outline" />
        <Button label="إرسال الطلب" onPress={submit} loading={loading} size="lg" icon="send-outline" style={{ marginTop: 8 }} />
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeScreen>
  );
}
const styles = StyleSheet.create({
  svcName: { fontSize: Typography.lg, fontWeight: Typography.bold, color: Colors.textPrimary },
  svcPrice: { fontSize: Typography.base, color: Colors.primary, fontWeight: Typography.semibold, marginTop: 4 },
});

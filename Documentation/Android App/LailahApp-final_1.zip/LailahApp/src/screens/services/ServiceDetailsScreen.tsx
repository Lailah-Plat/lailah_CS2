import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card, Button, Stars } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';
import type { Service } from '../../types';

export default function ServiceDetailsScreen() {
  const nav   = useNavigation<any>();
  const route = useRoute<any>();
  const service: Service = route.params?.service;
  const [qty, setQty] = useState(1);

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title={service?.name} onBack={() => nav.goBack()} />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }} showsVerticalScrollIndicator={false}>
        {/* Icon */}
        <View style={{ alignItems: 'center', paddingVertical: 20 }}>
          <View style={styles.icon}><Ionicons name="construct" size={52} color={Colors.primary} /></View>
          <Text style={styles.name}>{service?.name}</Text>
          <Text style={styles.category}>{service?.category}</Text>
          {service?.rating && <Stars rating={service.rating} />}
        </View>

        {/* Price & Qty */}
        <Card style={{ gap: 14 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={styles.label}>السعر</Text>
            <Text style={styles.price}>{service?.price?.toLocaleString()} ر.س / {service?.unit || 'وحدة'}</Text>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={styles.label}>الكمية</Text>
            <View style={styles.qtyRow}>
              <TouchableOpacity onPress={() => setQty(q => Math.max(1, q - 1))} style={styles.qtyBtn}><Ionicons name="remove" size={18} color={Colors.primary} /></TouchableOpacity>
              <Text style={styles.qtyVal}>{qty}</Text>
              <TouchableOpacity onPress={() => setQty(q => q + 1)} style={styles.qtyBtn}><Ionicons name="add" size={18} color={Colors.primary} /></TouchableOpacity>
            </View>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop: 10, borderTopWidth: 0.5, borderTopColor: Colors.border }}>
            <Text style={{ fontSize: Typography.base, fontWeight: Typography.bold, color: Colors.textPrimary }}>الإجمالي</Text>
            <Text style={{ fontSize: Typography.xl, fontWeight: Typography.bold, color: Colors.primary }}>{((service?.price || 0) * qty).toLocaleString()} ر.س</Text>
          </View>
        </Card>

        {service?.description && (
          <Card>
            <Text style={styles.label}>الوصف</Text>
            <Text style={{ fontSize: Typography.base, color: Colors.textSecondary, lineHeight: 26, marginTop: 6 }}>{service.description}</Text>
          </Card>
        )}

        <Button
          label="طلب الخدمة"
          onPress={() => nav.navigate('CreateServiceRequest', { service, quantity: qty })}
          size="lg" icon="send-outline"
          style={{ marginTop: 8 }}
        />
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeScreen>
  );
}

const styles = StyleSheet.create({
  icon: { width: 100, height: 100, borderRadius: 50, backgroundColor: Colors.primaryBg, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  name: { fontSize: Typography['2xl'], fontWeight: Typography.bold, color: Colors.textPrimary },
  category: { fontSize: Typography.sm, color: Colors.textSecondary, marginTop: 4, marginBottom: 8 },
  label: { fontSize: Typography.sm, fontWeight: Typography.semibold, color: Colors.textSecondary },
  price: { fontSize: Typography.lg, fontWeight: Typography.bold, color: Colors.primary },
  qtyRow: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  qtyBtn: { width: 34, height: 34, borderRadius: 17, borderWidth: 1.5, borderColor: Colors.primary, alignItems: 'center', justifyContent: 'center' },
  qtyVal: { fontSize: Typography.xl, fontWeight: Typography.bold, color: Colors.textPrimary, minWidth: 30, textAlign: 'center' },
});

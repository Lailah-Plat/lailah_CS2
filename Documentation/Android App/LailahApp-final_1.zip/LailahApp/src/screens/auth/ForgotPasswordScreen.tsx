import React, { useState } from 'react';
import { View, Text, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { SafeScreen, Button, Input, AppHeader } from '../../components/common';
import { Colors, Typography } from '../../theme';
import { authApi } from '../../api';

export default function ForgotPasswordScreen() {
  const navigation = useNavigation<any>();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSend() {
    if (!email.trim()) return Alert.alert('', 'أدخل بريدك الإلكتروني');
    setLoading(true);
    try {
      await authApi.forgotPassword(email.trim());
      navigation.navigate('OtpVerify', { email: email.trim() });
    } catch (err: any) {
      Alert.alert('خطأ', err.message || 'البريد غير مسجل');
    } finally { setLoading(false); }
  }

  return (
    <SafeScreen bg={Colors.white}>
      <AppHeader title="نسيت كلمة المرور" onBack={() => navigation.goBack()} />
      <View style={{ flex: 1, padding: 24, gap: 20 }}>
        <Text style={{ fontSize: Typography.base, color: Colors.textSecondary, lineHeight: 24 }}>
          أدخل بريدك الإلكتروني وسنرسل لك رمز التحقق لإعادة تعيين كلمة المرور.
        </Text>
        <Input label="البريد الإلكتروني" placeholder="example@email.com" value={email} onChangeText={setEmail} keyboardType="email-address" icon="mail-outline" />
        <Button label="إرسال رمز التحقق" onPress={handleSend} loading={loading} size="lg" />
      </View>
    </SafeScreen>
  );
}

import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, ScrollView, StyleSheet,
  KeyboardAvoidingView, Platform, Image, Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import * as LocalAuthentication from 'expo-local-authentication';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, Button, Input, Divider } from '../../components/common';
import { Colors, Typography, Spacing, Radius } from '../../theme';
import { authApi } from '../../api';
import { useAuthStore, useAppSettingsStore } from '../../store';

export default function LoginScreen() {
  const navigation = useNavigation<any>();
  const { login } = useAuthStore();
  const { biometricEnabled } = useAppSettingsStore();

  const [emailOrPhone, setEmailOrPhone] = useState('');
  const [password, setPassword]         = useState('');
  const [loading, setLoading]           = useState(false);
  const [errors, setErrors]             = useState<Record<string, string>>({});

  function validate() {
    const e: Record<string, string> = {};
    if (!emailOrPhone.trim()) e.emailOrPhone = 'البريد أو رقم الجوال مطلوب';
    if (!password)            e.password = 'كلمة المرور مطلوبة';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleLogin() {
    if (!validate()) return;
    setLoading(true);
    try {
      const data = await authApi.login(emailOrPhone.trim(), password);
      if (data.success && data.user) {
        await login(data.user, data.token);
      }
    } catch (err: any) {
      Alert.alert('خطأ في تسجيل الدخول', err.message || 'تحقق من بياناتك وحاول مجدداً');
    } finally {
      setLoading(false);
    }
  }

  async function handleBiometric() {
    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: 'تسجيل الدخول ببصمتك',
      fallbackLabel: 'استخدم كلمة المرور',
    });
    if (result.success) {
      // TODO: use saved credentials with SecureStore
      Alert.alert('تنبيه', 'يرجى تسجيل الدخول بكلمة المرور أولاً لتفعيل البصمة');
    }
  }

  async function handleSocialLogin(provider: 'google' | 'apple') {
    try {
      setLoading(true);
      const data = await authApi.socialLogin(
        `${provider}-user@lailah.sa`,
        provider === 'google' ? 'مستخدم Google' : 'مستخدم Apple',
        provider
      );
      if (data.success && data.user) await login(data.user, data.token);
    } catch (err: any) {
      Alert.alert('خطأ', err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <SafeScreen bg={Colors.white}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Logo */}
          <View style={styles.logoSection}>
            <View style={styles.logoCircle}>
              <Text style={styles.logoText}>ليلة</Text>
            </View>
            <Text style={styles.tagline}>احجز قاعتك بسهولة وأناقة</Text>
          </View>

          {/* Form */}
          <View style={styles.form}>
            <Text style={styles.formTitle}>مرحباً بعودتك 👋</Text>
            <Text style={styles.formSubtitle}>سجّل دخولك للمتابعة</Text>

            <View style={{ gap: 14 }}>
              <Input
                label="البريد الإلكتروني أو رقم الجوال"
                placeholder="example@email.com"
                value={emailOrPhone}
                onChangeText={setEmailOrPhone}
                keyboardType="email-address"
                icon="mail-outline"
                error={errors.emailOrPhone}
              />
              <Input
                label="كلمة المرور"
                placeholder="••••••••"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                icon="lock-closed-outline"
                error={errors.password}
              />
            </View>

            <TouchableOpacity
              onPress={() => navigation.navigate('ForgotPassword')}
              style={{ alignSelf: 'flex-start', marginTop: 4 }}
            >
              <Text style={styles.forgotText}>نسيت كلمة المرور؟</Text>
            </TouchableOpacity>

            <Button
              label="تسجيل الدخول"
              onPress={handleLogin}
              loading={loading}
              style={{ marginTop: 20 }}
              size="lg"
            />

            {biometricEnabled && (
              <TouchableOpacity onPress={handleBiometric} style={styles.biometricBtn}>
                <Ionicons name="finger-print" size={24} color={Colors.primary} />
                <Text style={styles.biometricText}>الدخول بالبصمة</Text>
              </TouchableOpacity>
            )}

            <Divider label="أو تسجيل الدخول بـ" />

            <View style={{ flexDirection: 'row', gap: 12 }}>
              <TouchableOpacity
                onPress={() => handleSocialLogin('google')}
                style={[styles.socialBtn, { flex: 1 }]}
              >
                <Ionicons name="logo-google" size={20} color="#EA4335" />
                <Text style={styles.socialText}>Google</Text>
              </TouchableOpacity>
              {Platform.OS === 'ios' && (
                <TouchableOpacity
                  onPress={() => handleSocialLogin('apple')}
                  style={[styles.socialBtn, { flex: 1 }]}
                >
                  <Ionicons name="logo-apple" size={20} color={Colors.black} />
                  <Text style={styles.socialText}>Apple</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>

          {/* Register link */}
          <View style={styles.registerRow}>
            <Text style={styles.registerText}>ليس لديك حساب؟ </Text>
            <TouchableOpacity onPress={() => navigation.navigate('Register')}>
              <Text style={[styles.registerText, { color: Colors.primary, fontWeight: Typography.semibold }]}>
                سجّل الآن
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeScreen>
  );
}

const styles = StyleSheet.create({
  scroll: { flexGrow: 1, paddingHorizontal: 24, paddingBottom: 40 },
  logoSection: { alignItems: 'center', paddingTop: 48, paddingBottom: 32 },
  logoCircle: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center',
    marginBottom: 12,
  },
  logoText: { color: Colors.white, fontSize: 28, fontWeight: Typography.bold },
  tagline: { color: Colors.textSecondary, fontSize: Typography.sm },
  form: { gap: 0 },
  formTitle: { fontSize: Typography['3xl'], fontWeight: Typography.bold, color: Colors.textPrimary, marginBottom: 4 },
  formSubtitle: { fontSize: Typography.base, color: Colors.textSecondary, marginBottom: 24 },
  forgotText: { color: Colors.primary, fontSize: Typography.sm, marginTop: 8 },
  biometricBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    justifyContent: 'center', paddingVertical: 14,
    borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.xl, marginTop: 12,
  },
  biometricText: { color: Colors.primary, fontSize: Typography.base, fontWeight: Typography.medium },
  socialBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 8, justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.xl, paddingVertical: 12,
  },
  socialText: { fontSize: Typography.base, color: Colors.textPrimary, fontWeight: Typography.medium },
  registerRow: { flexDirection: 'row', justifyContent: 'center', marginTop: 24 },
  registerText: { fontSize: Typography.base, color: Colors.textSecondary },
});

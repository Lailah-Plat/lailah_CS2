import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { SafeScreen, Button, AppHeader } from '../../components/common';
import { Colors, Typography, Spacing, Radius } from '../../theme';
import { authApi } from '../../api';
import { useAuthStore } from '../../store';

export default function OtpVerifyScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const { email, phone } = route.params;
  const { login } = useAuthStore();

  const [otp, setOtp]           = useState(['', '', '', '', '', '']);
  const [loading, setLoading]   = useState(false);
  const [countdown, setCountdown] = useState(60);
  const inputs = useRef<TextInput[]>([]);

  useEffect(() => {
    const t = setInterval(() => setCountdown(c => (c > 0 ? c - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, []);

  function handleOtpChange(val: string, idx: number) {
    const newOtp = [...otp];
    newOtp[idx] = val;
    setOtp(newOtp);
    if (val && idx < 5) inputs.current[idx + 1]?.focus();
    if (!val && idx > 0) inputs.current[idx - 1]?.focus();
  }

  async function handleVerify() {
    const code = otp.join('');
    if (code.length < 6) return Alert.alert('', 'أدخل رمز التحقق كاملاً');
    setLoading(true);
    try {
      const data = await authApi.verifyOtp(email, code);
      if (data.success && data.user) await login(data.user, data.token);
    } catch (err: any) {
      Alert.alert('خطأ', err.message || 'رمز التحقق غير صحيح');
    } finally { setLoading(false); }
  }

  async function handleResend() {
    if (countdown > 0) return;
    try {
      await authApi.forgotPassword(email);
      setCountdown(60);
    } catch {}
  }

  return (
    <SafeScreen bg={Colors.white}>
      <AppHeader title="التحقق من الهوية" onBack={() => navigation.goBack()} />
      <View style={{ flex: 1, padding: 24, alignItems: 'center' }}>
        <View style={styles.iconBox}>
          <Text style={{ fontSize: 36 }}>📱</Text>
        </View>
        <Text style={styles.title}>أدخل رمز التحقق</Text>
        <Text style={styles.sub}>أرسلنا رمز مكون من 6 أرقام إلى{'\n'}{phone || email}</Text>

        <View style={styles.otpRow}>
          {otp.map((digit, i) => (
            <TextInput
              key={i}
              ref={r => { if (r) inputs.current[i] = r; }}
              style={[styles.otpInput, digit ? { borderColor: Colors.primary } : {}]}
              value={digit}
              onChangeText={v => handleOtpChange(v.slice(-1), i)}
              keyboardType="number-pad"
              maxLength={1}
              textAlign="center"
            />
          ))}
        </View>

        <Button label="تحقق" onPress={handleVerify} loading={loading} size="lg" style={{ width: '100%', marginTop: 24 }} />

        <TouchableOpacity onPress={handleResend} style={{ marginTop: 20 }}>
          <Text style={{ color: countdown > 0 ? Colors.gray400 : Colors.primary, fontSize: Typography.sm }}>
            {countdown > 0 ? `إعادة الإرسال بعد ${countdown}ث` : 'إعادة إرسال الرمز'}
          </Text>
        </TouchableOpacity>
      </View>
    </SafeScreen>
  );
}

const styles = StyleSheet.create({
  iconBox: {
    width: 80, height: 80, borderRadius: 40, backgroundColor: Colors.primaryBg,
    alignItems: 'center', justifyContent: 'center', marginBottom: 20, marginTop: 20,
  },
  title: { fontSize: Typography['2xl'], fontWeight: Typography.bold, color: Colors.textPrimary, marginBottom: 8 },
  sub: { fontSize: Typography.sm, color: Colors.textSecondary, textAlign: 'center', lineHeight: 22, marginBottom: 32 },
  otpRow: { flexDirection: 'row', gap: 10 },
  otpInput: {
    width: 48, height: 56, borderWidth: 1.5, borderColor: Colors.border,
    borderRadius: Radius.md, fontSize: Typography.xl, fontWeight: Typography.bold,
    color: Colors.textPrimary, backgroundColor: Colors.gray50,
  },
});

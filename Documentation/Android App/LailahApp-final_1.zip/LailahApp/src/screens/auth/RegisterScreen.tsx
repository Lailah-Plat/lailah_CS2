import React, { useState } from 'react';
import { View, Text, ScrollView, KeyboardAvoidingView, Platform, Alert, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { SafeScreen, Button, Input, AppHeader } from '../../components/common';
import { Colors, Typography, Spacing, Radius } from '../../theme';
import { authApi } from '../../api';

export default function RegisterScreen() {
  const navigation = useNavigation<any>();
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '', confirm: '' });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  function set(key: string, val: string) { setForm(f => ({ ...f, [key]: val })); }

  function validate() {
    const e: Record<string, string> = {};
    if (!form.name.trim())  e.name = 'الاسم مطلوب';
    if (!form.email.trim()) e.email = 'البريد الإلكتروني مطلوب';
    if (!form.phone.trim()) e.phone = 'رقم الجوال مطلوب';
    if (form.password.length < 8) e.password = 'كلمة المرور 8 أحرف على الأقل';
    if (form.password !== form.confirm) e.confirm = 'كلمتا المرور غير متطابقتين';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleRegister() {
    if (!validate()) return;
    setLoading(true);
    try {
      await authApi.register({ name: form.name, email: form.email, phone: form.phone, password: form.password });
      navigation.navigate('OtpVerify', { email: form.email, phone: form.phone });
    } catch (err: any) {
      Alert.alert('خطأ', err.message || 'فشل التسجيل، حاول مرة أخرى');
    } finally { setLoading(false); }
  }

  return (
    <SafeScreen bg={Colors.white}>
      <AppHeader title="إنشاء حساب جديد" onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: 24, gap: 14 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <Input label="الاسم الكامل" placeholder="محمد عبدالله" value={form.name} onChangeText={v => set('name', v)} icon="person-outline" error={errors.name} />
          <Input label="البريد الإلكتروني" placeholder="example@email.com" value={form.email} onChangeText={v => set('email', v)} keyboardType="email-address" icon="mail-outline" error={errors.email} />
          <Input label="رقم الجوال" placeholder="05xxxxxxxx" value={form.phone} onChangeText={v => set('phone', v)} keyboardType="phone-pad" icon="call-outline" error={errors.phone} />
          <Input label="كلمة المرور" placeholder="••••••••" value={form.password} onChangeText={v => set('password', v)} secureTextEntry icon="lock-closed-outline" error={errors.password} />
          <Input label="تأكيد كلمة المرور" placeholder="••••••••" value={form.confirm} onChangeText={v => set('confirm', v)} secureTextEntry icon="lock-closed-outline" error={errors.confirm} />

          <Text style={{ fontSize: Typography.xs, color: Colors.textMuted, lineHeight: 20, marginTop: 4 }}>
            بالتسجيل، أوافق على <Text style={{ color: Colors.primary }}>شروط الاستخدام</Text> و<Text style={{ color: Colors.primary }}>سياسة الخصوصية</Text>
          </Text>

          <Button label="إنشاء الحساب" onPress={handleRegister} loading={loading} size="lg" style={{ marginTop: 8 }} />

          <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 8 }}>
            <Text style={{ color: Colors.textSecondary }}>لديك حساب؟ </Text>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
              <Text style={{ color: Colors.primary, fontWeight: Typography.semibold }}>سجّل دخولك</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeScreen>
  );
}

import React, { useState } from 'react';
import { View, Alert } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { SafeScreen, Button, Input, AppHeader } from '../../components/common';
import { Colors } from '../../theme';
import { authApi } from '../../api';
import { useAuthStore } from '../../store';

export default function ResetPasswordScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const { email, otp } = route.params;
  const { login } = useAuthStore();

  const [password, setPassword]   = useState('');
  const [confirm, setConfirm]     = useState('');
  const [loading, setLoading]     = useState(false);

  async function handleReset() {
    if (password.length < 8) return Alert.alert('', 'كلمة المرور 8 أحرف على الأقل');
    if (password !== confirm) return Alert.alert('', 'كلمتا المرور غير متطابقتين');
    setLoading(true);
    try {
      const data = await authApi.resetPassword(email, otp, password);
      if (data.success) {
        Alert.alert('✅ تم', 'تم تغيير كلمة المرور بنجاح', [
          { text: 'حسناً', onPress: () => navigation.navigate('Login') }
        ]);
      }
    } catch (err: any) {
      Alert.alert('خطأ', err.message);
    } finally { setLoading(false); }
  }

  return (
    <SafeScreen bg={Colors.white}>
      <AppHeader title="تعيين كلمة مرور جديدة" onBack={() => navigation.goBack()} />
      <View style={{ flex: 1, padding: 24, gap: 16 }}>
        <Input label="كلمة المرور الجديدة" placeholder="••••••••" value={password} onChangeText={setPassword} secureTextEntry icon="lock-closed-outline" />
        <Input label="تأكيد كلمة المرور" placeholder="••••••••" value={confirm} onChangeText={setConfirm} secureTextEntry icon="lock-closed-outline" />
        <Button label="تعيين كلمة المرور" onPress={handleReset} loading={loading} size="lg" style={{ marginTop: 8 }} />
      </View>
    </SafeScreen>
  );
}

import React, { useState, useEffect, useRef } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { io } from 'socket.io-client';
import { SafeScreen, AppHeader, Avatar } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';
import { useAuthStore } from '../../store';
import { BASE_URL } from '../../api/client';
import type { ChatMessage } from '../../types';

export default function ChatRoomScreen() {
  const nav   = useNavigation<any>();
  const route = useRoute<any>();
  const { roomId, recipientName, recipientAvatar } = route.params;
  const { user } = useAuthStore();

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [text, setText]         = useState('');
  const [connected, setConnected] = useState(false);
  const socketRef = useRef<any>(null);
  const flatRef   = useRef<FlatList>(null);

  useEffect(() => {
    const socket = io(BASE_URL, { transports: ['websocket'] });
    socketRef.current = socket;

    socket.on('connect', () => {
      setConnected(true);
      socket.emit('join_room', roomId);
    });
    socket.on('disconnect', () => setConnected(false));
    socket.on('receive_message', (msg: ChatMessage) => {
      setMessages(prev => [...prev, msg]);
      setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
    });
    socket.on('chat_history', (history: ChatMessage[]) => setMessages(history));

    return () => { socket.disconnect(); };
  }, [roomId]);

  function sendMessage() {
    if (!text.trim() || !socketRef.current) return;
    const msg: ChatMessage = {
      id: Date.now(),
      _id: Date.now(),
      text: text.trim(),
      createdAt: new Date().toISOString(),
      user: { _id: user?.id || 'me', name: user?.name },
    };
    socketRef.current.emit('send_message', { roomId, message: msg });
    setMessages(prev => [...prev, msg]);
    setText('');
    setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
  }

  const isMe = (msg: ChatMessage) => String(msg.user._id) === String(user?.id);

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader
        title={recipientName}
        subtitle={connected ? 'متصل' : 'جارٍ الاتصال...'}
        onBack={() => nav.goBack()}
        rightAction={<Avatar uri={recipientAvatar} name={recipientName} size={34} />}
      />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={80}>
        <FlatList
          ref={flatRef}
          data={messages}
          keyExtractor={(m, i) => String(m._id || i)}
          contentContainerStyle={{ padding: 16, gap: 8 }}
          onLayout={() => flatRef.current?.scrollToEnd({ animated: false })}
          renderItem={({ item: msg }) => {
            const me = isMe(msg);
            return (
              <View style={{ alignItems: me ? 'flex-start' : 'flex-end' }}>
                <View style={[styles.bubble, me ? styles.bubbleMe : styles.bubbleThem]}>
                  <Text style={[styles.bubbleText, me && { color: Colors.white }]}>{msg.text}</Text>
                  <Text style={[styles.bubbleTime, me && { color: 'rgba(255,255,255,0.7)' }]}>
                    {new Date(msg.createdAt).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
                  </Text>
                </View>
              </View>
            );
          }}
        />

        {/* Input Bar */}
        <View style={styles.inputBar}>
          <TextInput
            style={styles.input}
            value={text}
            onChangeText={setText}
            placeholder="اكتب رسالة..."
            placeholderTextColor={Colors.gray400}
            textAlign="right"
            multiline
            maxLength={500}
          />
          <TouchableOpacity onPress={sendMessage} disabled={!text.trim()} style={[styles.sendBtn, !text.trim() && { opacity: 0.4 }]}>
            <Ionicons name="send" size={20} color={Colors.white} style={{ transform: [{ scaleX: -1 }] }} />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeScreen>
  );
}

const styles = StyleSheet.create({
  bubble: { maxWidth: '75%', padding: 10, borderRadius: 16, marginBottom: 2 },
  bubbleMe: { backgroundColor: Colors.primary, borderBottomLeftRadius: 4 },
  bubbleThem: { backgroundColor: Colors.white, borderBottomRightRadius: 4 },
  bubbleText: { fontSize: Typography.base, color: Colors.textPrimary, lineHeight: 22 },
  bubbleTime: { fontSize: Typography.xs, color: Colors.textMuted, marginTop: 4, textAlign: 'left' },
  inputBar: {
    flexDirection: 'row', alignItems: 'flex-end', gap: 10,
    paddingHorizontal: 16, paddingVertical: 10,
    backgroundColor: Colors.white, borderTopWidth: 0.5, borderTopColor: Colors.border,
  },
  input: {
    flex: 1, backgroundColor: Colors.gray50, borderRadius: Radius.xl,
    paddingHorizontal: 14, paddingVertical: 10, fontSize: Typography.base,
    color: Colors.textPrimary, maxHeight: 120, borderWidth: 1, borderColor: Colors.border,
  },
  sendBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center',
  },
});

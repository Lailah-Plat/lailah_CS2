import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card, Avatar } from '../../components/common';
import { Colors, Typography } from '../../theme';

const ROOMS = [
  { id: 'support', name: 'الدعم الفني', sub: 'تحدث مع فريق خدمة العملاء', icon: 'headset-outline', color: Colors.primary },
  { id: 'admin',   name: 'إدارة المنصة', sub: 'استفسارات عامة عن المنصة',  icon: 'business-outline', color: '#10B981' },
];

export default function ChatListScreen() {
  const nav = useNavigation<any>();
  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="المحادثات" />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 12 }}>
        {ROOMS.map(r => (
          <TouchableOpacity key={r.id} onPress={() => nav.navigate('ChatRoom', { roomId: r.id, recipientName: r.name })} activeOpacity={0.85}>
            <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
              <View style={[styles.icon, { backgroundColor: r.color + '18' }]}>
                <Ionicons name={r.icon as any} size={22} color={r.color} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.roomName}>{r.name}</Text>
                <Text style={styles.roomSub}>{r.sub}</Text>
              </View>
              <Ionicons name="chevron-back" size={16} color={Colors.gray300} />
            </Card>
          </TouchableOpacity>
        ))}

        <TouchableOpacity onPress={() => nav.navigate('Support')} activeOpacity={0.85}>
          <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'center', borderWidth: 1, borderColor: Colors.primary, borderStyle: 'dashed' }}>
            <View style={[styles.icon, { backgroundColor: Colors.primaryBg }]}>
              <Ionicons name="ticket-outline" size={22} color={Colors.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.roomName, { color: Colors.primary }]}>تذاكر الدعم الفني</Text>
              <Text style={styles.roomSub}>متابعة طلبات الدعم والمشاكل</Text>
            </View>
            <Ionicons name="chevron-back" size={16} color={Colors.primary} />
          </Card>
        </TouchableOpacity>
      </ScrollView>
    </SafeScreen>
  );
}
const styles = StyleSheet.create({
  icon: { width: 48, height: 48, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  roomName: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary },
  roomSub: { fontSize: Typography.xs, color: Colors.textSecondary, marginTop: 3 },
});

import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, RefreshControl } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeScreen, AppHeader, Card, EmptyState } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';
import { walletApi } from '../../api';
import type { Wallet, WalletTransaction } from '../../types';

export default function WalletScreen() {
  const nav = useNavigation<any>();
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { load(); }, []);
  async function load() {
    try { const w = await walletApi.get(); setWallet(w); }
    catch {}
    finally { setLoading(false); setRefreshing(false); }
  }

  const txIcon = (type: string) => type === 'credit' ? 'arrow-down-circle' : 'arrow-up-circle';
  const txColor = (type: string) => type === 'credit' ? Colors.success : Colors.error;

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="محفظتي" onBack={() => nav.goBack()} />
      <ScrollView refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} colors={[Colors.primary]} />} showsVerticalScrollIndicator={false}>

        {/* Balance Card */}
        <LinearGradient colors={['#10B981', '#059669']} style={styles.balanceCard}>
          <Text style={styles.balanceLabel}>الرصيد المتاح</Text>
          <Text style={styles.balanceAmount}>{(wallet?.balance || 0).toLocaleString()}</Text>
          <Text style={styles.balanceCurrency}>ريال سعودي</Text>
          <View style={styles.balanceRow}>
            <View style={styles.balanceStat}>
              <Text style={styles.balanceStatLabel}>محجوز</Text>
              <Text style={styles.balanceStatVal}>{(wallet?.heldBalance || 0).toLocaleString()} ر.س</Text>
            </View>
            <View style={[styles.balanceStat, { borderRightWidth: 0 }]}>
              <Text style={styles.balanceStatLabel}>المعاملات</Text>
              <Text style={styles.balanceStatVal}>{wallet?.transactions?.length || 0}</Text>
            </View>
          </View>
        </LinearGradient>

        {/* Transactions */}
        <Text style={styles.sectionTitle}>سجل المعاملات</Text>
        {(!wallet?.transactions || wallet.transactions.length === 0) ? (
          <EmptyState icon="receipt-outline" title="لا توجد معاملات" subtitle="ستظهر هنا جميع معاملات محفظتك" />
        ) : (
          <Card style={{ marginHorizontal: 16, padding: 0, overflow: 'hidden' }}>
            {wallet.transactions.map((tx, i) => (
              <View key={i} style={[styles.txRow, i < wallet.transactions.length - 1 && styles.txBorder]}>
                <View style={[styles.txIcon, { backgroundColor: txColor(tx.type) + '18' }]}>
                  <Ionicons name={txIcon(tx.type) as any} size={20} color={txColor(tx.type)} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.txDesc}>{tx.description}</Text>
                  <Text style={styles.txDate}>{new Date(tx.createdAt).toLocaleDateString('ar-SA')}</Text>
                </View>
                <Text style={[styles.txAmount, { color: txColor(tx.type) }]}>
                  {tx.type === 'credit' ? '+' : '-'}{Number(tx.amount).toLocaleString()} ر.س
                </Text>
              </View>
            ))}
          </Card>
        )}

        <View style={{ height: 32 }} />
      </ScrollView>
    </SafeScreen>
  );
}

const styles = StyleSheet.create({
  balanceCard: { margin: 16, borderRadius: 20, padding: 24, alignItems: 'center' },
  balanceLabel: { color: 'rgba(255,255,255,0.85)', fontSize: Typography.sm, marginBottom: 8 },
  balanceAmount: { color: Colors.white, fontSize: 48, fontWeight: Typography.bold },
  balanceCurrency: { color: 'rgba(255,255,255,0.8)', fontSize: Typography.base, marginTop: 4 },
  balanceRow: { flexDirection: 'row', marginTop: 20, borderTopWidth: 0.5, borderTopColor: 'rgba(255,255,255,0.3)', paddingTop: 16, width: '100%' },
  balanceStat: { flex: 1, alignItems: 'center', borderRightWidth: 0.5, borderRightColor: 'rgba(255,255,255,0.3)' },
  balanceStatLabel: { color: 'rgba(255,255,255,0.75)', fontSize: Typography.xs },
  balanceStatVal: { color: Colors.white, fontSize: Typography.base, fontWeight: Typography.semibold, marginTop: 2 },
  sectionTitle: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary, margin: 16, marginBottom: 8 },
  txRow: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 },
  txBorder: { borderBottomWidth: 0.5, borderBottomColor: Colors.border },
  txIcon: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  txDesc: { fontSize: Typography.base, color: Colors.textPrimary, fontWeight: Typography.medium },
  txDate: { fontSize: Typography.xs, color: Colors.textSecondary, marginTop: 2 },
  txAmount: { fontSize: Typography.base, fontWeight: Typography.bold },
});

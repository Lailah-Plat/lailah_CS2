import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Radius } from '../theme';

const { width } = Dimensions.get('window');
const SLIDES = [
  { id: '1', title: 'اكتشف القاعات', desc: 'استعرض مئات القاعات في منطقتك بكل سهولة', icon: 'search', color: '#6B21A8' },
  { id: '2', title: 'احجز بنقرة', desc: 'اختر موعدك وادفع بأمان عبر بوابات دفع موثوقة', icon: 'calendar', color: '#EC4899' },
  { id: '3', title: 'تابع حجوزاتك', desc: 'استقبل إشعارات لحظية وتتبع حجوزاتك من أي مكان', icon: 'notifications', color: '#8B5CF6' },
];

export default function OnboardingScreen({ onDone }: { onDone?: () => void }) {
  const [current, setCurrent] = useState(0);
  const flatRef = useRef<FlatList>(null);

  function next() {
    if (current < SLIDES.length - 1) {
      flatRef.current?.scrollToIndex({ index: current + 1 });
      setCurrent(c => c + 1);
    } else { onDone?.(); }
  }

  return (
    <View style={{ flex: 1, backgroundColor: Colors.white }}>
      <FlatList ref={flatRef} data={SLIDES} horizontal pagingEnabled showsHorizontalScrollIndicator={false}
        onMomentumScrollEnd={e => setCurrent(Math.round(e.nativeEvent.contentOffset.x / width))}
        renderItem={({ item }) => (
          <View style={{ width, alignItems: 'center', justifyContent: 'center', padding: 40 }}>
            <View style={[styles.slideIcon, { backgroundColor: item.color + '18' }]}>
              <Ionicons name={item.icon as any} size={56} color={item.color} />
            </View>
            <Text style={styles.slideTitle}>{item.title}</Text>
            <Text style={styles.slideDesc}>{item.desc}</Text>
          </View>
        )}
        keyExtractor={i => i.id}
      />
      <View style={styles.footer}>
        <View style={styles.dots}>{SLIDES.map((_, i) => <View key={i} style={[styles.dot, i === current && styles.dotActive]} />)}</View>
        <TouchableOpacity onPress={next} style={styles.nextBtn}>
          <Text style={styles.nextText}>{current === SLIDES.length - 1 ? 'ابدأ الآن' : 'التالي'}</Text>
          <Ionicons name="arrow-back" size={18} color={Colors.white} />
        </TouchableOpacity>
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  slideIcon: { width: 120, height: 120, borderRadius: 60, alignItems: 'center', justifyContent: 'center', marginBottom: 32 },
  slideTitle: { fontSize: Typography['3xl'], fontWeight: Typography.bold, color: Colors.textPrimary, textAlign: 'center', marginBottom: 12 },
  slideDesc: { fontSize: Typography.base, color: Colors.textSecondary, textAlign: 'center', lineHeight: 26 },
  footer: { padding: 32, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  dots: { flexDirection: 'row', gap: 6 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.gray200 },
  dotActive: { width: 24, backgroundColor: Colors.primary },
  nextBtn: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: Colors.primary, paddingHorizontal: 24, paddingVertical: 12, borderRadius: Radius.xl },
  nextText: { color: Colors.white, fontSize: Typography.base, fontWeight: Typography.semibold },
});

import React, { useState } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';
import { api } from '../../api/client';

interface Msg { id: number; role: 'user' | 'assistant'; content: string; }

const SUGGESTIONS = ['ابحث لي عن قاعة للأفراح في الرياض','ما أسعار قاعات المؤتمرات؟','أريد حجز قاعة لـ 200 ضيف','ما طرق الدفع المتاحة؟'];

export default function SmartAssistantScreen() {
  const nav = useNavigation<any>();
  const [messages, setMessages] = useState<Msg[]>([
    { id: 0, role: 'assistant', content: 'مرحباً! أنا مساعدك الذكي في منصة ليلة 🌙\n\nيمكنني مساعدتك في:\n• البحث عن القاعات المناسبة\n• الاستفسار عن الأسعار والمواعيد\n• شرح خطوات الحجز والدفع\n• أي سؤال يخص منصة ليلة\n\nبماذا تريد مساعدة؟' },
  ]);
  const [input, setInput]   = useState('');
  const [loading, setLoading] = useState(false);
  const flatRef = React.useRef<FlatList>(null);

  async function send(text?: string) {
    const msg = text || input.trim();
    if (!msg) return;
    setInput('');
    const userMsg: Msg = { id: Date.now(), role: 'user', content: msg };
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    try {
      const res = await api.post('/api/ai/chat', {
        message: msg,
        history: messages.slice(-6).map(m => ({ role: m.role, content: m.content })),
      });
      setMessages(prev => [...prev, { id: Date.now() + 1, role: 'assistant', content: res.reply || res.message || 'عذراً، لم أفهم سؤالك. حاول مرة أخرى.' }]);
    } catch {
      setMessages(prev => [...prev, { id: Date.now() + 1, role: 'assistant', content: 'عذراً، حدث خطأ مؤقت. حاول مرة أخرى.' }]);
    } finally {
      setLoading(false);
      setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
    }
  }

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="المساعد الذكي ✨" onBack={() => nav.goBack()} />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={80}>
        <FlatList
          ref={flatRef}
          data={messages}
          keyExtractor={m => String(m.id)}
          contentContainerStyle={{ padding: 16, gap: 10 }}
          renderItem={({ item: m }) => (
            <View style={{ alignItems: m.role === 'user' ? 'flex-start' : 'flex-end' }}>
              {m.role === 'assistant' && (
                <View style={styles.aiAvatar}>
                  <Text style={{ fontSize: 14 }}>🌙</Text>
                </View>
              )}
              <View style={[styles.bubble, m.role === 'user' ? styles.userBubble : styles.aiBubble]}>
                <Text style={[styles.bubbleText, m.role === 'user' && { color: Colors.white }]}>{m.content}</Text>
              </View>
            </View>
          )}
          ListFooterComponent={loading ? (
            <View style={[styles.bubble, styles.aiBubble, { width: 70 }]}>
              <Text style={{ color: Colors.textSecondary, letterSpacing: 4 }}>●●●</Text>
            </View>
          ) : null}
        />

        {messages.length === 1 && (
          <View style={{ paddingHorizontal: 16, paddingBottom: 8 }}>
            <Text style={{ fontSize: Typography.xs, color: Colors.textSecondary, marginBottom: 8 }}>اقتراحات:</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {SUGGESTIONS.map((s, i) => (
                <TouchableOpacity key={i} onPress={() => send(s)} style={styles.suggestion}>
                  <Text style={{ fontSize: Typography.xs, color: Colors.primary }}>{s}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        <View style={styles.inputBar}>
          <TextInput
            style={styles.input} value={input} onChangeText={setInput}
            placeholder="اكتب سؤالك هنا..." placeholderTextColor={Colors.gray400}
            textAlign="right" onSubmitEditing={() => send()} returnKeyType="send"
          />
          <TouchableOpacity onPress={() => send()} disabled={!input.trim() || loading} style={[styles.sendBtn, (!input.trim() || loading) && { opacity: 0.4 }]}>
            <Ionicons name="send" size={18} color={Colors.white} style={{ transform: [{ scaleX: -1 }] }} />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeScreen>
  );
}

const styles = StyleSheet.create({
  aiAvatar: { width: 28, height: 28, borderRadius: 14, backgroundColor: Colors.primaryBg, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  bubble: { maxWidth: '80%', padding: 12, borderRadius: 16, marginBottom: 2 },
  userBubble: { backgroundColor: Colors.primary, borderBottomLeftRadius: 4, alignSelf: 'flex-end' },
  aiBubble: { backgroundColor: Colors.white, borderBottomRightRadius: 4 },
  bubbleText: { fontSize: Typography.base, color: Colors.textPrimary, lineHeight: 22 },
  suggestion: { backgroundColor: Colors.primaryBg, paddingHorizontal: 12, paddingVertical: 7, borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.primaryLight },
  inputBar: { flexDirection: 'row', gap: 10, padding: 12, backgroundColor: Colors.white, borderTopWidth: 0.5, borderTopColor: Colors.border },
  input: { flex: 1, backgroundColor: Colors.gray50, borderRadius: Radius.xl, paddingHorizontal: 14, paddingVertical: 10, fontSize: Typography.base, color: Colors.textPrimary, borderWidth: 1, borderColor: Colors.border },
  sendBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center' },
});

import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card } from '../../components/common';
import { Colors, Typography } from '../../theme';
import { paymentApi } from '../../api';

const ALL_METHODS = [
  { id: 'moyasar', nameAr: 'مدى', desc: 'بطاقات مدى والبطاقات الائتمانية', icon: 'card-outline', color: '#1A56DB' },
  { id: 'applepay', nameAr: 'Apple Pay', desc: 'الدفع بواسطة Apple Pay', icon: 'logo-apple', color: '#000' },
  { id: 'tabby', nameAr: 'تابي', desc: 'قسّم على 4 دفعات بدون فوائد', icon: 'layers-outline', color: '#3BB273' },
  { id: 'tamara', nameAr: 'تمارة', desc: 'ادفع لاحقاً أو قسّم', icon: 'time-outline', color: '#FF6B35' },
  { id: 'paytabs', nameAr: 'PayTabs', desc: 'فيزا وماستركارد الدولية', icon: 'globe-outline', color: '#6B21A8' },
  { id: 'hyperpay', nameAr: 'HyperPay', desc: 'بوابة دفع متكاملة', icon: 'flash-outline', color: '#E91E63' },
];

export default function PaymentMethodsScreen() {
  const nav = useNavigation<any>();
  const [active, setActive] = useState<string[]>([]);

  useEffect(() => {
    paymentApi.getGateways().then(res => setActive(res.gateways || [])).catch(() => setActive(['moyasar']));
  }, []);

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="طرق الدفع المتاحة" onBack={() => nav.goBack()} />
      <FlatList
        data={ALL_METHODS}
        keyExtractor={m => m.id}
        contentContainerStyle={{ padding: 16, gap: 10 }}
        ListHeaderComponent={<Text style={{ fontSize: Typography.sm, color: Colors.textSecondary, marginBottom: 4 }}>طرق الدفع المُفعَّلة من إدارة المنصة</Text>}
        renderItem={({ item }) => {
          const isActive = active.includes(item.id);
          return (
            <Card style={[styles.methodCard, !isActive && { opacity: 0.5 }]}>
              <View style={[styles.methodIcon, { backgroundColor: item.color + '18' }]}>
                <Ionicons name={item.icon as any} size={22} color={item.color} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.methodName}>{item.nameAr}</Text>
                <Text style={styles.methodDesc}>{item.desc}</Text>
              </View>
              {isActive
                ? <Ionicons name="checkmark-circle" size={22} color={Colors.success} />
                : <Text style={{ fontSize: Typography.xs, color: Colors.textMuted }}>غير متاح</Text>
              }
            </Card>
          );
        }}
      />
    </SafeScreen>
  );
}
const styles = StyleSheet.create({
  methodCard: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  methodIcon: { width: 46, height: 46, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  methodName: { fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary },
  methodDesc: { fontSize: Typography.xs, color: Colors.textSecondary, marginTop: 2 },
});

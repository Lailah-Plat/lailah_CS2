import React, { useState } from 'react';
import { ScrollView, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import * as ImagePicker from 'expo-image-picker';
import { SafeScreen, AppHeader, Input, Button, Avatar } from '../../components/common';
import { Colors } from '../../theme';
import { userApi } from '../../api';
import { useAuthStore } from '../../store';

export default function EditProfileScreen() {
  const nav = useNavigation<any>();
  const { user, updateUser } = useAuthStore();
  const [form, setForm] = useState({ name: user?.name || '', phone: user?.phone || '', city: user?.city || '', region: user?.region || '' });
  const [loading, setLoading] = useState(false);

  function set(k: string, v: string) { setForm(f => ({ ...f, [k]: v })); }

  async function pickAvatar() {
    const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.8 });
    if (!res.canceled && res.assets[0]) {
      try { const data = await userApi.uploadAvatar(res.assets[0].uri); if (data.url) updateUser({ avatarUrl: data.url }); }
      catch {}
    }
  }

  async function save() {
    if (!form.name.trim()) return Alert.alert('', 'الاسم مطلوب');
    setLoading(true);
    try {
      const updated = await userApi.updateProfile(form);
      updateUser(updated);
      Alert.alert('✅ تم الحفظ', 'تم تحديث ملفك الشخصي', [{ text: 'حسناً', onPress: () => nav.goBack() }]);
    } catch (e: any) { Alert.alert('خطأ', e.message); }
    finally { setLoading(false); }
  }

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="تعديل الملف الشخصي" onBack={() => nav.goBack()} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: 16, gap: 14, alignItems: 'center' }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <Avatar uri={user?.avatarUrl} name={user?.name} size={88} style={{ marginBottom: 4 }} />
          <Button label="تغيير الصورة" onPress={pickAvatar} variant="outline" size="sm" icon="camera-outline" />
          <Input label="الاسم الكامل" placeholder="محمد عبدالله" value={form.name} onChangeText={v => set('name', v)} icon="person-outline" />
          <Input label="رقم الجوال" placeholder="05xxxxxxxx" value={form.phone} onChangeText={v => set('phone', v)} keyboardType="phone-pad" icon="call-outline" />
          <Input label="المنطقة" placeholder="الرياض" value={form.region} onChangeText={v => set('region', v)} icon="map-outline" />
          <Input label="المدينة" placeholder="الرياض" value={form.city} onChangeText={v => set('city', v)} icon="location-outline" />
          <Button label="حفظ التغييرات" onPress={save} loading={loading} size="lg" style={{ width: '100%', marginTop: 8 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeScreen>
  );
}

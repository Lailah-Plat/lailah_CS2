import React, { useEffect, useState } from 'react';
import { FlatList, TouchableOpacity, View, Text, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card, EmptyState, Stars } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';
import { favoritesApi } from '../../api';
import { useFavoritesStore } from '../../store';

export default function FavoritesScreen() {
  const nav = useNavigation<any>();
  const { favorites: favIds, toggleFavorite } = useFavoritesStore();
  const [halls, setHalls] = useState<any[]>([]);

  useEffect(() => {
    favoritesApi.getAll().then(res => setHalls(res.favorites || [])).catch(() => {});
  }, []);

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title={`المفضلة (${halls.length})`} onBack={() => nav.goBack()} />
      <FlatList
        data={halls}
        keyExtractor={h => String(h.id)}
        contentContainerStyle={{ padding: 16, gap: 12, flexGrow: 1 }}
        ListEmptyComponent={<EmptyState icon="heart-outline" title="لا توجد قاعات مفضلة" subtitle="أضف قاعات لمفضلتك للوصول إليها بسرعة" action={{ label: 'استعرض القاعات', onPress: () => nav.navigate('ExploreTab') }} />}
        renderItem={({ item: h }) => (
          <TouchableOpacity onPress={() => nav.navigate('ExploreTab', { screen: 'HallDetails', params: { hallId: h.hallId || h.id } })} activeOpacity={0.85}>
            <Card style={{ flexDirection: 'row', gap: 12 }}>
              <View style={{ width: 70, height: 70, borderRadius: 12, backgroundColor: Colors.primaryBg, alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name="business" size={28} color={Colors.primaryLight} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: Typography.base, fontWeight: Typography.semibold, color: Colors.textPrimary }}>{h.hallName || h.name}</Text>
                <Text style={{ fontSize: Typography.sm, color: Colors.textSecondary, marginTop: 3 }}>{h.city}</Text>
                {h.rating && <Stars rating={h.rating} size={12} />}
              </View>
              <TouchableOpacity onPress={() => toggleFavorite(h.hallId || h.id)}>
                <Ionicons name="heart" size={22} color="#FF4B6E" />
              </TouchableOpacity>
            </Card>
          </TouchableOpacity>
        )}
      />
    </SafeScreen>
  );
}

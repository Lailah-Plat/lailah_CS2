import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Switch, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, AppHeader, Card } from '../../components/common';
import { Colors, Typography } from '../../theme';
import { useAppSettingsStore, useAuthStore } from '../../store';

export default function SettingsScreen() {
  const nav = useNavigation<any>();
  const { pushEnabled, setPushEnabled, biometricEnabled, setBiometricEnabled } = useAppSettingsStore();
  const { logout } = useAuthStore();

  return (
    <SafeScreen bg={Colors.bg}>
      <AppHeader title="الإعدادات" onBack={() => nav.goBack()} />
      <View style={{ padding: 16, gap: 12 }}>
        <Card style={{ gap: 0, padding: 0, overflow: 'hidden' }}>
          <ToggleRow icon="notifications-outline" label="الإشعارات" value={pushEnabled} onChange={setPushEnabled} color={Colors.primary} />
          <ToggleRow icon="finger-print" label="الدخول بالبصمة" value={biometricEnabled} onChange={setBiometricEnabled} color="#10B981" bordered />
        </Card>
        <Card style={{ gap: 0, padding: 0, overflow: 'hidden' }}>
          <ActionRow icon="lock-closed-outline" label="تغيير كلمة المرور" onPress={() => Alert.alert('قريباً')} color={Colors.primary} />
          <ActionRow icon="trash-outline" label="حذف الحساب" onPress={() => Alert.alert('حذف الحساب', 'هذا الإجراء لا يمكن التراجع عنه', [{ text: 'إلغاء', style: 'cancel' }, { text: 'حذف', style: 'destructive', onPress: logout }])} color={Colors.error} bordered />
        </Card>
      </View>
    </SafeScreen>
  );
}

function ToggleRow({ icon, label, value, onChange, color, bordered }: any) {
  return (
    <View style={[styles.row, bordered && styles.borderTop]}>
      <View style={[styles.ico, { backgroundColor: color + '18' }]}>
        <Ionicons name={icon} size={18} color={color} />
      </View>
      <Text style={styles.label}>{label}</Text>
      <Switch value={value} onValueChange={onChange} trackColor={{ true: Colors.primaryLight }} thumbColor={value ? Colors.primary : Colors.white} />
    </View>
  );
}
function ActionRow({ icon, label, onPress, color, bordered }: any) {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.row, bordered && styles.borderTop]}>
      <View style={[styles.ico, { backgroundColor: color + '18' }]}>
        <Ionicons name={icon} size={18} color={color} />
      </View>
      <Text style={[styles.label, { color }]}>{label}</Text>
      <Ionicons name="chevron-back" size={16} color={Colors.gray300} />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 },
  borderTop: { borderTopWidth: 0.5, borderTopColor: Colors.border },
  ico: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  label: { flex: 1, fontSize: Typography.base, color: Colors.textPrimary, fontWeight: Typography.medium },
});

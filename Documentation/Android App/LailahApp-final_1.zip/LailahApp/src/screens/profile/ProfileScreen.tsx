import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Switch, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeScreen, Avatar, Card } from '../../components/common';
import { Colors, Typography, Radius } from '../../theme';
import { useAuthStore, useAppSettingsStore } from '../../store';

const MENU = [
  { title: 'حسابي', items: [
    { icon: 'person-outline', label: 'تعديل الملف الشخصي', screen: 'EditProfile', color: Colors.primary },
    { icon: 'wallet-outline', label: 'محفظتي', screen: 'Wallet', color: '#10B981' },
    { icon: 'heart-outline', label: 'المفضلة', screen: 'Favorites', color: '#EC4899' },
    { icon: 'calendar-outline', label: 'التقويم الذكي', screen: 'Calendar', color: '#F59E0B' },
    { icon: 'sparkles-outline', label: 'المساعد الذكي', screen: 'SmartAssistant', color: '#8B5CF6' },
  ]},
  { title: 'الدفع', items: [
    { icon: 'card-outline', label: 'طرق الدفع المتاحة', screen: 'PaymentMethods', color: '#3B82F6' },
  ]},
  { title: 'الدعم والمساعدة', items: [
    { icon: 'chatbubble-outline', label: 'تواصل معنا', screen: 'ContactUs', color: Colors.primary },
    { icon: 'help-circle-outline', label: 'الأسئلة الشائعة', screen: 'FAQ', color: '#10B981' },
  ]},
  { title: 'عن التطبيق', items: [
    { icon: 'information-circle-outline', label: 'من نحن', screen: 'About', color: Colors.primary },
    { icon: 'document-text-outline', label: 'الشروط والأحكام', screen: 'Terms', color: Colors.gray600 },
    { icon: 'shield-outline', label: 'سياسة الخصوصية', screen: 'Privacy', color: Colors.gray600 },
  ]},
];

export default function ProfileScreen() {
  const nav = useNavigation<any>();
  const { user, logout } = useAuthStore();
  const { pushEnabled, setPushEnabled } = useAppSettingsStore();

  return (
    <SafeScreen bg={Colors.bg}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>
        {/* Header */}
        <View style={styles.header}>
          <Avatar uri={user?.avatarUrl} name={user?.name} size={72} />
          <Text style={styles.name}>{user?.name}</Text>
          <Text style={styles.email}>{user?.email}</Text>
          <TouchableOpacity onPress={() => nav.navigate('EditProfile')} style={styles.editBtn}>
            <Text style={styles.editBtnText}>تعديل الملف الشخصي</Text>
          </TouchableOpacity>
        </View>

        {/* Push toggle */}
        <Card style={{ marginHorizontal: 16, marginTop: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <View style={[styles.ico, { backgroundColor: Colors.primaryBg }]}>
              <Ionicons name="notifications-outline" size={18} color={Colors.primary} />
            </View>
            <Text style={{ fontSize: Typography.base, color: Colors.textPrimary }}>الإشعارات</Text>
          </View>
          <Switch value={pushEnabled} onValueChange={setPushEnabled} trackColor={{ true: Colors.primaryLight }} thumbColor={pushEnabled ? Colors.primary : Colors.white} />
        </Card>

        {MENU.map((section, si) => (
          <View key={si} style={{ marginTop: 16, marginHorizontal: 16 }}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <Card style={{ padding: 0, overflow: 'hidden' }}>
              {section.items.map((item, ii) => (
                <TouchableOpacity key={ii} onPress={() => nav.navigate(item.screen)} style={[styles.row, ii < section.items.length - 1 && styles.rowBorder]}>
                  <View style={[styles.ico, { backgroundColor: item.color + '18' }]}>
                    <Ionicons name={item.icon as any} size={18} color={item.color} />
                  </View>
                  <Text style={styles.rowLabel}>{item.label}</Text>
                  <Ionicons name="chevron-back" size={16} color={Colors.gray300} />
                </TouchableOpacity>
              ))}
            </Card>
          </View>
        ))}

        <TouchableOpacity onPress={() => Alert.alert('تسجيل الخروج', 'هل تريد الخروج؟', [{ text: 'إلغاء', style: 'cancel' }, { text: 'خروج', style: 'destructive', onPress: logout }])} style={styles.logoutBtn}>
          <Ionicons name="log-out-outline" size={20} color={Colors.error} />
          <Text style={{ color: Colors.error, fontWeight: Typography.semibold, fontSize: Typography.base }}>تسجيل الخروج</Text>
        </TouchableOpacity>
        <Text style={{ textAlign: 'center', color: Colors.textMuted, fontSize: Typography.xs, marginTop: 8 }}>الإصدار 1.0.0 — ليلة © 2026</Text>
      </ScrollView>
    </SafeScreen>
  );
}

const styles = StyleSheet.create({
  header: { alignItems: 'center', paddingVertical: 28, backgroundColor: Colors.white, borderBottomWidth: 0.5, borderBottomColor: Colors.border },
  name: { fontSize: Typography.xl, fontWeight: Typography.bold, color: Colors.textPrimary, marginTop: 10 },
  email: { fontSize: Typography.sm, color: Colors.textSecondary, marginTop: 4 },
  editBtn: { marginTop: 12, paddingHorizontal: 20, paddingVertical: 8, borderRadius: Radius.full, borderWidth: 1.5, borderColor: Colors.primary },
  editBtnText: { color: Colors.primary, fontSize: Typography.sm, fontWeight: Typography.medium },
  ico: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  sectionTitle: { fontSize: Typography.xs, color: Colors.textMuted, fontWeight: Typography.semibold, marginBottom: 8, textTransform: 'uppercase' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingVertical: 14 },
  rowBorder: { borderBottomWidth: 0.5, borderBottomColor: Colors.border },
  rowLabel: { flex: 1, fontSize: Typography.base, color: Colors.textPrimary },
  logoutBtn: { flexDirection: 'row', alignItems: 'center', gap: 10, justifyContent: 'center', margin: 16, padding: 14, borderRadius: Radius.xl, backgroundColor: Colors.errorBg },
});

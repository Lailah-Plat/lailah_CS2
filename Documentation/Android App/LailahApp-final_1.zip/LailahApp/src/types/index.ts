// ===================================================
// Types — منصة ليلة (تطبيق الجوال)
// ===================================================

// ===== Auth =====
export interface User {
  id: number | string;
  name: string;
  email: string;
  phone?: string;
  role: 'عميل' | 'customer' | 'admin' | 'provider';
  region?: string;
  city?: string;
  iban?: string;
  avatarUrl?: string;
  status?: string;
  nationalId?: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

// ===== Halls =====
export interface Hall {
  id: number | string;
  name: string;
  type: string;
  description?: string;
  city: string;
  region?: string;
  address?: string;
  capacity: number;
  hourlyRate: number;
  images: string[];
  rating?: number;
  reviewCount?: number;
  amenities?: string[];
  latitude?: number;
  longitude?: number;
  providerId?: number;
  providerName?: string;
  status: 'active' | 'inactive';
  isVatEnabled?: boolean;
  vatRate?: number;
  isFavorite?: boolean;
  minGuests?: number;
  maxGuests?: number;
  availableDates?: string[];
}

// ===== Services =====
export interface Service {
  id: number | string;
  name: string;
  description?: string;
  category: string;
  price: number;
  unit?: string;
  quantity?: number;
  image?: string;
  hallId?: number | string;
  providerId?: number;
  isIndependent?: boolean;
  rating?: number;
  status: 'active' | 'inactive';
}

// ===== Bookings =====
export type BookingStatus =
  | 'pending'
  | 'pending_payment'
  | 'confirmed'
  | 'completed'
  | 'cancelled'
  | 'rejected';

export interface BookingService {
  serviceId: number | string;
  serviceName: string;
  quantity: number;
  price: number;
  total: number;
}

export interface Booking {
  id: number | string;
  bookingRef?: string;
  hallId: number | string;
  hallName: string;
  hallImage?: string;
  userId: number | string;
  customerName?: string;
  startTime: string;
  endTime: string;
  guests: number;
  status: BookingStatus;
  totalAmount: number;
  hallAmount?: number;
  servicesAmount?: number;
  vatAmount?: number;
  services?: BookingService[];
  notes?: string;
  paymentMethod?: string;
  paymentId?: string;
  invoiceUrl?: string;
  createdAt: string;
  updatedAt?: string;
  cancellationReason?: string;
}

// ===== Service Requests =====
export type ServiceRequestStatus = 'pending' | 'accepted' | 'rejected' | 'in_progress' | 'completed';

export interface ServiceRequest {
  id: number | string;
  requestRef?: string;
  serviceId: number | string;
  serviceName: string;
  userId: number | string;
  customerName?: string;
  quantity: number;
  totalAmount: number;
  status: ServiceRequestStatus;
  eventDate?: string;
  notes?: string;
  address?: string;
  createdAt: string;
}

// ===== Wallet =====
export interface WalletTransaction {
  id: number | string;
  type: 'credit' | 'debit';
  amount: number;
  description: string;
  reference?: string;
  createdAt: string;
  balance?: number;
}

export interface Wallet {
  balance: number;
  heldBalance: number;
  totalDeposited: number;
  totalWithdrawn: number;
  transactions: WalletTransaction[];
}

// ===== Notifications =====
export type NotificationType = 'booking' | 'payment' | 'system' | 'review' | 'support' | 'chat';

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  body: string;
  read: boolean;
  data?: Record<string, any>;
  createdAt: string;
}

// ===== Chat / Support =====
export interface ChatMessage {
  id: string | number;
  _id: string | number;
  text: string;
  createdAt: Date | string;
  user: {
    _id: string | number;
    name?: string;
    avatar?: string;
  };
  pending?: boolean;
  sent?: boolean;
  received?: boolean;
  image?: string;
  file?: string;
}

export interface SupportTicket {
  id: number | string;
  subject: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  priority: 'low' | 'medium' | 'high';
  messages: ChatMessage[];
  createdAt: string;
  updatedAt?: string;
}

// ===== Review =====
export interface Review {
  id: number | string;
  hallId: number | string;
  userId: number | string;
  customerName?: string;
  rating: number;
  comment?: string;
  images?: string[];
  createdAt: string;
  response?: string;
}

// ===== Payment =====
export type PaymentGateway = 'moyasar' | 'hyperpay' | 'geidea' | 'paytabs' | 'tabby' | 'tamara';

export interface PaymentMethod {
  id: PaymentGateway;
  name: string;
  nameAr: string;
  logo: string;
  isActive: boolean;
  supportsBNPL?: boolean;
}

export interface Invoice {
  id: number | string;
  invoiceRef: string;
  bookingId?: number | string;
  serviceRequestId?: number | string;
  customerName: string;
  items: Array<{ name: string; qty: number; unitPrice: number; total: number }>;
  subtotal: number;
  vatRate: number;
  vatAmount: number;
  totalAmount: number;
  status: 'paid' | 'unpaid' | 'cancelled';
  issuedAt: string;
  dueDate?: string;
  qrCode?: string;
  zatcaHash?: string;
}

// ===== Navigation =====
export type RootStackParamList = {
  Splash: undefined;
  Onboarding: undefined;
  Auth: undefined;
  Main: undefined;
};

export type AuthStackParamList = {
  Login: undefined;
  Register: undefined;
  OtpVerify: { email: string; phone?: string };
  ForgotPassword: undefined;
  ResetPassword: { email: string; otp: string };
};

export type MainTabParamList = {
  HomeTab: undefined;
  ExploreTab: undefined;
  BookingsTab: undefined;
  ChatTab: undefined;
  ProfileTab: undefined;
};

export type HomeStackParamList = {
  Home: undefined;
  Notifications: undefined;
};

export type ExploreStackParamList = {
  Explore: undefined;
  HallDetails: { hallId: number | string };
  HallGallery: { images: string[]; index?: number };
  HallReviews: { hallId: number | string; hallName: string };
  HallMap: { hall: Hall };
  ServicesExplore: undefined;
  ServiceDetails: { service: Service };
};

export type BookingStackParamList = {
  MyBookings: undefined;
  BookingDetails: { bookingId: number | string };
  CreateBooking: { hall: Hall };
  BookingCalendar: { hallId: number | string };
  BookingServices: { hallId: number | string; bookingData: Partial<Booking> };
  BookingPayment: { booking: Partial<Booking>; amount: number };
  BookingConfirmation: { booking: Booking };
  InvoiceView: { invoice: Invoice };
  ServiceRequests: undefined;
  ServiceRequestDetails: { requestId: number | string };
  CreateServiceRequest: { service: Service };
};

export type ChatStackParamList = {
  ChatList: undefined;
  ChatRoom: { roomId: string; recipientName: string; recipientAvatar?: string };
  SupportTickets: undefined;
  SupportTicketDetail: { ticketId: number | string };
  NewSupportTicket: undefined;
};

export type ProfileStackParamList = {
  Profile: undefined;
  EditProfile: undefined;
  Wallet: undefined;
  Favorites: undefined;
  Calendar: undefined;
  SmartAssistant: undefined;
  PaymentMethods: undefined;
  Settings: undefined;
  About: undefined;
  Terms: undefined;
  Privacy: undefined;
  ContactUs: undefined;
  FAQ: undefined;
};

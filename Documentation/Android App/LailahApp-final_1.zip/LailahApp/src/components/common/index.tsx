/**
 * Common Components — مكوّنات مشتركة
 */
import React from 'react';
import {
  View, Text, TouchableOpacity, ActivityIndicator,
  StyleSheet, TextInput, Image, ScrollView,
  Platform, StatusBar,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, Radius, Shadow } from '../../theme';

// ===== SafeScreen =====
export function SafeScreen({
  children, style, bg = Colors.bg, statusBarStyle = 'dark-content',
}: {
  children: React.ReactNode;
  style?: any;
  bg?: string;
  statusBarStyle?: 'dark-content' | 'light-content';
}) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[{ flex: 1, backgroundColor: bg, paddingTop: insets.top }, style]}>
      <StatusBar barStyle={statusBarStyle} backgroundColor={bg} />
      {children}
    </View>
  );
}

// ===== Header =====
export function AppHeader({
  title, subtitle, onBack, rightAction, transparent = false,
}: {
  title?: string;
  subtitle?: string;
  onBack?: () => void;
  rightAction?: React.ReactNode;
  transparent?: boolean;
}) {
  return (
    <View style={[styles.header, transparent && { backgroundColor: 'transparent' }]}>
      {onBack ? (
        <TouchableOpacity onPress={onBack} style={styles.headerBtn}>
          <Ionicons name="arrow-back" size={22} color={Colors.textPrimary} />
        </TouchableOpacity>
      ) : <View style={styles.headerBtn} />}
      <View style={{ flex: 1, alignItems: 'center' }}>
        {title && <Text style={styles.headerTitle}>{title}</Text>}
        {subtitle && <Text style={styles.headerSubtitle}>{subtitle}</Text>}
      </View>
      <View style={styles.headerBtn}>{rightAction}</View>
    </View>
  );
}

// ===== Button =====
export function Button({
  label, onPress, variant = 'primary', size = 'md', loading = false,
  disabled = false, icon, style,
}: {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  disabled?: boolean;
  icon?: string;
  style?: any;
}) {
  const bgMap = {
    primary: Colors.primary, secondary: Colors.secondary,
    outline: 'transparent', ghost: 'transparent', danger: Colors.error,
  };
  const textMap = {
    primary: Colors.white, secondary: Colors.white,
    outline: Colors.primary, ghost: Colors.primary, danger: Colors.white,
  };
  const sizeMap = { sm: 36, md: 48, lg: 56 };
  const fontMap = { sm: Typography.sm, md: Typography.base, lg: Typography.md };

  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.8}
      style={[
        styles.button,
        { backgroundColor: bgMap[variant], height: sizeMap[size], opacity: disabled ? 0.5 : 1 },
        variant === 'outline' && { borderWidth: 1.5, borderColor: Colors.primary },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={textMap[variant]} size="small" />
      ) : (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          {icon && <Ionicons name={icon as any} size={18} color={textMap[variant]} />}
          <Text style={[styles.buttonText, { color: textMap[variant], fontSize: fontMap[size] }]}>
            {label}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

// ===== Input =====
export function Input({
  label, placeholder, value, onChangeText, secureTextEntry,
  keyboardType, error, icon, multiline, numberOfLines, editable = true,
  onPress,
}: {
  label?: string;
  placeholder?: string;
  value?: string;
  onChangeText?: (t: string) => void;
  secureTextEntry?: boolean;
  keyboardType?: any;
  error?: string;
  icon?: string;
  multiline?: boolean;
  numberOfLines?: number;
  editable?: boolean;
  onPress?: () => void;
}) {
  const [showPass, setShowPass] = React.useState(false);

  const inner = (
    <View style={[styles.inputWrapper, error ? { borderColor: Colors.error } : {}]}>
      {icon && (
        <Ionicons name={icon as any} size={18} color={Colors.gray400} style={{ marginLeft: 12 }} />
      )}
      <TextInput
        style={[styles.inputText, multiline && { height: 100, textAlignVertical: 'top', paddingTop: 12 }]}
        placeholder={placeholder}
        placeholderTextColor={Colors.gray400}
        value={value}
        onChangeText={onChangeText}
        secureTextEntry={secureTextEntry && !showPass}
        keyboardType={keyboardType}
        multiline={multiline}
        numberOfLines={numberOfLines}
        editable={editable}
        textAlign="right"
      />
      {secureTextEntry && (
        <TouchableOpacity onPress={() => setShowPass(p => !p)} style={{ paddingRight: 12 }}>
          <Ionicons name={showPass ? 'eye-off' : 'eye'} size={18} color={Colors.gray400} />
        </TouchableOpacity>
      )}
    </View>
  );

  return (
    <View style={{ gap: 6 }}>
      {label && <Text style={styles.label}>{label}</Text>}
      {onPress ? (
        <TouchableOpacity onPress={onPress} activeOpacity={0.8}>{inner}</TouchableOpacity>
      ) : inner}
      {error && <Text style={styles.errorText}>{error}</Text>}
    </View>
  );
}

// ===== Card =====
export function Card({ children, style }: { children: React.ReactNode; style?: any }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

// ===== Badge =====
export function Badge({
  label, color = Colors.primary, bg,
}: { label: string; color?: string; bg?: string }) {
  return (
    <View style={[styles.badge, { backgroundColor: bg || color + '20' }]}>
      <Text style={[styles.badgeText, { color }]}>{label}</Text>
    </View>
  );
}

// ===== Avatar =====
export function Avatar({
  uri, name, size = 44, style,
}: { uri?: string; name?: string; size?: number; style?: any }) {
  const initials = name ? name.split(' ').map(w => w[0]).join('').slice(0, 2) : '؟';
  if (uri) {
    return (
      <Image
        source={{ uri }}
        style={[{ width: size, height: size, borderRadius: size / 2 }, style]}
      />
    );
  }
  return (
    <View style={[{
      width: size, height: size, borderRadius: size / 2,
      backgroundColor: Colors.primaryBg,
      alignItems: 'center', justifyContent: 'center',
    }, style]}>
      <Text style={{ color: Colors.primary, fontSize: size * 0.4, fontWeight: '600' }}>
        {initials}
      </Text>
    </View>
  );
}

// ===== Rating Stars =====
export function Stars({ rating, size = 14 }: { rating: number; size?: number }) {
  return (
    <View style={{ flexDirection: 'row', gap: 2 }}>
      {[1, 2, 3, 4, 5].map(i => (
        <Ionicons
          key={i}
          name={i <= Math.round(rating) ? 'star' : 'star-outline'}
          size={size}
          color={i <= Math.round(rating) ? '#F59E0B' : Colors.gray300}
        />
      ))}
    </View>
  );
}

// ===== Empty State =====
export function EmptyState({
  icon, title, subtitle, action,
}: {
  icon: string;
  title: string;
  subtitle?: string;
  action?: { label: string; onPress: () => void };
}) {
  return (
    <View style={styles.emptyState}>
      <View style={styles.emptyIcon}>
        <Ionicons name={icon as any} size={40} color={Colors.primaryLight} />
      </View>
      <Text style={styles.emptyTitle}>{title}</Text>
      {subtitle && <Text style={styles.emptySubtitle}>{subtitle}</Text>}
      {action && (
        <Button label={action.label} onPress={action.onPress} style={{ marginTop: 20, paddingHorizontal: 32 }} />
      )}
    </View>
  );
}

// ===== Loading Skeleton =====
export function Skeleton({ width, height, radius = 8, style }: {
  width: number | string; height: number; radius?: number; style?: any;
}) {
  const [opacity] = React.useState(new (require('react-native').Animated.Value)(0.4));
  React.useEffect(() => {
    const anim = require('react-native').Animated.loop(
      require('react-native').Animated.sequence([
        require('react-native').Animated.timing(opacity, { toValue: 1, duration: 800, useNativeDriver: true }),
        require('react-native').Animated.timing(opacity, { toValue: 0.4, duration: 800, useNativeDriver: true }),
      ])
    );
    anim.start();
    return () => anim.stop();
  }, []);

  return (
    <require('react-native').Animated.View
      style={[{ width, height, borderRadius: radius, backgroundColor: Colors.gray200 }, style, { opacity }]}
    />
  );
}

// ===== Divider =====
export function Divider({ label }: { label?: string }) {
  if (!label) return <View style={{ height: 0.5, backgroundColor: Colors.border, marginVertical: 12 }} />;
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginVertical: 12 }}>
      <View style={{ flex: 1, height: 0.5, backgroundColor: Colors.border }} />
      <Text style={{ color: Colors.gray400, fontSize: Typography.xs }}>{label}</Text>
      <View style={{ flex: 1, height: 0.5, backgroundColor: Colors.border }} />
    </View>
  );
}

// ===== Status Badge =====
const STATUS_MAP: Record<string, { label: string; color: string }> = {
  confirmed:       { label: 'مؤكد',           color: Colors.success },
  pending:         { label: 'قيد المراجعة',   color: Colors.warning },
  pending_payment: { label: 'بانتظار الدفع',  color: Colors.info },
  cancelled:       { label: 'ملغي',           color: Colors.error },
  completed:       { label: 'مكتمل',          color: Colors.gray500 },
  rejected:        { label: 'مرفوض',          color: Colors.error },
  open:            { label: 'مفتوح',          color: Colors.info },
  in_progress:     { label: 'جارٍ التنفيذ',   color: Colors.warning },
  resolved:        { label: 'تم الحل',        color: Colors.success },
  active:          { label: 'نشط',            color: Colors.success },
};

export function StatusBadge({ status }: { status: string }) {
  const cfg = STATUS_MAP[status] || { label: status, color: Colors.gray500 };
  return <Badge label={cfg.label} color={cfg.color} />;
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16,
    paddingVertical: 12, backgroundColor: Colors.white,
    borderBottomWidth: 0.5, borderBottomColor: Colors.border,
  },
  headerBtn: { width: 40, alignItems: 'center' },
  headerTitle: { fontSize: Typography.md, fontWeight: Typography.semibold, color: Colors.textPrimary },
  headerSubtitle: { fontSize: Typography.xs, color: Colors.textSecondary, marginTop: 2 },
  button: {
    borderRadius: Radius.xl, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: Spacing[6],
  },
  buttonText: { fontWeight: Typography.semibold },
  inputWrapper: {
    flexDirection: 'row', alignItems: 'center',
    borderWidth: 1.5, borderColor: Colors.border,
    borderRadius: Radius.lg, backgroundColor: Colors.white,
    minHeight: 50,
  },
  inputText: {
    flex: 1, paddingHorizontal: 14, color: Colors.textPrimary,
    fontSize: Typography.base, textAlign: 'right',
  },
  label: { fontSize: Typography.sm, fontWeight: Typography.medium, color: Colors.textPrimary },
  errorText: { fontSize: Typography.xs, color: Colors.error },
  card: {
    backgroundColor: Colors.white, borderRadius: Radius.xl,
    padding: Spacing[4], ...Shadow.sm,
  },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radius.full },
  badgeText: { fontSize: Typography.xs, fontWeight: Typography.semibold },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32 },
  emptyIcon: {
    width: 80, height: 80, borderRadius: 40, backgroundColor: Colors.primaryBg,
    alignItems: 'center', justifyContent: 'center', marginBottom: 16,
  },
  emptyTitle: {
    fontSize: Typography.lg, fontWeight: Typography.semibold,
    color: Colors.textPrimary, textAlign: 'center',
  },
  emptySubtitle: {
    fontSize: Typography.sm, color: Colors.textSecondary,
    textAlign: 'center', marginTop: 6, lineHeight: 22,
  },
});
